(function(){
  const CFG = window.ACSCALC || {};
  const root = document.querySelector('.acscalc');
  if (!root) return;

  const $ = (sel, el=root) => (el ? el.querySelector(sel) : null);
  const $$ = (sel, el=root) => (el ? Array.from(el.querySelectorAll(sel)) : []);

  const errorBox = $('[data-role="error"]');

  // ------------------------------------------------------------
  // Refresh auth state + REST nonce (survives full-page caching)
  // - GET endpoints do not require WP REST nonce.
  // ------------------------------------------------------------
  async function refreshAuthStateOnce(){
    try{
      const url = (CFG && CFG.auth && CFG.auth.stateUrl) ? String(CFG.auth.stateUrl) : '';
      if (!url) return false;
      const res = await fetch(addCacheBuster(url), { method:'GET', credentials:'include', cache:'no-store', headers: noCacheHeaders() });
      if (!res.ok) return false;
      const j = await res.json();
      if (!j || typeof j !== 'object') return false;
      CFG.auth = CFG.auth || {};
      if (typeof j.isLoggedIn === 'boolean') CFG.auth.isLoggedIn = j.isLoggedIn;
      if (j.restNonce) CFG.auth.restNonce = String(j.restNonce);
      if (j.loginUrl) CFG.auth.loginUrl = String(j.loginUrl);
      if (j.signupUrl) CFG.auth.signupUrl = String(j.signupUrl);
      return !!CFG.auth.isLoggedIn;
    } catch(_){ return false; }
  }


function noCacheHeaders(){
  return { 'Cache-Control':'no-cache, no-store, must-revalidate', 'Pragma':'no-cache' };
}
function addCacheBuster(url){
  try{
    const u = String(url||'');
    if (!u) return u;
    const sep = u.includes('?') ? '&' : '?';
    return u + sep + 'cb=' + Date.now() + '_' + Math.random().toString(16).slice(2);
  }catch(_){ return url; }
}

  function normalizeThemeKey(theme){
    const t = String(theme || 'general').trim().toLowerCase();
    if (t === 'communication') return 'teen';
    return t || 'general';
  }

  function getHouseLabel(house){
    const num = Number(house);
    const map = {
      1:'1st House — Self & Identity',
      2:'2nd House — Money & Values',
      3:'3rd House — Communication & Learning',
      4:'4th House — Home & Roots',
      5:'5th House — Love & Creativity',
      6:'6th House — Work & Wellbeing',
      7:'7th House — Partnership',
      8:'8th House — Transformation',
      9:'9th House — Study & Expansion',
      10:'10th House — Career & Reputation',
      11:'11th House — Community & Goals',
      12:'12th House — Inner World & Healing'
    };
    return map[num] || '';
  }

  // kick once (cache-safe)
  refreshAuthStateOnce();

  // ------------------------------------------------------------
  // Auth gating (Premium requires login)
  // ------------------------------------------------------------
  function isLoggedIn(){
    try{
      // 1) Server-localized flag (may be cached) – fast path
      const flag = !!(CFG && CFG.auth && CFG.auth.isLoggedIn);
      if (flag) return true;

      // 2) DOM signals (survive HttpOnly cookies + full-page cache)
      if (document.body && document.body.classList && document.body.classList.contains('logged-in')) return true;
      if (document.getElementById('wpadminbar')) return true;

      // 3) Cookie heuristic (may fail if HttpOnly)
      const ck = String(document.cookie || '');
      if (ck.includes('wordpress_logged_in_')) return true;

      return false;
    }catch(_){ return false; }
  }

  async function ensureLoggedInFresh(){
    try{
      if (isLoggedIn()) return true;
      await refreshAuthStateOnce();
      return isLoggedIn();
    }catch(_){ return isLoggedIn(); }
  }
  function getLoginUrl(){
    try{ return (CFG && CFG.auth && CFG.auth.loginUrl) ? String(CFG.auth.loginUrl) : ''; }catch(_){ return ''; }
  }
  function getSignupUrl(){
    try{
      const u = (CFG && CFG.auth && CFG.auth.signupUrl) ? String(CFG.auth.signupUrl) : '';
      return u || getLoginUrl();
    }catch(_){ return getLoginUrl(); }
  }
  function openLoginGate(){
    try{
      const modal = root.querySelector('[data-role="loginGate"]');
      if (!modal) return false;
      const aLogin = modal.querySelector('[data-action="loginGateLogin"]');
      const aSignup = modal.querySelector('[data-action="loginGateSignup"]');
      const loginUrl = getLoginUrl();
      const signupUrl = getSignupUrl();
      if (aLogin && loginUrl) aLogin.setAttribute('href', loginUrl);
      if (aSignup && signupUrl) aSignup.setAttribute('href', signupUrl);
      modal.style.display = 'flex';
      modal.setAttribute('aria-hidden','false');
      return true;
    }catch(_){ return false; }
  }
  function closeLoginGate(){
    try{
      const modal = root.querySelector('[data-role="loginGate"]');
      if (!modal) return;
      modal.style.display = 'none';
      modal.setAttribute('aria-hidden','true');
    }catch(_){ }
  }

  // Modal actions
  root.addEventListener('click', (e)=>{
    const act = e.target && e.target.closest ? e.target.closest('[data-action]') : null;
    if (!act) return;
    const a = act.getAttribute('data-action');
    if (a === 'loginGateClose') {
      e.preventDefault();
      closeLoginGate();
    }
  });

  // ------------------------------------------------------------
  // Social proof (pseudo-dynamic, display-only)
  // ------------------------------------------------------------
  function formatNumber(n){
    try{ return Number(n).toLocaleString(); }catch(_){ return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ','); }
  }
  function initSocialProof(){
    const sp = document.querySelector('[data-role="socialProof"]');
    if (!sp) return;
    const elScore = sp.querySelector('[data-role="spScore"]');
    const elUsers = sp.querySelector('[data-role="spUsers"]');
    const cfg = (CFG && CFG.socialProof) ? CFG.socialProof : null;
    const base = Math.max(0, parseInt(cfg && cfg.base || 138888, 10) || 138888);
    const rating = (cfg && cfg.rating != null) ? Number(cfg.rating) : 4.9;
    const epochStr = (cfg && cfg.epoch) ? String(cfg.epoch) : '2025-01-01T00:00:00Z';
    if (elScore) elScore.textContent = (Math.round(rating*10)/10).toFixed(1);

    // Compute a gentle growth curve from epoch (won't look "too fake")
    let epochMs = Date.parse(epochStr);
    if (!isFinite(epochMs)) epochMs = Date.parse('2025-01-01T00:00:00Z');
    const now = Date.now();
    const hours = Math.max(0, (now - epochMs) / 36e5);
    // ~0.35 users/hour (~8/day). This is intentionally subtle.
    const drift = Math.floor(hours * 0.35);

    // Stabilize using localStorage so number never decreases per visitor.
    const key = 'acscalc_sp_users_v1';
    let stored = 0;
    try{ stored = parseInt(localStorage.getItem(key) || '0', 10) || 0; }catch(_){ stored = 0; }

    let current = Math.max(base + drift, stored || 0);
    // small, occasional "natural" bump on first view (0-2) then persist
    const bumpKey = 'acscalc_sp_bump_v1';
    let bump = 0;
    try{
      const raw = localStorage.getItem(bumpKey);
      if (raw == null){
        bump = Math.floor(Math.random()*3); // 0..2
        localStorage.setItem(bumpKey, String(bump));
      } else {
        bump = parseInt(raw, 10) || 0;
      }
    }catch(_){ bump = 0; }
    current += Math.max(0, Math.min(2, bump));

    function render(){
      if (!elUsers) return;
      elUsers.textContent = `Over ${formatNumber(current)}+ users`;
    }
    render();

    // Subtle live increments (0-1) every 20-45s, capped per session
    let sessionAdds = 0;
    const maxSessionAdds = 6;
    function scheduleTick(){
      const delay = 20000 + Math.floor(Math.random()*25000);
      setTimeout(()=>{
        try{
          if (sessionAdds < maxSessionAdds){
            const add = (Math.random() < 0.55) ? 0 : 1;
            if (add){
              current += add;
              sessionAdds += add;
              render();
              try{ localStorage.setItem(key, String(current)); }catch(_){ }
            }
          }
        }catch(_){ }
        scheduleTick();
      }, delay);
    }
    scheduleTick();
  }

  // run once
  try{ initSocialProof(); }catch(_){ }

  // ============================================================
  // 移动端检测（屏幕宽度 ≤ 800px 且 支持触摸）
  // ============================================================
  function isMobileDevice() {
    // Allow forcing desktop selects (useful for QA on touch devices):
    // ?acscalc_desktop=1 or ?force_desktop=1 or window.ACSCALC.forceDesktop = true
    try {
      const sp = new URLSearchParams(window.location.search);
      if (sp.get('acscalc_desktop') === '1' || sp.get('force_desktop') === '1') return false;
    } catch (e) {}
    if (CFG && CFG.forceDesktop) return false;

    const isNarrowScreen = window.innerWidth <= 640;
    const isTouchDevice = (navigator.maxTouchPoints || 0) > 1;
    return isNarrowScreen && isTouchDevice;
  }

  // 监听窗口大小变化，实时切换显示模式
  let _lastIsMobile = isMobileDevice();
  window.addEventListener('resize', function() {
    const nowMobile = isMobileDevice();
    if (nowMobile !== _lastIsMobile) {
      _lastIsMobile = nowMobile;
      // 重新初始化所有日期/时间选择器的显示状态
      updatePickerDisplayMode();
    }
  });

  function updatePickerDisplayMode() {
    const forms = document.querySelectorAll('form[data-form]');
    forms.forEach(function(form) {
      const dateRow = form.querySelector('[data-role="birthDateRow"]');
      const dateTrigger = form.querySelector('[data-role="mobileDateTrigger"]');
      const timeRow = form.querySelector('[data-role="birthTimeRow"]');
      const timeTrigger = form.querySelector('[data-role="mobileTimeTrigger"]');

      if (isMobileDevice()) {
        // 移动端：隐藏下拉框，显示触发按钮
        if (dateRow) dateRow.style.setProperty('display', 'none', 'important');
        if (dateTrigger) dateTrigger.style.setProperty('display', 'block', 'important');
        if (timeRow) timeRow.style.setProperty('display', 'none', 'important');
        if (timeTrigger) timeTrigger.style.setProperty('display', 'block', 'important');
      } else {
        // 桌面端：显示下拉框，强制隐藏触发按钮
        if (dateRow) dateRow.style.setProperty('display', 'flex', 'important');
        if (dateTrigger) dateTrigger.style.setProperty('display', 'none', 'important');
        if (timeRow) timeRow.style.setProperty('display', 'flex', 'important');
        if (timeTrigger) timeTrigger.style.setProperty('display', 'none', 'important');
      }
    });
  }


  // ------------------------------------------------------------
  // PPT multi-page UI helpers (release UI uses .acscalc__page[data-page])
  // ------------------------------------------------------------
  const hasPptPages = !!root.querySelector('.acscalc__page[data-page]');

  function updateUiState(panelName, pageName){
    // Result pages should show the top-right Back link and hide the mode switch.
    const isResult = /(^|-)result$/.test(pageName) || /(^|-)report$/.test(pageName) || pageName.includes('result') || pageName.includes('report');
    root.classList.toggle('is-results', !!isResult);
    root.dataset.activePanel = panelName || '';
    root.dataset.activePage = pageName || '';
  }

  function showPageInPanel(panelName, pageName){
    if (!hasPptPages) return;
    const panel = root.querySelector(`.acscalc__panel[data-panel="${panelName}"]`) || root;
    const pages = Array.from(panel.querySelectorAll('.acscalc__page[data-page]'));
    if (!pages.length) return;
    pages.forEach(p=>{
      const active = (p.getAttribute('data-page') === pageName);
      p.hidden = !active;
      p.style.display = active ? '' : 'none';
    });
    updateUiState(panelName, pageName);
    try{ window.scrollTo({ top: root.getBoundingClientRect().top + window.scrollY - 10, behavior:'smooth' }); }catch(_){ }
  }

  function showQuickPage(pageName){ showPageInPanel('quick', pageName); }
  function showPrecisePage(pageName){ showPageInPanel('precise', pageName); }


  function showError(msg){
    if (!errorBox) return;
    errorBox.textContent = msg;
    errorBox.style.display = 'block';
  }
  function clearError(){
    if (!errorBox) return;
    errorBox.textContent = '';
    errorBox.style.display = 'none';
  }

  // ------------------------------
  // Birth date dropdown (Year / Month / Day)
  // ------------------------------
  function pad2(n){ return String(n).padStart(2,'0'); }
  function daysInMonth(y, m){
    const yy = Number(y), mm = Number(m);
    if (!yy || !mm) return 31;
    return new Date(yy, mm, 0).getDate(); // mm is 1-12, day 0 => last day of prev month
  }

  // ============================================================
  // 移动端滚轮选择器 (Wheel Picker)
  // ============================================================
  const WheelPicker = (function() {
    let pickerEl = null;
    let wheelsContainer = null;
    let currentCallback = null;
    let currentType = null; // 'date' | 'time'
    let currentValues = {};
    let wheelData = {};

    const ITEM_HEIGHT = 44; // Item height (px)
    const VISIBLE_ITEMS = 5; // Number of visible items

    function init() {
      pickerEl = document.getElementById('acscalcWheelPicker');
      if (!pickerEl) return;

      wheelsContainer = pickerEl.querySelector('[data-role="wheelsContainer"]');
      if (!wheelsContainer) return;

      // 绑定事件
      const cancelBtn = pickerEl.querySelector('[data-action="wheelCancel"]');
      const confirmBtn = pickerEl.querySelector('[data-action="wheelConfirm"]');
      const overlay = pickerEl.querySelector('.acscalc-wheel-picker__overlay');

      if (cancelBtn) cancelBtn.addEventListener('click', hide);
      if (confirmBtn) confirmBtn.addEventListener('click', confirm);
      if (overlay) overlay.addEventListener('click', hide);

      // 阻止滚动穿透
      pickerEl.addEventListener('touchmove', function(e) {
        if (!e.target.closest('.acscalc-wheel-picker__wheel')) {
          e.preventDefault();
        }
      }, { passive: false });
    }

    function generateYears() {
      const current = new Date().getFullYear();
      const years = [];
      for (let y = current; y >= 1900; y--) {
        years.push({ value: y, label: String(y) });
      }
      return years;
    }

    function generateMonths() {
      const months = [];
      for (let m = 1; m <= 12; m++) {
        months.push({ value: m, label: pad2(m) });
      }
      return months;
    }

    function generateDays(year, month) {
      const max = daysInMonth(year, month);
      const days = [];
      for (let d = 1; d <= max; d++) {
        days.push({ value: d, label: pad2(d) });
      }
      return days;
    }

    function generateHours() {
      const hours = [];
      for (let h = 0; h <= 23; h++) {
        hours.push({ value: h, label: pad2(h) });
      }
      return hours;
    }

    function generateMinutes() {
      const minutes = [];
      for (let m = 0; m <= 59; m++) {
        minutes.push({ value: m, label: pad2(m) });
      }
      return minutes;
    }

    function createWheel(key, items, selectedValue) {
      const wheel = document.createElement('div');
      wheel.className = 'acscalc-wheel-picker__wheel';
      wheel.setAttribute('data-wheel', key);

      const list = document.createElement('div');
      list.className = 'acscalc-wheel-picker__list';

      // 添加顶部占位
      for (let i = 0; i < Math.floor(VISIBLE_ITEMS / 2); i++) {
        const spacer = document.createElement('div');
        spacer.className = 'acscalc-wheel-picker__item acscalc-wheel-picker__item--spacer';
        list.appendChild(spacer);
      }

      // 添加选项
      items.forEach(function(item, index) {
        const el = document.createElement('div');
        el.className = 'acscalc-wheel-picker__item';
        el.setAttribute('data-value', item.value);
        el.setAttribute('data-index', index);
        el.textContent = item.label;
        list.appendChild(el);
      });

      // 添加底部占位
      for (let i = 0; i < Math.floor(VISIBLE_ITEMS / 2); i++) {
        const spacer = document.createElement('div');
        spacer.className = 'acscalc-wheel-picker__item acscalc-wheel-picker__item--spacer';
        list.appendChild(spacer);
      }

      wheel.appendChild(list);

      // 滚动到选中项
      let selectedIndex = items.findIndex(function(it) { return it.value === selectedValue; });
      if (selectedIndex < 0) selectedIndex = 0;

      // 使用 requestAnimationFrame 确保DOM已渲染
      requestAnimationFrame(function() {
        wheel.scrollTop = selectedIndex * ITEM_HEIGHT;
        updateHighlight(wheel);
      });

      // 滚动事件 - 使用节流处理
      let scrollTimeout = null;
      wheel.addEventListener('scroll', function() {
        clearTimeout(scrollTimeout);
        scrollTimeout = setTimeout(function() {
          snapToItem(wheel, key, items);
        }, 80);
      }, { passive: true });

      // 点击选项直接跳转
      list.addEventListener('click', function(e) {
        const item = e.target.closest('.acscalc-wheel-picker__item:not(.acscalc-wheel-picker__item--spacer)');
        if (!item) return;
        const index = parseInt(item.getAttribute('data-index'), 10);
        wheel.scrollTo({ top: index * ITEM_HEIGHT, behavior: 'smooth' });
      });

      return wheel;
    }

    function snapToItem(wheel, key, items) {
      const scrollTop = wheel.scrollTop;
      const index = Math.round(scrollTop / ITEM_HEIGHT);
      const clampedIndex = Math.max(0, Math.min(index, items.length - 1));

      const targetScrollTop = clampedIndex * ITEM_HEIGHT;
      const offset = Math.abs(scrollTop - targetScrollTop);

      // 只有当偏移量大于2px时才执行滚动，避免微小抖动
      if (offset > 2) {
        wheel.scrollTo({ top: targetScrollTop, behavior: 'smooth' });
      }

      const selectedItem = items[clampedIndex];
      if (selectedItem) {
        currentValues[key] = selectedItem.value;

        // 如果是年份或月份变化，需要更新天数
        if (currentType === 'date' && (key === 'year' || key === 'month')) {
          updateDaysWheel();
        }
      }

      updateHighlight(wheel);
    }

    function updateHighlight(wheel) {
      const items = wheel.querySelectorAll('.acscalc-wheel-picker__item:not(.acscalc-wheel-picker__item--spacer)');
      const scrollTop = wheel.scrollTop;
      const centerIndex = Math.round(scrollTop / ITEM_HEIGHT);

      items.forEach(function(item, i) {
        item.classList.toggle('is-selected', i === centerIndex);
      });
    }

    function updateDaysWheel() {
      if (!wheelsContainer) return;
      const dayWheel = wheelsContainer.querySelector('[data-wheel="day"]');
      if (!dayWheel) return;

      const year = currentValues.year || new Date().getFullYear();
      const month = currentValues.month || 1;
      const currentDay = currentValues.day || 1;

      const newDays = generateDays(year, month);
      wheelData.day = newDays;

      // 如果当前天数超过新月份的最大天数，调整
      const maxDay = newDays.length;
      if (currentDay > maxDay) {
        currentValues.day = maxDay;
      }

      // 重建天数滚轮
      const newWheel = createWheel('day', newDays, currentValues.day);
      dayWheel.replaceWith(newWheel);
    }

    function showDatePicker(initialDate, callback) {
      if (!pickerEl || !wheelsContainer) init();
      if (!pickerEl || !wheelsContainer) return;

      currentType = 'date';
      currentCallback = callback;

      // 解析初始日期
      let year = new Date().getFullYear();
      let month = 1;
      let day = 1;

      if (initialDate) {
        const parts = String(initialDate).split('-');
        if (parts.length === 3) {
          year = parseInt(parts[0], 10) || year;
          month = parseInt(parts[1], 10) || 1;
          day = parseInt(parts[2], 10) || 1;
        }
      }

      currentValues = { year: year, month: month, day: day };

      // 生成数据
      wheelData = {
        year: generateYears(),
        month: generateMonths(),
        day: generateDays(year, month)
      };

      // 清空并创建滚轮
      wheelsContainer.innerHTML = '';
      wheelsContainer.appendChild(createWheel('year', wheelData.year, year));
      wheelsContainer.appendChild(createWheel('month', wheelData.month, month));
      wheelsContainer.appendChild(createWheel('day', wheelData.day, day));

      // 更新标题
      const title = pickerEl.querySelector('.acscalc-wheel-picker__title');
      if (title) title.textContent = 'Select Date';

      show();
    }

    function showTimePicker(initialTime, callback) {
      if (!pickerEl || !wheelsContainer) init();
      if (!pickerEl || !wheelsContainer) return;

      currentType = 'time';
      currentCallback = callback;

      // 解析初始时间
      let hour = 12;
      let minute = 0;

      if (initialTime) {
        const parts = String(initialTime).split(':');
        if (parts.length >= 2) {
          hour = parseInt(parts[0], 10) || 0;
          minute = parseInt(parts[1], 10) || 0;
        }
      }

      currentValues = { hour: hour, minute: minute };

      // 生成数据
      wheelData = {
        hour: generateHours(),
        minute: generateMinutes()
      };

      // 清空并创建滚轮
      wheelsContainer.innerHTML = '';
      wheelsContainer.appendChild(createWheel('hour', wheelData.hour, hour));
      wheelsContainer.appendChild(createWheel('minute', wheelData.minute, minute));

      // 更新标题
      const title = pickerEl.querySelector('.acscalc-wheel-picker__title');
      if (title) title.textContent = 'Select Time';

      show();
    }

    function show() {
      if (!pickerEl) return;
      pickerEl.style.display = '';
      document.body.style.overflow = 'hidden'; // Prevent background scrolling

      requestAnimationFrame(function() {
        pickerEl.classList.add('is-active');
      });
    }

    function hide() {
      if (!pickerEl) return;
      pickerEl.classList.remove('is-active');
      document.body.style.overflow = '';

      setTimeout(function() {
        if (pickerEl) pickerEl.style.display = 'none';
      }, 300);
    }

    function confirm() {
      if (!wheelsContainer) return;
      // 读取当前各滚轮的值
      var wheels = wheelsContainer.querySelectorAll('.acscalc-wheel-picker__wheel');
      wheels.forEach(function(wheel) {
        var key = wheel.getAttribute('data-wheel');
        var scrollTop = wheel.scrollTop;
        var index = Math.round(scrollTop / ITEM_HEIGHT);
        var items = wheelData[key];
        if (items && items[index]) {
          currentValues[key] = items[index].value;
        }
      });

      var result = '';
      if (currentType === 'date') {
        var y = currentValues.year;
        var m = pad2(currentValues.month);
        var d = pad2(currentValues.day);
        result = y + '-' + m + '-' + d;
      } else if (currentType === 'time') {
        var h = pad2(currentValues.hour);
        var min = pad2(currentValues.minute);
        result = h + ':' + min;
      }

      if (currentCallback) {
        currentCallback(result, currentValues);
      }

      hide();
    }

    return {
      init: init,
      showDatePicker: showDatePicker,
      showTimePicker: showTimePicker,
      hide: hide
    };
  })();

  // 页面加载后初始化（兜底：如果脚本在头部加载）
  document.addEventListener('DOMContentLoaded', function() {
    try { WheelPicker.init(); } catch(_){ }
  });

  function initBirthDateDropdown(form) {
    const ySel = form.querySelector('select[name="birthYear"]');
    const mSel = form.querySelector('select[name="birthMonth"]');
    const dSel = form.querySelector('select[name="birthDay"]');
    const hidden = form.querySelector('input[name="birthDate"]');
    const dateRow = form.querySelector('[data-role="birthDateRow"]');
    const mobileTrigger = form.querySelector('[data-role="mobileDateTrigger"]');

    if (!ySel || !mSel || !dSel || !hidden) return;

    // =====================
    // 移动端：使用滚轮选择器
    // =====================
    if (isMobileDevice() && mobileTrigger) {
      // 隐藏原生下拉框，显示触发输入框（使用important确保生效）
      if (dateRow) dateRow.style.setProperty('display', 'none', 'important');
      mobileTrigger.style.setProperty('display', 'block', 'important');

      // 更新显示值
      function updateMobileDisplay() {
        var val = hidden.value;
        if (val) {
          mobileTrigger.value = val;
        } else {
          mobileTrigger.value = '';
        }
      }

      // 点击触发滚轮（移除之前可能绑定的事件）
      mobileTrigger.onclick = function() {
        WheelPicker.showDatePicker(hidden.value, function(dateStr, values) {
          hidden.value = dateStr;
          mobileTrigger.value = dateStr;

          // 同步更新隐藏的原生select（保持数据一致性）
          ySel.value = String(values.year);
          mSel.value = pad2(values.month);
          dSel.value = pad2(values.day);
        });
      };

      updateMobileDisplay();
    } else {
      // =====================
      // 桌面端：使用原生下拉框，强制隐藏移动端触发器
      // =====================
      if (mobileTrigger) {
        mobileTrigger.style.setProperty('display', 'none', 'important');
      }
      if (dateRow) {
        dateRow.style.setProperty('display', 'flex', 'important');
      }
    }

    // 以下是桌面端下拉框的初始化逻辑（始终执行，保持数据同步）

    // Populate year/month only once (keep placeholder option at index 0)
    if (ySel.options.length <= 1) {
      const curY = new Date().getFullYear();
      const startY = 1900;
      for (let y = curY; y >= startY; y--) {
        const opt = document.createElement('option');
        opt.value = String(y);
        opt.textContent = String(y);
        ySel.appendChild(opt);
      }
    }
    if (mSel.options.length <= 1) {
      for (let m = 1; m <= 12; m++) {
        const opt = document.createElement('option');
        opt.value = pad2(m);
        opt.textContent = pad2(m);
        mSel.appendChild(opt);
      }
    }

    function refreshDays() {
      const y = ySel.value;
      const m = mSel.value;
      const cur = dSel.value;
      const maxD = daysInMonth(y, Number(m));
      while (dSel.options.length > 1) dSel.remove(1);
      for (let d = 1; d <= maxD; d++) {
        const opt = document.createElement('option');
        opt.value = pad2(d);
        opt.textContent = pad2(d);
        dSel.appendChild(opt);
      }
      if (cur && Number(cur) <= maxD) dSel.value = cur;
    }

    function syncHidden() {
      const y = ySel.value;
      const m = mSel.value;
      const d = dSel.value;
      hidden.value = (y && m && d) ? y + '-' + m + '-' + d : '';
    }

    ySel.addEventListener('change', function() { refreshDays(); syncHidden(); });
    mSel.addEventListener('change', function() { refreshDays(); syncHidden(); });
    dSel.addEventListener('change', function() { syncHidden(); });

    refreshDays();
    syncHidden();
  }

  function initAllBirthDateDropdowns(){
    $$('form[data-form]').forEach(f=>initBirthDateDropdown(f));
  }

  // ------------------------------
  // Birth time dropdown (Hour / Minute)
  // ------------------------------
  function initBirthTimeDropdown(form) {
    const hSel = form.querySelector('select[name="birthHour"]');
    const mSel = form.querySelector('select[name="birthMinute"]');
    const hidden = form.querySelector('input[name="birthTime"]');
    const timeRow = form.querySelector('[data-role="birthTimeRow"]');
    const mobileTrigger = form.querySelector('[data-role="mobileTimeTrigger"]');

    if (!hSel || !mSel || !hidden) return;

    // =====================
    // 移动端：使用滚轮选择器
    // =====================
    if (isMobileDevice() && mobileTrigger) {
      // 隐藏原生下拉框，显示触发输入框（使用important确保生效）
      if (timeRow) timeRow.style.setProperty('display', 'none', 'important');
      mobileTrigger.style.setProperty('display', 'block', 'important');

      // 更新显示值
      function updateMobileDisplay() {
        var val = hidden.value;
        if (val && val !== '12:00') {
          mobileTrigger.value = val;
        } else {
          mobileTrigger.value = '';
        }
      }

      // 点击触发滚轮
      mobileTrigger.onclick = function() {
        WheelPicker.showTimePicker(hidden.value, function(timeStr, values) {
          hidden.value = timeStr;
          mobileTrigger.value = timeStr;

          // 同步更新隐藏的原生select
          hSel.value = pad2(values.hour);
          mSel.value = pad2(values.minute);
        });
      };

      updateMobileDisplay();
    } else {
      // =====================
      // 桌面端：使用原生下拉框，强制隐藏移动端触发器
      // =====================
      if (mobileTrigger) {
        mobileTrigger.style.setProperty('display', 'none', 'important');
      }
      if (timeRow) {
        timeRow.style.setProperty('display', 'flex', 'important');
      }
    }

    // 以下是桌面端下拉框的初始化逻辑（始终执行）

    // Populate only once (keep placeholder at index 0)
    if (hSel.options.length <= 1) {
      for (let h = 0; h <= 23; h++) {
        const opt = document.createElement('option');
        opt.value = pad2(h);
        opt.textContent = pad2(h);
        hSel.appendChild(opt);
      }
    }
    if (mSel.options.length <= 1) {
      for (let m = 0; m <= 59; m++) {
        const opt = document.createElement('option');
        opt.value = pad2(m);
        opt.textContent = pad2(m);
        mSel.appendChild(opt);
      }
    }

    function syncHidden() {
      const hh = hSel.value;
      const mm = mSel.value;
      hidden.value = (hh && mm) ? hh + ':' + mm : '';
    }

    hSel.addEventListener('change', syncHidden);
    mSel.addEventListener('change', syncHidden);
    syncHidden();
  }

  function initAllBirthTimeDropdowns(){
    $$('form[data-form]').forEach(f=>initBirthTimeDropdown(f));
  }

  // ------------------------------
  // PPT slide-06 "Upgrade guide" view
  // ------------------------------
  function setQueryParam(key, val){
    try{
      const u = new URL(window.location.href);
      if (val === null || val === undefined || val === '') u.searchParams.delete(key);
      else u.searchParams.set(key, String(val));
      window.history.pushState({}, '', u.toString());
    }catch(_){
      // ignore
    }
  }

  function showUpgradeView(){
    const main = root.querySelector('[data-view-block="quick-main"]');
    const up   = root.querySelector('[data-view-block="upgrade"]');
    if (!up) return;
    if (main) { main.hidden = true; main.style.display = 'none'; }
    up.hidden = false;
    up.style.display = '';
    root.classList.add('acscalc--view-upgrade');
    root.dataset.view = 'upgrade';
    setQueryParam('acscalc_view', 'upgrade');
    try{ window.scrollTo({ top: root.getBoundingClientRect().top + window.scrollY - 10, behavior:'smooth' }); }catch(_){ }
  }

  function hideUpgradeView(){
    const main = root.querySelector('[data-view-block="quick-main"]');
    const up   = root.querySelector('[data-view-block="upgrade"]');
    if (!up) return;
    up.hidden = true;
    up.style.display = 'none';
    if (main) { main.hidden = false; main.style.display = ''; }
    root.classList.remove('acscalc--view-upgrade');
    root.dataset.view = '';
    setQueryParam('acscalc_view', '');
    try{ window.scrollTo({ top: root.getBoundingClientRect().top + window.scrollY - 10, behavior:'smooth' }); }catch(_){ }
  }
  // Derive zodiac keys from an ephemeris longitude (0-360).
  // This is used only when we have a real chart response from the ACS chart endpoint.
  function zodiacFromLongitude(lon){
    const x = Number(lon);
    if (!isFinite(x)) return { key: '', ast: '' };
    const idx = ((Math.floor(((x%360)+360)%360 / 30)) + 12) % 12;
    const keys = [
      'aries','taurus','gemini','cancer','leo','virgo',
      'libra','scorpio','sagittarius','capricorn','aquarius','pisces'
    ];
    const astOrder = ['AST013','AST014','AST015','AST016','AST017','AST018','AST019','AST020','AST021','AST022','AST023','AST024'];
    return { key: keys[idx] || '', ast: astOrder[idx] || '' };
  }

// Force-initialize panel visibility on load (guards against theme CSS conflicts)
  try{
    const activePanel = document.querySelector('.acscalc__panel.is-active');
    document.querySelectorAll('.acscalc__panel').forEach(p=>{
      const active = activePanel ? (p === activePanel) : (p.getAttribute('data-panel') === 'quick');
      p.classList.toggle('is-active', active);
      p.style.display = active ? '' : 'none';
      p.hidden = !active;
    });
  }catch(_){}

  // Tabs (only if mode=both) - behave like a true mode switch (only one visible)
  
  // Respect shortcode mode (quick/precise/both)
  try{
    const mode = (root && root.getAttribute('data-mode')) ? root.getAttribute('data-mode') : 'both';
    const tabsEl = document.querySelector('[data-role="tabs"]');
    if (tabsEl && mode !== 'both') tabsEl.style.display = 'none';
    const activeTab = mode === 'precise' ? 'precise' : 'quick';
    document.querySelectorAll('.acscalc__tab[data-tab]').forEach(b=>{
      const a = b.getAttribute('data-tab') === activeTab;
      b.classList.toggle('is-active', a);
      b.setAttribute('aria-selected', a ? 'true' : 'false');
    });
    document.querySelectorAll('.acscalc__panel').forEach(p=>{
      const a = p.getAttribute('data-panel') === activeTab;
      p.classList.toggle('is-active', a);
      p.style.display = a ? '' : 'none';
      p.hidden = !a;
    });
  }catch(_){ }

  // Initialize dropdown date inputs
  try{ initAllBirthDateDropdowns(); }catch(_){ }

  // Initialize dropdown time inputs (hour/minute)
  try{ initAllBirthTimeDropdowns(); }catch(_){ }

  // Initialize wheel picker (mobile only)
  try{ WheelPicker.init(); }catch(_){ }

  // Set correct display mode for current device
  try{ updatePickerDisplayMode(); }catch(_){ }

  // Initialize PPT pages (if present)
  if (hasPptPages) {
    const mode = (root && root.getAttribute('data-mode')) ? root.getAttribute('data-mode') : 'both';

    // Default visible page per panel
    showQuickPage('quick-input');
    showPrecisePage('precise-input');

    // If shortcode locks to one mode, ensure its first page is visible
    if (mode === 'quick') {
      showQuickPage('quick-input');
    } else if (mode === 'precise') {
      showPrecisePage('precise-input');
    }
  }

  const tabs = $('[data-role="tabs"]');
  if (tabs) {
    // Initialize aria-selected
    document.querySelectorAll('.acscalc__tab[data-tab]').forEach(b=>{
      b.setAttribute('aria-selected', b.classList.contains('is-active') ? 'true' : 'false');
    });

    tabs.addEventListener('click', (e)=>{
      const btn = e.target.closest('button[data-tab]');
      if (!btn) return;

      clearError();
      $$('.acscalc__loading', root).forEach(x => { try{ x.style.display='none'; }catch(_){} });

      const tab = btn.dataset.tab;

      // Premium gating: require login for precise mode
      if (tab === 'precise' && !isLoggedIn()) {
        e.preventDefault();
        // Refresh auth state (handles full-page cache) then retry once.
        ensureLoggedInFresh().then((ok)=>{
          if (ok) {
            try{ btn.click(); }catch(_){ }
          } else {
            try{ openLoginGate(); }catch(_){ }
          }
        });
        return;
      }

      $$('.acscalc__tab', tabs).forEach(b => {
        const active = (b === btn);
        b.classList.toggle('is-active', active);
        b.setAttribute('aria-selected', active ? 'true' : 'false');
      });

      $$('.acscalc__panel', root).forEach(p => {
        const active = (p.dataset.panel === tab);
        p.classList.toggle('is-active', active);
        p.style.display = active ? '' : 'none';
        p.hidden = !active;

        // Hide results in inactive mode so it feels like a single switch
        if (!active) {
          const r = p.querySelector('[data-result]');
          if (r) { r.style.display='none'; r.innerHTML=''; }
        }
      });

      try{
        window.scrollTo({ top: root.getBoundingClientRect().top + window.scrollY - 10, behavior:'smooth' });
      }catch(_){}
    });
  }

  // Top-right Back (only visible on result pages)
  (function(){
    const back = root.querySelector('[data-action="app-back"]');
    if (!back) return;
    back.addEventListener('click', (e)=>{
      e.preventDefault();
      clearError();
      const panel = root.dataset.activePanel || 'quick';
      if (panel === 'precise') {
        showPrecisePage('precise-input');
      } else {
        showQuickPage('quick-input');
      }
    });
  })();

  // Global actions (page navigation)
  root.addEventListener('click', (e)=>{
    const el = e.target.closest('[data-action]');
    if (!el) return;
    const act = el.getAttribute('data-action');

    // Prefer PPT pages navigation when available
    if (hasPptPages) {
      if (act === 'back-to-quick-input') {
        e.preventDefault();
        showQuickPage('quick-input');
        return;
      }
      if (act === 'back-to-quick-result') {
        e.preventDefault();
        showQuickPage('quick-result');
        return;
      }
      if (act === 'open-upgrade') {
        e.preventDefault();
        showQuickPage('quick-upgrade');
        return;
      }
      if (act === 'back-to-precise-input') {
        e.preventDefault();
        showPrecisePage('precise-input');
        return;
      }
      if (act === 'switch-precise') {
        e.preventDefault();

        // Astral UI: switch to Premium (precise) in-page.
        try{
          const btn = root.querySelector('.acscalc__tab[data-tab="precise"]');
          if (btn) btn.click();
        }catch(_){ }
        try{ showPrecisePage('precise-input'); }catch(_){ }
        return;
      }
    }

    // Legacy upgrade view blocks (older markup)
    if (act === 'open-upgrade') {
      e.preventDefault();
      showUpgradeView();
    } else if (act === 'back-quick') {
      e.preventDefault();
      hideUpgradeView();
    }
  });

  // If page loaded with ?acscalc_view=upgrade, show upgrade view.
  try{
    const u = new URL(window.location.href);
    const v = u.searchParams.get('acscalc_view') || (root.dataset ? root.dataset.view : '');
    if (v === 'upgrade') showUpgradeView();
  }catch(_){ }

  function escapeHtml(s){
    return String((s==null)?'':s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  }

  function decodeHtmlEntities(text){
    const raw = String(text==null ? '' : text);
    try{
      const ta = document.createElement('textarea');
      ta.innerHTML = raw;
      return ta.value;
    }catch(_){
      return raw.replace(/&#039;/g, "'").replace(/&quot;/g, '"').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
    }
  }

  function mdToHtml(text){
    // Safe renderer with limited HTML passthrough for <details> blocks.
    const raw = String(text||'');
    const hasDetails = /<details[\s>]/i.test(raw);

    const renderMd = (t)=>{
      const esc = escapeHtml(t);
      return esc
        .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
        .replace(/\n{2,}/g, '</p><p>')
        .replace(/\n/g, '<br/>')
        .replace(/^/, '<p>')
        .replace(/$/, '</p>');
    };

    if (!hasDetails) return renderMd(raw);

    // Keep <details>...</details> as HTML, but sanitize it.
    const parts = raw.split(/(<details[\s\S]*?<\/details>)/ig);
    const sanitizeDetails = (html)=>{
      let h = String(html||'');
      // Remove scripts
      h = h.replace(/<script[\s\S]*?<\/script>/ig, '');
      // Remove on* event handlers
      h = h.replace(/\son\w+\s*=\s*(["\']).*?\1/ig, '');
      // Remove javascript: URLs
      h = h.replace(/(href|src)\s*=\s*(["\'])\s*javascript:[^"\']*\2/ig, '');
      return h;
    };

    let out = '';
    for (let i=0;i<parts.length;i++){
      const p = parts[i];
      if (!p) continue;
      if (/^<details[\s>]/i.test(p)) out += sanitizeDetails(p);
      else out += renderMd(p);
    }
    return out;
  }

  

  // --- Placeholder resolution (EN front-end) ---
  // Resolve {{sunSign}} / {{sun_sign}} style variables and nested copy placeholders like {{action_career_01}}.
  function cnZodiacToEn(name){
    const s = String(name||'').trim();
    if (!s) return '';
    const map = {
      '白羊座':'Aries','金牛座':'Taurus','双子座':'Gemini','巨蟹座':'Cancer','狮子座':'Leo','处女座':'Virgo',
      '天秤座':'Libra','天蝎座':'Scorpio','射手座':'Sagittarius','摩羯座':'Capricorn','水瓶座':'Aquarius','双鱼座':'Pisces'
    };
    return map[s] || s;
  }

  function pickFromTemplateLib(tpl){
    if (!tpl) return '';
    const list = Array.isArray(tpl.carousel_en_list) ? tpl.carousel_en_list : [];
    if (list.length) return String(list[Math.floor(Math.random()*list.length)] || '');
    return String(tpl.template_en || '');
  }

  function resolvePlaceholders(text, ctx, templateLib){
    if (!text) return '';
    const lib = (templateLib && typeof templateLib === 'object') ? templateLib : {};
    const c = (ctx && typeof ctx === 'object') ? ctx : {};
    const maxPasses = 3;
    let out = String(text);
    for (let pass=0; pass<maxPasses; pass++){
      let changed = false;
      out = out.replace(/\{\{\s*([^{}\s]+)\s*\}\}/g, (m, key)=>{
        const k = String(key||'').trim();
        if (!k) return m;
        if (Object.prototype.hasOwnProperty.call(c, k)) { changed = true; return String(c[k] ?? ''); }
        const alias = (k === 'sunSign') ? 'sun_sign'
          : (k === 'moonSign') ? 'moon_sign'
          : (k === 'risingSign') ? 'rising_sign'
          : (k === 'ascSign') ? 'rising_sign'
          : '';
        if (alias && Object.prototype.hasOwnProperty.call(c, alias)) { changed = true; return String(c[alias] ?? ''); }
        if (Object.prototype.hasOwnProperty.call(lib, k)) { changed = true; return pickFromTemplateLib(lib[k]); }
        return m;
      });
      if (!changed) break;
    }
    return out;
  }

function parseYmd(input){
    // Accept multiple common date formats and normalize to {y,m,d}
    // Supported examples:
    //  - YYYY-MM-DD, YYYY/MM/DD, YYYY.MM.DD
    //  - DD/MM/YYYY, DD-MM-YYYY
    //  - MM/DD/YYYY, MM-DD-YYYY
    const s = String(input||'').trim();
    if (!s) return null;

    // YYYY[-/.]MM[-/.]DD
    let m = /^(\d{4})[\/\-.](\d{1,2})[\/\-.](\d{1,2})$/.exec(s);
    if (m){
      const y = Number(m[1]), mo = Number(m[2]), d = Number(m[3]);
      if (!isValidYmd(y, mo, d)) return null;
      return { y, m: mo, d };
    }

    // DD[-/.]MM[-/.]YYYY or MM[-/.]DD[-/.]YYYY
    m = /^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})$/.exec(s);
    if (m){
      const a = Number(m[1]), b = Number(m[2]), y = Number(m[3]);

      // Heuristic:
      // - If first part > 12 => DD/MM/YYYY
      // - Else if second part > 12 => MM/DD/YYYY
      // - Else default to DD/MM/YYYY (common internationally)
      let d, mo;
      if (a > 12) { d = a; mo = b; }
      else if (b > 12) { mo = a; d = b; }
      else { d = a; mo = b; }

      if (!isValidYmd(y, mo, d)) return null;
      return { y, m: mo, d };
    }

    return null;
  }

  function isValidYmd(y, mo, d){
    if (!Number.isFinite(y) || !Number.isFinite(mo) || !Number.isFinite(d)) return false;
    if (y < 1900 || y > 2100) return false;
    if (mo < 1 || mo > 12) return false;
    if (d < 1 || d > 31) return false;
    const dt = new Date(y, mo-1, d);
    return dt && dt.getFullYear() === y && (dt.getMonth()+1) === mo && dt.getDate() === d;
  }

  function normalizeBirthDate(input){
    const p = parseYmd(input);
    if (!p) return null;
    const mm = String(p.m).padStart(2,'0');
    const dd = String(p.d).padStart(2,'0');
    return `${p.y}-${mm}-${dd}`;
  }

  function normalizeBirthTime(input){
    const s = String(input||'').trim();
    if (!s) return null;
    // Accept HH:MM, H:MM, HHMM
    let m = /^(\d{1,2}):(\d{2})$/.exec(s);
    if (!m) m = /^(\d{2})(\d{2})$/.exec(s);
    if (!m) return null;
    const hh = Number(m[1]), mm = Number(m[2]);
    if (hh < 0 || hh > 23 || mm < 0 || mm > 59) return null;
    return `${String(hh).padStart(2,'0')}:${String(mm).padStart(2,'0')}`;
  }

  function calcAge(ymd){
    const p = parseYmd(ymd);
    if (!p) return null;
    const now = new Date();
    let age = now.getFullYear() - p.y;
    const thisYearBirthday = new Date(now.getFullYear(), p.m-1, p.d);
    if (now < thisYearBirthday) age -= 1;
    if (age < 0) age = 0;
    return age;
  }

  function ageToBucket(age){
    const n = Number(age);
    if (!isFinite(n) || n < 0) return '';
    if (n < 3) return 'baby';
    if (n < 12) return 'child';
    if (n < 18) return 'teen';
    return 'adult';
  }

  function parseCityInput(raw){
    const s = String(raw||'').trim();
    const parts = s.split(',').map(x=>x.trim()).filter(Boolean);
    const name = parts[0] || s;
    let country = null;
    if (parts.length >= 2) {
      const tail = parts[parts.length-1];
      country = /^[A-Za-z]{2}$/.test(tail) ? tail.toUpperCase() : tail;
    }
    return { name, country };
  }

  // City DB
let _cities = null;
let _citiesLoadError = false;

async function loadCities(){
  if (_cities) return _cities;
  if (_citiesLoadError) return [];

  const url =
    (window.ACS_CONFIG && window.ACS_CONFIG.citiesJsonUrl)
      ? window.ACS_CONFIG.citiesJsonUrl
      : (CFG && CFG.citiesUrl ? CFG.citiesUrl : null);

  if (!url) { _cities = []; return _cities; }

  try {
    const res = await fetch(url, { cache: 'force-cache' });
    _cities = res.ok ? await res.json() : [];
  } catch (e) {
    _citiesLoadError = true;
    _cities = [];
  }
  return _cities;
}

  async function resolveCityCoordsFromInput(cityLabel){
    // cityLabel like "London, GB" or "Beijing, CN"
    const s = String(cityLabel||'').trim();
    if (!s) return null;
    const parts = s.split(',').map(x=>x.trim()).filter(Boolean);
    const name = (parts[0] || s).toLowerCase();
    const country = (parts.length>=2 ? parts[parts.length-1] : '').toUpperCase();

    const cities = await loadCities();
    // Try exact match first
    for (let i=0;i<cities.length;i++){
      const row = normCityRow(cities[i]);
      const rn = String(row.name||'').trim().toLowerCase();
      const rc = String(row.country||'').trim().toUpperCase();
      if (rn === name && (!country || rc === country)) {
        return { name: row.name, country: row.country, lat: row.lat, lng: row.lng, tz: row.tz || '' };
      }
    }
    // Try startsWith match
    for (let i=0;i<cities.length;i++){
      const row = normCityRow(cities[i]);
      const rn = String(row.name||'').trim().toLowerCase();
      const rc = String(row.country||'').trim().toUpperCase();
      if (rn.startsWith(name) && (!country || rc === country)) {
        return { name: row.name, country: row.country, lat: row.lat, lng: row.lng, tz: row.tz || '' };
      }
    }
    return null;
  }

  function normCityRow(x){
    return {
      name: (x.name || x.city || x.n || '').toString(),
      country: (x.country || x.c || '').toString(),
      admin1: (x.admin1 || x.region || x.state || x.a1 || '').toString(),
      admin2: (x.admin2 || x.county || x.a2 || '').toString(),
      lat: (x.lat!=null?x.lat:(x.latitude!=null?x.latitude:null)),
      lng: (x.lng!=null?x.lng:(x.longitude!=null?x.longitude:null)),
      tz: (x.tz!=null?x.tz:(x.timezone!=null?x.timezone:''))
    };
  }

  async function getCityMatches(q, limit=20){
    const query = String(q||'').trim().toLowerCase();
    if (query.length < 1) return [];

    // "Fuse-like" fuzzy matching (no external dependency).
    // We approximate Fuse's threshold using normalized edit distance.
    const THRESHOLD = 0.3;
    const cities = await loadCities();

    function normText(s){
      return String(s||'')
        .toLowerCase()
        .replace(/[^a-z0-9\s,.-]/g,' ')
        .replace(/\s+/g,' ')
        .trim();
    }

    // Basic Levenshtein distance (iterative DP, memory optimized).
    function lev(a,b){
      a = String(a||'');
      b = String(b||'');
      const al = a.length, bl = b.length;
      if (!al) return bl;
      if (!bl) return al;
      // Ensure b is shorter for less memory
      if (bl > al) { const t=a; a=b; b=t; }
      const m = a.length, n = b.length;
      let prev = new Array(n+1);
      let cur  = new Array(n+1);
      for (let j=0;j<=n;j++) prev[j]=j;
      for (let i=1;i<=m;i++){
        cur[0]=i;
        const ca = a.charCodeAt(i-1);
        for (let j=1;j<=n;j++){
          const cost = (ca === b.charCodeAt(j-1)) ? 0 : 1;
          const ins = cur[j-1] + 1;
          const del = prev[j] + 1;
          const sub = prev[j-1] + cost;
          cur[j] = ins < del ? (ins < sub ? ins : sub) : (del < sub ? del : sub);
        }
        const tmp = prev; prev = cur; cur = tmp;
      }
      return prev[n];
    }

    const qn = normText(query);
    const qTokens = qn.split(' ').filter(Boolean);
    const qFirst = qTokens[0] || qn;
    const qShort = qFirst.slice(0, Math.min(3, qFirst.length));

    // 1) Fast pass: collect a limited candidate pool using cheap contains/prefix heuristics.
    const candidates = [];
    const MAX_POOL = 800; // keep fuzzy distance computation bounded
    for (let i=0;i<cities.length;i++){
      const c = normCityRow(cities[i]);
      const name = String(c.name||'').trim();
      if (!name) continue;
      const label = normText(`${name} ${c.admin1||''} ${c.country||''}`);

      // Cheap wins
      if (label.startsWith(qn) || label.includes(qn)) {
        candidates.push({ c, label, score: 0 });
      } else if (qShort && label.includes(qShort)) {
        // Rough filter to catch typos like "fransisco"
        candidates.push({ c, label, score: null });
      }

      if (candidates.length >= MAX_POOL) break;
    }

    // If pool is empty (rare), fall back to a tiny scan using first character.
    if (!candidates.length){
      const fc = qn[0] || '';
      for (let i=0;i<cities.length && candidates.length<MAX_POOL;i++){
        const c = normCityRow(cities[i]);
        const name = String(c.name||'').trim();
        if (!name) continue;
        const label = normText(`${name} ${c.admin1||''} ${c.country||''}`);
        if (fc && label[0] === fc) candidates.push({ c, label, score: null });
      }
    }

    // 2) Score candidates by normalized edit distance on the city name portion.
    // Prefer name matching, but allow admin1/country to help in the pool.
    const scored = [];
    for (let i=0;i<candidates.length;i++){
      const it = candidates[i];
      const c = it.c;
      const nameN = normText(c.name);

      let score = it.score;
      if (score !== 0){
        // Compare query to city name and also to full label, take best.
        const d1 = lev(qn, nameN);
        const s1 = d1 / Math.max(1, Math.max(qn.length, nameN.length));
        const d2 = lev(qn, it.label);
        const s2 = d2 / Math.max(1, Math.max(qn.length, it.label.length));
        score = Math.min(s1, s2);
      }

      // Token bonus: if all tokens appear somewhere in label, slightly improve score
      if (qTokens.length > 1){
        let all = true;
        for (const tk of qTokens){
          if (tk && !it.label.includes(tk)) { all=false; break; }
        }
        if (all) score = Math.max(0, score - 0.05);
      }

      if (score <= THRESHOLD) scored.push({ c, score });
    }

    scored.sort((a,b)=>a.score-b.score);
    return scored.slice(0, limit).map(x=>x.c);
  }

  function renderCitySuggestions(box, matches){
    if (!box) return;
    if (!matches || !matches.length){
      box.style.display='none';
      box.innerHTML='';
      return;
    }
    box.innerHTML = matches.map(c=>{
      const label = c.country ? `${c.name}, ${c.country}` : c.name;
      const meta = (c.lat!=null && c.lng!=null) ? `(${c.lat}, ${c.lng})` : '';
      return `<div class="acscalc__suggestion" data-city="${escapeHtml(label)}">
        ${escapeHtml(label)}${meta ? `<small>${escapeHtml(meta)}</small>` : ''}
      </div>`;
    }).join('');
    box.style.display='block';
  }

  async function postJson(url, payload){
    const headers = { 'Content-Type':'application/json' };
    try{
      const nonce = (CFG && CFG.auth && CFG.auth.restNonce) ? String(CFG.auth.restNonce) : '';
      if (nonce) headers['X-WP-Nonce'] = nonce;
    }catch(_){ }

    // If we are calling our own premium proxy and nonce is missing, try to refresh auth state once.
    try{
      const needsNonce = /\/wp-json\/acscalc\//.test(String(url||''));
      const hasNonce = !!headers['X-WP-Nonce'];
      if (needsNonce && !hasNonce) {
        const sUrl = (CFG && CFG.auth && CFG.auth.stateUrl) ? String(CFG.auth.stateUrl) : '';
        if (sUrl) {
          const r = await fetch(addCacheBuster(sUrl), { method:'GET', credentials:'include', cache:'no-store', headers: noCacheHeaders() }).catch(()=>null);
          if (r && r.ok) {
            const j = await r.json().catch(()=>null);
            if (j && j.restNonce) {
              CFG.auth = CFG.auth || {};
              CFG.auth.restNonce = String(j.restNonce);
              headers['X-WP-Nonce'] = String(j.restNonce);
            }
            if (j && typeof j.isLoggedIn === 'boolean') {
              CFG.auth = CFG.auth || {};
              CFG.auth.isLoggedIn = j.isLoggedIn;
            }
          }
        }
      }
    }catch(_){ }

    const res = await fetch(url, {
      method: 'POST',
      credentials: 'same-origin',
      headers,
      body: JSON.stringify(payload)
    });
    if (!res.ok){
      // Try to parse WP REST error payload for a cleaner message.
      let msg = '';
      let code = '';
      try{
        const j = await res.clone().json();
        if (j && j.message) msg = String(j.message);
        if (j && (j.code || (j.data && j.data.code) || (j.error && j.error.code))) code = String(j.code || (j.data && j.data.code) || (j.error && j.error.code));
      }catch(_){ }
      if (!msg) {
        const t = await res.text().catch(()=> '');
        msg = String(t || '').replace(/\s+/g,' ').trim();
      }
      const err = new Error(`Request failed (${res.status}). ${msg}`.slice(0, 260));
      err.status = res.status;
      if (code) err.code = code;
      throw err;
    }
    return res.json();
  }


// Chart POST helper: strict by default, but supports ENGINE_MISSING by computing in-browser (Moshier) if available.
async function postJsonChart(url, payload){
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type':'application/json' },
    body: JSON.stringify(payload)
  });

  if (res.ok) return res.json();

  // Try ENGINE_MISSING fallback (Swiss Ephemeris not installed on server).
  let data = null;
  try { data = await res.clone().json(); } catch(_){}

  if (res.status === 501 && data && data.error && data.error.code === 'ENGINE_MISSING') {
    if (window.ACS_Moshier && typeof window.ACS_Moshier.calculatePlanets === 'function') {
      const birth = payload && (payload.birth || payload.dob) ? (payload.birth || { date: payload.dob, time: payload.tob }) : null;
      const date = birth && birth.date ? String(birth.date) : '';
      const time = birth && birth.time ? String(birth.time) : '12:00';
      const city = payload && payload.city && typeof payload.city === 'object' ? payload.city : null;
      const lat = city && city.lat != null ? Number(city.lat) : Number(payload && payload.lat);
      const lng = city && city.lng != null ? Number(city.lng) : Number(payload && payload.lng);

      if (!date || !isFinite(lat) || !isFinite(lng)) {
        throw new Error('Chart request failed (ENGINE_MISSING) and client fallback is missing required inputs.');
      }

      function normLon(x){
        let v = Number(x);
        if (!isFinite(v)) return null;
        v = v % 360;
        if (v < 0) v += 360;
        return v;
      }
      function pickLon(obj){
        if (!obj || typeof obj !== 'object') return null;
        const candidates = [
          obj.longitude, obj.lon, obj.lng, obj.l, obj.L,
          obj.apparentLongitude, obj.apparent_longitude,
          obj.tropicalLongitude, obj.tropical_longitude,
          obj.position && obj.position.longitude,
          obj.position && obj.position.lon,
          obj.position && obj.position.L,
          obj.position && obj.position.apparentLongitude
        ];
        for (const c of candidates){
          const v = normLon(c);
          if (v !== null) return v;
        }
        return null;
      }

      // Prefer city timezone/offset when available; otherwise fall back to UTC.
      const cityTz = city && (city.tz || city.timezone) ? String(city.tz || city.timezone) : '';
      const tNorm = time && String(time).length === 5 ? `${time}:00` : String(time || '12:00:00');
      let iso = `${date}T${tNorm}Z`;
      try{
        if (cityTz && typeof Intl !== 'undefined' && Intl.DateTimeFormat) {
          const dtLocal = new Date(`${date}T${tNorm}`);
          const fmt = new Intl.DateTimeFormat('en-US', { timeZone: cityTz, year:'numeric', month:'2-digit', day:'2-digit', hour:'2-digit', minute:'2-digit', second:'2-digit', hour12:false });
          const parts = fmt.formatToParts(dtLocal).reduce((acc,p)=>{ acc[p.type]=p.value; return acc; }, {});
          const asUTC = Date.UTC(+parts.year, (+parts.month)-1, +parts.day, +parts.hour, +parts.minute, +parts.second);
          const localAsUTC = Date.UTC(+date.slice(0,4), (+date.slice(5,7))-1, +date.slice(8,10), +tNorm.slice(0,2), +tNorm.slice(3,5), +(tNorm.slice(6,8)||'0'));
          const diffMin = Math.round((localAsUTC - asUTC)/60000);
          const sign = diffMin <= 0 ? '+' : '-';
          const abs = Math.abs(diffMin);
          iso = `${date}T${tNorm}${sign}${String(Math.floor(abs/60)).padStart(2,'0')}:${String(abs%60).padStart(2,'0')}`;
        }
      }catch(_){ }
      const eph = await window.ACS_Moshier.calculatePlanets(iso, lat, lng, 'precise');


// --- Placidus houses + angles (no Swiss Ephemeris required) ---
// The project docs expect Placidus cusps; without server-side Swiss Ephemeris we compute them locally
// using standard astronomy formulas (LST + mean obliquity + Placidus time-division equation).
function __normLon(x){
  const v = Number(x);
  if (!isFinite(v)) return 0;
  let r = v % 360;
  if (r < 0) r += 360;
  return r;
}
function __rad(x){ return Number(x) * Math.PI / 180; }
function __deg(x){ return x * 180 / Math.PI; }
function __jdFromDateUTC(d){
  const y = d.getUTCFullYear();
  let m = d.getUTCMonth() + 1;
  const day = d.getUTCDate() + (d.getUTCHours() + (d.getUTCMinutes() + d.getUTCSeconds()/60)/60)/24;
  let Y = y, M = m;
  if (M <= 2){ Y -= 1; M += 12; }
  const A = Math.floor(Y/100);
  const B = 2 - A + Math.floor(A/4);
  const jd = Math.floor(365.25*(Y+4716)) + Math.floor(30.6001*(M+1)) + day + B - 1524.5;
  return jd;
}
function __meanObliquityDeg(T){
  const sec = 21.448 - 46.8150*T - 0.00059*T*T + 0.001813*T*T*T;
  return 23 + (26 + (sec/60))/60;
}
function __gmstDeg(jd){
  const T = (jd - 2451545.0) / 36525.0;
  const gmst = 280.46061837 + 360.98564736629*(jd - 2451545.0) + 0.000387933*T*T - (T*T*T)/38710000.0;
  return __normLon(gmst);
}

function __equalHouseFromAsc(asc, mc){
  asc = __normLon(asc);
  mc = __normLon(mc);
  const cusps = [];
  for (let i=0;i<12;i++) cusps.push(__normLon(asc + i*30));
  return {
    houses: { system: 'Equal', cusps: cusps.concat([cusps[0]]) },
    angles: { ascendant: asc, asc: asc, midheaven: mc, mc: mc, descendant: __normLon(asc+180), imumcoeli: __normLon(mc+180) }
  };
}
function __porphyryFromAngles(asc, mc){
  asc = __normLon(asc);
  mc = __normLon(mc);
  const dsc = __normLon(asc + 180);
  const ic = __normLon(mc + 180);
  function arc(a,b){ let d = __normLon(b) - __normLon(a); if (d < 0) d += 360; return d; }
  const q1 = arc(mc, asc), q2 = arc(asc, ic), q3 = arc(ic, dsc), q4 = arc(dsc, mc);
  const cusps = [];
  cusps[0] = asc;
  cusps[1] = __normLon(asc + q2/3);
  cusps[2] = __normLon(asc + 2*q2/3);
  cusps[3] = ic;
  cusps[4] = __normLon(ic + q3/3);
  cusps[5] = __normLon(ic + 2*q3/3);
  cusps[6] = dsc;
  cusps[7] = __normLon(dsc + q4/3);
  cusps[8] = __normLon(dsc + 2*q4/3);
  cusps[9] = mc;
  cusps[10] = __normLon(mc + q1/3);
  cusps[11] = __normLon(mc + 2*q1/3);
  return {
    houses: { system: 'Porphyry', cusps: cusps.concat([cusps[0]]) },
    angles: { ascendant: asc, asc: asc, midheaven: mc, mc: mc, descendant: dsc, imumcoeli: ic }
  };
}
function __cuspArc(a,b){ let d = __normLon(b) - __normLon(a); if (d < 0) d += 360; return d; }
function __looksEqualCusps(cusps){
  try{
    if (!Array.isArray(cusps) || cusps.length < 12) return false;
    const mods = cusps.slice(0,12).map(v => { v = __normLon(v); let m = v % 30; if (m < 0) m += 30; return m; });
    const min = Math.min.apply(null, mods), max = Math.max.apply(null, mods);
    return (max - min) < 0.3;
  }catch(_){ return false; }
}

function __pickCuspsFromEph(eph){
  try{
    const candidates = [];
    if (eph){
      candidates.push(
        eph.houses, eph.Houses, eph.cusps, eph.Cusps, eph.houseCusps, eph.house_cusps,
        eph.houses && eph.houses.cusps,
        eph.Houses && eph.Houses.cusps
      );
    }
    for (const c of candidates){
      if (!c) continue;
      if (Array.isArray(c)){
        const arr = c.slice(0,12).map(__normLon).filter(v => Number.isFinite(v));
        if (arr.length === 12) return arr;
      } else if (typeof c === 'object'){
        const arr = [];
        for (let i=1;i<=12;i++){
          const v = __normLon(c[i] ?? c[String(i)]);
          if (!Number.isFinite(v)) break;
          arr.push(v);
        }
        if (arr.length === 12) return arr;
      }
    }
  }catch(_){ }
  return null;
}
function __pickAnglesFromEph(eph, cusps){
  try{
    const asc = __normLon((eph && (eph.ascendant ?? eph.Ascendant ?? eph.ASC ?? eph.asc ?? (eph.angles && eph.angles.ascendant))) ?? (cusps ? cusps[0] : null));
    const mc = __normLon((eph && (eph.midheaven ?? eph.Midheaven ?? eph.MC ?? eph.mc ?? (eph.angles && eph.angles.midheaven))) ?? (cusps ? cusps[9] : null));
    if (!Number.isFinite(asc) || !Number.isFinite(mc)) return null;
    return { ascendant: asc, asc: asc, midheaven: mc, mc: mc, descendant: __normLon(asc+180), imumcoeli: __normLon(mc+180) };
  }catch(_){ return null; }
}
function __geoFromEph(eph){
  try{
    const cusps = __pickCuspsFromEph(eph);
    if (!cusps || __looksEqualCusps(cusps)) return null;
    const ang = __pickAnglesFromEph(eph, cusps);
    if (!ang) return null;
    return __sanitizeGeo({ houses:{ system:'Placidus', cusps: cusps.concat([cusps[0]]) }, angles: ang });
  }catch(_){ return null; }
}
function __sanitizeGeo(geo){
  try{
    const cusps = geo && geo.houses && Array.isArray(geo.houses.cusps) ? geo.houses.cusps.slice(0,12).map(__normLon) : null;
    const ang = geo && geo.angles ? geo.angles : {};
    const asc = __normLon(ang.ascendant != null ? ang.ascendant : ang.asc);
    const mc = __normLon(ang.midheaven != null ? ang.midheaven : ang.mc);
    if (!cusps || cusps.length < 12 || asc == null) return __porphyryFromAngles(asc||0, mc||0);
    let ok = !__looksEqualCusps(cusps);
    for (let i=0; ok && i<12;i++){
      const arc = __cuspArc(cusps[i], cusps[(i+1)%12]);
      if (!(arc > 0.5 && arc < 120)) { ok = false; break; }
    }
    for (let i=0; ok && i<6;i++){
      const oppErr = Math.abs(__cuspArc(cusps[i], cusps[(i+6)%12]) - 180);
      if (oppErr > 8) { ok = false; break; }
    }
    if (!ok) return __porphyryFromAngles(asc, mc||0);
    if (geo.angles){ if (geo.angles.asc == null && geo.angles.ascendant != null) geo.angles.asc = geo.angles.ascendant; if (geo.angles.mc == null && geo.angles.midheaven != null) geo.angles.mc = geo.angles.midheaven; }
    return geo;
  }catch(_){ return __porphyryFromAngles(0,0); }
}
function __placidusHousesFromPayload(dateStr, timeStr, latDeg, lonDeg){
  const t = String(timeStr||'');
  const isoZ = /Z$/.test(t) ? `${dateStr}T${t}` : `${dateStr}T${t}${t.length===5?':00':''}Z`;
  const d0 = new Date(isoZ);
  const jd = __jdFromDateUTC(d0);
  const TT = (jd - 2451545.0) / 36525.0;
  const eps = __meanObliquityDeg(TT);
  const lst = __normLon(__gmstDeg(jd) + Number(lonDeg||0)); // east positive

  const lstR = __rad(lst);
  const epsR = __rad(eps);
  const latR = __rad(Number(latDeg||0));

  const mc = __normLon(__deg(Math.atan2(Math.sin(lstR), Math.cos(lstR)*Math.cos(epsR))));
  const asc = __normLon(__deg(Math.atan2(
    -Math.cos(lstR),
    Math.sin(lstR)*Math.cos(epsR) + Math.tan(latR)*Math.sin(epsR)
  )));

  function __wrapPi(x){
    let v = x;
    while (v <= -Math.PI) v += 2*Math.PI;
    while (v > Math.PI) v -= 2*Math.PI;
    return v;
  }
  function __eclToEq(lamR){
    const sinLam = Math.sin(lamR);
    const cosLam = Math.cos(lamR);
    const sinEps = Math.sin(epsR);
    const cosEps = Math.cos(epsR);
    const ra = Math.atan2(sinLam*cosEps, cosLam);
    const dec = Math.asin(sinEps * sinLam);
    return { ra, dec };
  }
  function __semiDiurnalArc(decR){
    const t = -Math.tan(latR) * Math.tan(decR);
    if (t <= -1) return Math.PI;
    if (t >= 1) return 0;
    return Math.acos(t);
  }
  function __hourAngle(raR){ return __wrapPi(lstR - raR); }
  function __distForward(aDeg,bDeg){ return __normLon(bDeg - aDeg); }
  function __inArc(startDeg,endDeg,xDeg){
    const dSE = __distForward(startDeg,endDeg);
    const dSX = __distForward(startDeg,xDeg);
    return dSX >= 0 && dSX <= dSE + 1e-6;
  }

  function __findRootForCusp(mode, arcStartDeg, arcEndDeg){
    const k = (mode === '11') ? (1/3) : (mode === '12' ? (2/3) : (mode === '9' ? (-1/3) : (-2/3)));
    function f(lamDeg){
      const lamR = __rad(__normLon(lamDeg));
      const { ra, dec } = __eclToEq(lamR);
      const H = __hourAngle(ra);
      const sda = __semiDiurnalArc(dec);
      return H + (k * sda);
    }

    const roots = [];
    let prevX = 0;
    let prevF = f(0);
    const step = 1;
    for (let x = step; x <= 360; x += step){
      const curF = f(x);
      if (!isFinite(prevF) || !isFinite(curF)) { prevX = x; prevF = curF; continue; }
      if (prevF === 0) {
        roots.push(prevX);
      } else if (curF === 0 || (prevF < 0 && curF > 0) || (prevF > 0 && curF < 0)) {
        let a = prevX, b = x;
        let fa = prevF, fb = curF;
        for (let i=0;i<40;i++){
          const mid = (a+b)/2;
          const fm = f(mid);
          if (!isFinite(fm)) break;
          if (Math.abs(fm) < 1e-10) { a = b = mid; break; }
          if ((fa < 0 && fm > 0) || (fa > 0 && fm < 0)) { b = mid; fb = fm; }
          else { a = mid; fa = fm; }
        }
        roots.push((a+b)/2);
      }
      prevX = x;
      prevF = curF;
    }

    const filtered = roots.map(__normLon).filter(r => __inArc(arcStartDeg, arcEndDeg, r));
    const pool = filtered.length ? filtered : roots.map(__normLon);
    if (!pool.length) return null;
    let best = pool[0];
    let bestD = __distForward(arcStartDeg, best);
    for (const r of pool){
      const d = __distForward(arcStartDeg, r);
      if (d < bestD){ best = r; bestD = d; }
    }
    return best;
  }

  const desc = __normLon(asc + 180);
  const ic = __normLon(mc + 180);

  const cusp11 = __findRootForCusp('11', mc, asc);
  const cusp12 = __findRootForCusp('12', mc, asc);
  const cusp9  = __findRootForCusp('9',  mc, desc);
  const cusp8  = __findRootForCusp('8',  mc, desc);

  const cusp5 = cusp11 != null ? __normLon(cusp11 + 180) : null;
  const cusp6 = cusp12 != null ? __normLon(cusp12 + 180) : null;
  const cusp3 = cusp9  != null ? __normLon(cusp9  + 180) : null;
  const cusp2 = cusp8  != null ? __normLon(cusp8  + 180) : null;

  if ([cusp2,cusp3,cusp5,cusp6,cusp8,cusp9,cusp11,cusp12].some(v => v == null)) {
    return __porphyryFromAngles(asc, mc);
  }
  const cusps12 = [
    asc, cusp2, cusp3, ic, cusp5, cusp6, desc, cusp8, cusp9, mc, cusp11, cusp12
  ];

  return __sanitizeGeo({
    houses: { system: 'Placidus', cusps: cusps12.concat([cusps12[0]]) },
    angles: { ascendant: asc, asc: asc, midheaven: mc, mc: mc, descendant: desc, imumcoeli: ic }
  });
}

      const keys = ['sun','moon','mercury','venus','mars','jupiter','saturn','uranus','neptune','pluto'];
      const planets = [];
      for (const k of keys){
        const obj = (eph && (eph[k] || (eph.planets && eph.planets[k]) || (eph.Results && eph.Results[k]) || (eph.results && eph.results[k]))) || null;
        const lon = pickLon(obj);
        if (lon !== null){
          planets.push({ name: k.charAt(0).toUpperCase()+k.slice(1), key: k, longitude: lon });
        }
      }

      // Angles: best-effort from whatever the library returns.
      let asc = pickLon((eph && (eph.ascendant || eph.asc || eph.Asc || (eph.angles && eph.angles.ascendant))) || null);
asc = (asc == null) ? 0 : asc;
let mc  = pickLon((eph && (eph.midheaven || eph.mc || eph.MC || (eph.angles && eph.angles.midheaven))) || null);
mc = (mc == null) ? 0 : mc;

      if (!planets.length) {
        throw new Error('Chart request failed (ENGINE_MISSING) and client fallback could not compute any planetary longitudes.');
      }

      
// Prefer house cusps/angles provided by the ephemeris result when they are available and not equal-house-like.
// Only if missing or obviously degraded do we recompute locally.
let __geo = null;
try{ __geo = __geoFromEph(eph); }catch(e){ __geo = null; }
if (!__geo) {
  try{ __geo = __placidusHousesFromPayload(date, time, lat, lng); }catch(e){ __geo = null; }
}

const __planetsList = planets.map(p => Object.assign({}, p, { lon: p.longitude }));
const __planetsMap = {};
__planetsList.forEach(p => { __planetsMap[p.name] = { name:p.name, key:p.key, longitude:p.longitude, lon:p.longitude }; });
const __angles = (__geo && __geo.angles) ? Object.assign({}, __geo.angles) : {
  ascendant: asc,
  asc: asc,
  midheaven: mc,
  mc: mc,
  descendant: (asc + 180) % 360,
  imumcoeli: (mc + 180) % 360,
};
if (__angles.asc == null && __angles.ascendant != null) __angles.asc = __angles.ascendant;
if (__angles.ascendant == null && __angles.asc != null) __angles.ascendant = __angles.asc;
if (__angles.mc == null && __angles.midheaven != null) __angles.mc = __angles.midheaven;
if (__angles.midheaven == null && __angles.mc != null) __angles.midheaven = __angles.mc;
return {
  planets: __planetsList,
  planets_list: __planetsList,
  planets_map: __planetsMap,
  houses: (__geo && __geo.houses) ? __geo.houses : null,
  angles: __angles,
  aspects: [],
  meta: { engine: 'moshier-js-browser', lat, lng },
};
    }

    throw new Error('Chart request failed (ENGINE_MISSING). Client fallback is not available (ACS_Moshier not loaded).');
  }

  const t = await res.text().catch(()=> '');
  throw new Error(`Chart request failed (${res.status}). ${t}`.slice(0, 260));
}

  function pick(obj, paths, fallback=''){
    for (const p of paths){
      const parts = p.split('.');
      let v = obj;
      let ok = true;
      for (const k of parts){
        if (v && typeof v === 'object' && k in v) v = v[k];
        else { ok=false; break; }
      }
      if (ok && v != null && v !== '') return v;
    }
    return fallback;
  }

  function __parseSignPositionString(input){
    const s = String(input||'').trim();
    if (!s) return null;
    const signNames = [
      ['Aries','白羊','白羊座'], ['Taurus','金牛','金牛座'], ['Gemini','双子','双子座'], ['Cancer','巨蟹','巨蟹座'],
      ['Leo','狮子','狮子座'], ['Virgo','处女','处女座'], ['Libra','天秤','天秤座'], ['Scorpio','天蝎','天蝎座'],
      ['Sagittarius','射手','射手座'], ['Capricorn','摩羯','摩羯座'], ['Aquarius','水瓶','水瓶座'], ['Pisces','双鱼','双鱼座']
    ];
    let signIndex = -1;
    for (let i=0;i<signNames.length;i++){
      if (signNames[i].some(n=>s.toLowerCase().includes(String(n).toLowerCase()))){ signIndex = i; break; }
    }
    if (signIndex < 0) return null;
    const m = s.match(/(\d{1,2})(?:\D+?(\d{1,2}))?(?:\D+?(\d{1,2}))?/);
    if (!m) return null;
    const d = Number(m[1]||0), mm = Number(m[2]||0), ss = Number(m[3]||0);
    if (!isFinite(d) || d >= 30) return null;
    return signIndex*30 + d + mm/60 + ss/3600;
  }

  function parseLonFlexible(value){
    if (value == null) return null;
    if (typeof value === 'number' && isFinite(value)) return ((value%360)+360)%360;
    const s = String(value).trim();
    if (!s) return null;
    if (/^-?\d+(?:\.\d+)?$/.test(s)) return ((Number(s)%360)+360)%360;
    const signPos = __parseSignPositionString(s);
    if (signPos != null) return signPos;
    const abs = s.match(/(-?\d{1,3})(?:\D+?(\d{1,2}))?(?:\D+?(\d{1,2}))?/);
    if (abs){
      const d = Number(abs[1]||0), mm = Number(abs[2]||0), ss = Number(abs[3]||0);
      const x = d + mm/60 + ss/3600;
      if (isFinite(x)) return ((x%360)+360)%360;
    }
    return null;
  }

  function positionTextFromLon(lon){
    if (!isFinite(Number(lon))) return '';
    return `${signFromLon(lon)} ${formatDegInSign(lon)}`.trim();
  }

  function nakshatraInfoFromLon(lon){
    const x = ((Number(lon)%360)+360)%360;
    if (!isFinite(x)) return { name:'', lord:'' };
    const names = ['Ashwini','Bharani','Krittika','Rohini','Mrigashirsha','Ardra','Punarvasu','Pushya','Ashlesha','Magha','Purva Phalguni','Uttara Phalguni','Hasta','Chitra','Swati','Vishakha','Anuradha','Jyeshtha','Mula','Purva Ashadha','Uttara Ashadha','Shravana','Dhanishta','Shatabhisha','Purva Bhadrapada','Uttara Bhadrapada','Revati'];
    const lords = ['Ketu','Venus','Sun','Moon','Mars','Rahu','Jupiter','Saturn','Mercury'];
    const idx = Math.min(names.length-1, Math.floor(x / (360/27)));
    return { name:names[idx]||'', lord:lords[idx%9]||'' };
  }

  function chartHasUsablePlanets(chartN){
    const arr = chartN && Array.isArray(chartN.planetsArr) ? chartN.planetsArr : [];
    return arr.filter(p => p && isFinite(parseLonFlexible(p.longitude!=null ? p.longitude : (p.lon!=null ? p.lon : p.apparentLongitude)))).length >= 3;
  }

  function normalizeChart(chart){
    if (typeof chart === 'string') {
      try { chart = JSON.parse(chart); } catch(_){ return null; }
    }
    if (chart && typeof chart === 'object') {
      if (chart.chart && typeof chart.chart === 'object') chart = chart.chart;
      else if (chart.data && typeof chart.data === 'object' && chart.data.chart) chart = chart.data.chart;
      else if (chart.raw && typeof chart.raw === 'object') chart = chart.raw;
      else if (chart.payload && typeof chart.payload === 'object' && chart.payload.chart) chart = chart.payload.chart;
    }
    if (!chart || typeof chart !== 'object') return null;

    // Accept either:
    // 1) planets as array: [{name:"Sun", longitude:...}, ...]
    // 2) planets as object: {sun:{longitude...}, ...}
    let planetsArr = [];
    let planetsObj = {};
    const p = (chart.planets!=null)
      ? chart.planets
      : (chart.planetsArr!=null
          ? chart.planetsArr
          : (chart.planets_list!=null
              ? chart.planets_list
              : (chart.bodies!=null
                  ? chart.bodies
                  : (chart.points!=null ? chart.points : null))));
    if (Array.isArray(p)) {
      planetsArr = p.filter(Boolean);
      planetsArr.forEach(it=>{
        const n = String(it.name || it.key || '').trim();
        if (!n) return;
        const k = n.toLowerCase();
        planetsObj[k] = it;
      });
    } else if (p && typeof p === 'object') {
      planetsObj = p;
      Object.keys(p).forEach(k=>{
        const it = p[k];
        if (!it) return;
        planetsArr.push(Object.assign({ name: (it.name || k) }, it));
      });
    }

    
    // If planets were provided via planetsObj / planetsArr (already-normalized shapes), accept them.
    if ((!p || (Array.isArray(p) && planetsArr.length===0)) && chart.planetsObj && typeof chart.planetsObj==='object') {
      planetsObj = chart.planetsObj;
      planetsArr = [];
      Object.keys(planetsObj).forEach(k=>{
        const it = planetsObj[k];
        if (!it) return;
        planetsArr.push(Object.assign({ name: (it.name || k), key: k }, it));
      });
    }
    if ((!p || (Array.isArray(p) && planetsArr.length===0)) && chart.planets_map && typeof chart.planets_map==='object') {
      planetsObj = chart.planets_map;
      planetsArr = [];
      Object.keys(planetsObj).forEach(k=>{
        const it = planetsObj[k];
        if (!it) return;
        planetsArr.push(Object.assign({ name: (it.name || k), key: (it.key || k) }, it));
      });
    }

    // Normalize planetsObj keys to lower-case canonical form for lookups.
    try{
      const canon = {};
      Object.keys(planetsObj||{}).forEach(k=>{
        const kk = String(k||'').toLowerCase().trim();
        canon[kk] = planetsObj[k];
      });
      planetsObj = canon;
    }catch(_){ }
// Normalize longitude fields (support both `longitude` and legacy `lon`)
    planetsArr = planetsArr.map(it => {
      if (!it || typeof it !== 'object') return it;
      const rawLon = (it.longitude!=null) ? it.longitude : ((it.lon!=null)?it.lon:(it.apparentLongitude!=null?it.apparentLongitude:(it.absoluteLongitude!=null?it.absoluteLongitude:(it.pos_abs!=null?it.pos_abs:it.position))));
      const lon = parseLonFlexible(rawLon);
      const sign = it.sign || it.rasi || it.zodiac || '';
      const degInSign = parseLonFlexible(it.deg_in_sign!=null ? it.deg_in_sign : it.degree_in_sign);
      const out = Object.assign({}, it);
      if (lon!=null) out.longitude = lon;
      else if (sign && degInSign!=null){
        const signIdx = ['Aries','Taurus','Gemini','Cancer','Leo','Virgo','Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces'].findIndex(n => String(n).toLowerCase() === String(sign).trim().toLowerCase());
        if (signIdx >= 0) out.longitude = signIdx*30 + degInSign;
      }
      return out;
    });

    Object.keys(planetsObj || {}).forEach(k => {
      const it = planetsObj[k];
      if (!it || typeof it !== 'object') return;
      const rawLon = (it.longitude!=null) ? it.longitude : ((it.lon!=null)?it.lon:(it.apparentLongitude!=null?it.apparentLongitude:(it.absoluteLongitude!=null?it.absoluteLongitude:(it.pos_abs!=null?it.pos_abs:it.position))));
      const lon = parseLonFlexible(rawLon);
      if (lon!=null) it.longitude = lon;
    });

    return {
      raw: chart,
      planetsArr,
      planets: planetsArr,
      planetsObj,
      houses: chart.houses || null,
      angles: (function(a){
        a = (a && typeof a === 'object') ? Object.assign({}, a) : {};
        if (a.ascendant == null && a.asc != null) a.ascendant = a.asc;
        if (a.asc == null && a.ascendant != null) a.asc = a.ascendant;
        if (a.ascendant == null && a.Ascendant != null) a.ascendant = a.Ascendant;
        if (a.asc == null && a.ASC != null) a.asc = a.ASC;
        if (a.midheaven == null && a.mc != null) a.midheaven = a.mc;
        if (a.mc == null && a.midheaven != null) a.mc = a.midheaven;
        if (a.mc == null && a.MC != null) a.mc = a.MC;
        return a;
      })(chart.angles || chart.Angles || chart.points || null),
      aspects: chart.aspects || null,
      meta: chart.meta || null,
    };
  }

  function signFromLon(lon){
    const x = Number(lon);
    if (!isFinite(x)) return '';
    const idx = ((Math.floor(((x%360)+360)%360 / 30)) + 12) % 12;
    const names = ['Aries','Taurus','Gemini','Cancer','Leo','Virgo','Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces'];
    return names[idx] || '';
  }


  function houseFromCusps(lon, houses){
    try{
      const x = ((Number(lon)%360)+360)%360;
      const cusps = houses && houses.cusps ? houses.cusps : houses;
      if (!cusps || !Array.isArray(cusps) || cusps.length < 12) return null;
      const c12 = cusps.slice(0,12).map(v=>((Number(v)%360)+360)%360);
      for(let i=0;i<12;i++){
        const a = c12[i];
        const b = c12[(i+1)%12];
        if (a <= b) {
          if (x >= a && x < b) return i+1;
        } else {
          // wrap
          if (x >= a || x < b) return i+1;
        }
      }
      return 1;
    }catch(_){
      return null;
    }
  }

  function formatAspect(a){
    if (!a) return '';
    const p1 = a.p1 || a.planet1 || a.from || '';
    const p2 = a.p2 || a.planet2 || a.to || '';
    const type = (a.type || '').toLowerCase();
    const orb = (a.orb!=null && isFinite(Number(a.orb))) ? Number(a.orb) : null;
    const typeMap = {
      conjunction: 'conjunct',
      sextile: 'sextile',
      square: 'square',
      trine: 'trine',
      opposition: 'opposition'
    };
    const t = typeMap[type] || type;
    const o = (orb!=null) ? ` (orb ${orb.toFixed(1)}°)` : '';
    return `${p1} ${t} ${p2}${o}`.trim();
  }

  

function formatAspectEN(a){
  if (!a) return '';
  const pMap = {
    sun: 'Sun', moon: 'Moon', mercury:'Mercury', venus:'Venus', mars:'Mars',
    jupiter:'Jupiter', saturn:'Saturn', uranus:'Uranus', neptune:'Neptune', pluto:'Pluto',
    asc:'Ascendant', ascendant:'Ascendant', mc:'Midheaven', midheaven:'Midheaven'
  };

  const tMap = {
    conjunction: 'conjunction',
    sextile: 'sextile',
    square: 'square',
    trine: 'trine',
    opposition: 'opposition'
  };

  const p1k = String(a.p1 || a.planet1 || a.from || '').toLowerCase();
  const p2k = String(a.p2 || a.planet2 || a.to || '').toLowerCase();

  // aspect type can come in various spellings
  const rawType = String(a.type || a.aspect || a.name || a.kind || '').toLowerCase().trim();
  const typeKey = (
    rawType.includes('conj') ? 'conjunction' :
    rawType.includes('sext') ? 'sextile' :
    rawType.includes('sqr') || rawType.includes('square') ? 'square' :
    rawType.includes('tri') ? 'trine' :
    rawType.includes('opp') ? 'opposition' :
    rawType
  );

  const P1 = pMap[p1k] || (a.p1 || a.planet1 || 'Planet1');
  const P2 = pMap[p2k] || (a.p2 || a.planet2 || 'Planet2');
  const T  = tMap[typeKey] || (a.type || a.aspect || 'aspect');

  const orb = Number(a.orb);
  const orbTxt = isFinite(orb) ? ` (orb ${Math.abs(orb).toFixed(1)}°)` : '';

  return `${P1} ${T} ${P2}${orbTxt}`;
}

function renderChartSvg(chartN){
  if (!chartN || !chartN.planetsArr || !chartN.planetsArr.length) return '';

  const ang = chartN.angles || {};

  function pickFinite(){
    for (let i=0;i<arguments.length;i++){
      const v = arguments[i];
      if (v !== undefined && v !== null && isFinite(Number(v))) return Number(v);
    }
    return null;
  }

  const asc = pickFinite(ang.ascendant, ang.asc, ang.Asc, ang.ASC);

  function signInfo(lon){
    const x = ((Number(lon)%360)+360)%360;
    const idx = Math.floor(x/30);
    const degIn = x - idx*30;
    const namesEn = ['Aries','Taurus','Gemini','Cancer','Leo','Virgo','Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces'];
    return { idx, degIn, name: namesEn[idx]||'' };
  }

  function formatPos(lon){
    if (!isFinite(Number(lon))) return '';
    const s = signInfo(lon);
    return `${s.name} ${s.degIn.toFixed(0)}°`;
  }

  const POI = [
    { key:'sun',  icon:'☉', label:'Sun' },
    { key:'moon', icon:'☽', label:'Moon' },
    { key:'asc',  icon:'↑', label:'Ascendant' },
    { key:'mercury', icon:'☿', label:'Mercury' },
    { key:'venus', icon:'♀', label:'Venus' },
    { key:'mars',  icon:'♂', label:'Mars' },
  ];

  function getLonFor(key){
    if (key === 'asc') return (asc != null) ? asc : null;
    const obj = chartN.planetsObj || {};
    const it = obj[key] || obj[key.toUpperCase()] || null;
    const lon = it ? Number(it.longitude) : NaN;
    return isFinite(lon) ? lon : null;
  }

  let rows = POI.map(it=>{
    const lon = getLonFor(it.key);
    if (lon == null) return '';
    const value = formatPos(lon);
    return `
      <div class="acscalc__coreRow">
        <div class="acscalc__coreIcon">${escapeHtml(it.icon)}</div>
        <div class="acscalc__coreLabel">${escapeHtml(it.label)}：</div>
        <div class="acscalc__coreValue">${escapeHtml(value)}</div>
      </div>
    `;
  }).filter(Boolean).join('');

  // ---- Derived Sun factors (house + key aspect) ----
  // Keep these inside the same "core table" to avoid duplicate debug-style lines below.
  try{
    const sunLon = getLonFor('sun');
    if (sunLon != null){
      const sunHouse = houseFromCusps(sunLon, chartN && chartN.houses);
      if (sunHouse != null){
        // Append as an extra row (no separate section below).
        rows += `
          <div class="acscalc__coreRow">
            <div class="acscalc__coreIcon">⌂</div>
            <div class="acscalc__coreLabel">Sun House:</div>
            <div class="acscalc__coreValue">House ${escapeHtml(String(sunHouse))}</div>
          </div>
        `;
      }

      const aspects = (chartN && chartN.aspects && Array.isArray(chartN.aspects)) ? chartN.aspects : [];
      const keyAspects = aspects
        .filter(a=>{
          const p1 = String(a.p1 || a.planet1 || a.from || '').toLowerCase();
          const p2 = String(a.p2 || a.planet2 || a.to || '').toLowerCase();
          return p1 === 'sun' || p2 === 'sun';
        })
        .sort((a,b)=> (Number(a.orb||999) - Number(b.orb||999)))
        .slice(0,1) // only show the closest aspect to match UI requirement
        .map(formatAspectEN)
        .filter(Boolean);

      if (keyAspects.length){
        rows += `
          <div class="acscalc__coreRow">
            <div class="acscalc__coreIcon">✦</div>
            <div class="acscalc__coreLabel">Sun Aspect:</div>
            <div class="acscalc__coreValue">${escapeHtml(keyAspects.join(' • '))}</div>
          </div>
        `;
      }
    }
  }catch(_){}

  if (!rows) return '';

  // 只返回“Natal Chart Key Data”样式表格（不展示算法中间态）
  return `
    <details class="acscalc__coreCard acscalc__coreDetails">
      <summary class="acscalc__coreHead">
        <div class="acscalc__coreBadge">⌖</div>
        <div class="acscalc__coreTitle">Natal Chart Key Data</div>
        <div class="acscalc__coreChevron" aria-hidden="true">▾</div>
      </summary>
      <div class="acscalc__coreTable">
        ${rows}
      </div>
    </details>
  `;
}


function renderProducts(products){
    const items = (Array.isArray(products) ? products : []).slice(0, 8);
    if (!items.length) return '<p style="color:#666;margin:6px 0 0 0;">No displayable products found (may be age-gated).</p>';
    const cards = items.map(p=>{
      const title = escapeHtml(p.title || p.name || 'Product');
      const url = escapeHtml(p.url || '#');
      const img = p.img ? `<img src="${escapeHtml(p.img)}" alt=""/>` : '';
      const price = p.price ? `<p>${escapeHtml(String(p.price))}</p>` : `<p>View details</p>`;
      return `<div class="acscalc__card acscalc__product">${img}<a href="${url}" target="_blank" rel="noopener noreferrer">${title}</a>${price}</div>`;
    }).join('');
    return `<div class="acscalc__products">${cards}</div>`;
  }

  function savePlan(mode, payload, data){
    try{
      const key = 'acscalc_saved_plans_v1';
      const arr = JSON.parse(localStorage.getItem(key) || '[]');
      arr.unshift({ ts: Date.now(), mode, payload, data });
      localStorage.setItem(key, JSON.stringify(arr.slice(0, 20)));
      return true;
    }catch(e){
      return false;
    }
  }

  // 显示星盘解读弹窗
  async function showNatalInterpretationModal(chartN, payload){
    // Prevent multi-click races / duplicate modals
    try{
      if (window.__ACSCALC_NATAL_MODAL_OPENING__) return;
      if (document.getElementById('natalInterpretationModal')) return;
      window.__ACSCALC_NATAL_MODAL_OPENING__ = true;
      // Safety: never keep the lock forever
      setTimeout(()=>{ try{ window.__ACSCALC_NATAL_MODAL_OPENING__ = false; }catch(_){ } }, 5000);
    }catch(_){ }

    // 调试日志
    console.log('[Natal Interpretation] function called', {
      hasChartN: !!chartN,
      hasPayload: !!payload,
      hasTemplates: !!(payload && payload.natal_chart_templates),
      templateKeys: payload && payload.natal_chart_templates ? Object.keys(payload.natal_chart_templates) : []
    });

    // 获取星盘解读话术模板
    const templates = (payload && payload.natal_chart_templates) || {};
    
    // 如果没有模板数据，允许空展示（入口仍可打开）
    if (!templates || Object.keys(templates).length === 0) {
      console.warn('[Natal Interpretation] No template copy found (empty display is allowed). Please configure natal chart copy in WP admin.');
    }

// 获取星盘数据
    const planetsObj = (chartN && chartN.planetsObj) || {};
    const angles = (chartN && chartN.angles) || {};
    const aspects = (chartN && chartN.aspects) || [];

    // 提取行星数据
    const sunLon = planetsObj.sun ? planetsObj.sun.longitude : null;
    const moonLon = planetsObj.moon ? planetsObj.moon.longitude : null;
    const mercuryLon = planetsObj.mercury ? planetsObj.mercury.longitude : null;
    const venusLon = planetsObj.venus ? planetsObj.venus.longitude : null;
    const marsLon = planetsObj.mars ? planetsObj.mars.longitude : null;
    const ascLon = angles.ascendant != null ? angles.ascendant : null;

    // 转换为星座
    const sunSign = sunLon != null ? signFromLon(sunLon) : '';
    const moonSign = moonLon != null ? signFromLon(moonLon) : '';
    const ascSign = ascLon != null ? signFromLon(ascLon) : '';
    const mercurySign = mercuryLon != null ? signFromLon(mercuryLon) : '';
    const venusSign = venusLon != null ? signFromLon(venusLon) : '';
    const marsSign = marsLon != null ? signFromLon(marsLon) : '';

    // Template library for nested placeholders (e.g., {{action_career_01}})
    const tplLib = (payload && payload.templates) ? payload.templates : ((window.ACSCALC && window.ACSCALC.templates) ? window.ACSCALC.templates : {});
    const tplCtx = {
      sunSign: sunSign, sun_sign: sunSign,
      moonSign: moonSign, moon_sign: moonSign,
      risingSign: ascSign, rising_sign: ascSign, ascSign: ascSign
    };

    // 获取太阳宫位
    const sunHouse = sunLon != null ? houseFromCusps(sunLon, chartN && chartN.houses) : null;

    // 获取太阳相位
    const sunAspects = aspects
      .filter(a => {
        const p1 = String(a.p1 || a.planet1 || a.from || '').toLowerCase();
        const p2 = String(a.p2 || a.planet2 || a.to || '').toLowerCase();
        return p1 === 'sun' || p2 === 'sun';
      })
      .sort((a, b) => (Number(a.orb || 999) - Number(b.orb || 999)))
      .slice(0, 1)
      .map(formatAspectEN)
      .filter(Boolean);
    const sunAspect = sunAspects.length > 0 ? sunAspects[0] : '';

    // -----------------------------
    // Customer doc update:
    // Natal interpretation only needs 3 outputs now:
    //   {{sun_emotion_random}}, {{moon_emotion_random}}, {{rising_emotion_random}}
    // We resolve them by pulling the corresponding EMO pool variables
    // (emo_zod_{sign}_01..03) via backend /acs/v1/vars.
    // -----------------------------
    const __VAR_CACHE__ = window.__ACSCALC_VAR_CACHE__ = window.__ACSCALC_VAR_CACHE__ || {};

    function signToEmoKey(sign){
      const s = String(sign||'').toLowerCase().trim();
      const map = {
        aries:'aries', taurus:'taurus', gemini:'gemini', cancer:'cancer', leo:'leo', virgo:'virgo',
        libra:'libra', scorpio:'scorpio', sagittarius:'sag', capricorn:'cap', aquarius:'aqu', pisces:'pis',
        sag:'sag', cap:'cap', aqu:'aqu', pis:'pis'
      };
      return map[s] || '';
    }

    async function fetchVars(codes){
      const need = (codes||[]).filter(c => c && !Object.prototype.hasOwnProperty.call(__VAR_CACHE__, c));
      if (need.length === 0) return __VAR_CACHE__;
      try{
        const base = (CFG && CFG.siteUrl) ? String(CFG.siteUrl).replace(/\/$/,'') : (window.location.origin || '');
        const url = base + '/wp-json/acs/v1/vars?codes=' + encodeURIComponent(need.join(',')) + '&locale=' + encodeURIComponent('en-US');
        const res = await fetch(addCacheBuster(url), { method:'GET', credentials:'include', cache:'no-store', headers: noCacheHeaders() });
        if (!res.ok) return __VAR_CACHE__;
        const j = await res.json();
        const vars = (j && j.vars && typeof j.vars === 'object') ? j.vars : {};
        Object.keys(vars).forEach(k => { __VAR_CACHE__[k] = String(vars[k] ?? ''); });
      }catch(_){ }
      return __VAR_CACHE__;
    }

    async function pickZodiacEmoCopy(sign){
      const key = signToEmoKey(sign);
      if (!key) return '';
      const codes = [`emo_zod_${key}_01`,`emo_zod_${key}_02`,`emo_zod_${key}_03`];
      await fetchVars(codes);
      // random pick with fallback
      const start = Math.floor(Math.random()*3);
      const order = [start,(start+1)%3,(start+2)%3];
      for (const i of order){
        const v = String(__VAR_CACHE__[codes[i]] || '').trim();
        // Some sites may accidentally leave the variable value as its own code (e.g. "emo_zod_aries_01").
        // Treat that as invalid and keep falling back to the other items.
        if (!v) continue;
        const vv = v.toLowerCase();
        const cc = String(codes[i]||'').toLowerCase();
        if (vv === cc) continue;
        if (/^emo_zod_[a-z]+_(0[1-3])$/.test(vv)) continue;
        return v;
      }
      return '';
    }

    // 先渲染弹窗骨架（避免等待话术导致弹窗打开很慢）
    const modalHtml = `
      <div class="acscalc__modal" id="natalInterpretationModal" style="
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.8);
        z-index: 10000;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
        box-sizing: border-box;
      ">
        <div class="acscalc__modalContent" style="
          background: #1a1a2e;
          border-radius: 16px;
          max-width: 800px;
          width: 100%;
          max-height: 90vh;
          overflow-y: auto;
          padding: 32px;
          position: relative;
          box-shadow: 0 10px 40px rgba(0, 0, 0, 0.5);
        ">
          <button class="acscalc__modalClose" style="
            position: absolute;
            top: 16px;
            right: 16px;
            background: transparent;
            border: none;
            color: rgba(255, 255, 255, 0.6);
            font-size: 28px;
            cursor: pointer;
            padding: 0;
            width: 32px;
            height: 32px;
            line-height: 32px;
            text-align: center;
            transition: color 0.2s;
          " onmouseover="this.style.color='rgba(255,255,255,1)'" onmouseout="this.style.color='rgba(255,255,255,0.6)'">
            ×
          </button>

          <h2 style="
            color: #fff;
            font-size: 24px;
            font-weight: 600;
            margin: 0 0 24px 0;
            text-align: center;
          ">🌟 Natal Chart Interpretation</h2>

          <div id="acscalcNatalItemsHost" style="display:grid;gap:16px;">
            <div style="color:rgba(255,255,255,.75);font-size:14px;">Loading…</div>
          </div>
        </div>
      </div>
    `;
    // 添加弹窗到页面
    const modalContainer = document.createElement('div');
    modalContainer.innerHTML = modalHtml;
    document.body.appendChild(modalContainer);

    // Fetch rendered interpretation items from backend (module-based, editable in admin)
    (async function(){
      try{
        const base = (CFG && CFG.siteUrl) ? String(CFG.siteUrl).replace(/\/$/,'') : (window.location.origin || '');
        const url = base + '/wp-json/acs/v1/natal-interpretation';
        const body = {
          sun_sign: sunSign,
          moon_sign: moonSign,
          rising_sign: ascSign,
          locale: 'en-US'
        };
        const res = await fetch(addCacheBuster(url), {
          method: 'POST',
          credentials: 'include',
          headers: Object.assign({'Content-Type':'application/json'}, noCacheHeaders()),
          body: JSON.stringify(body)
        });
        const j = await res.json();
        let items = [];
        if (j && Array.isArray(j.items)) {
          items = j.items.map((it, idx)=>({
            title: (it && (it.title || it.label)) ? String(it.title || it.label) : ('Item ' + (idx+1)),
            text: (it && it.text) ? String(it.text) : ''
          })).filter(it=>it.text.trim().length);
        } else if (j && (j.sun || j.moon || j.ascendant)) {
          // legacy fallback
          if (j.sun && j.sun.text) items.push({ title:'Sun', text: String(j.sun.text) });
          if (j.moon && j.moon.text) items.push({ title:'Moon', text: String(j.moon.text) });
          if (j.ascendant && j.ascendant.text) items.push({ title:'Ascendant', text: String(j.ascendant.text) });
        }

        const host = document.getElementById('acscalcNatalItemsHost');
        if (!host) return;

        if (!items.length){
          host.innerHTML = '<div style="color:rgba(255,255,255,.75);font-size:14px;">No interpretation items configured.</div>';
          return;
        }

        const ICONS = { sun:'☀️', moon:'🌙', ascendant:'↗️', rising:'↗️' };
        host.innerHTML = items.map(it=>{
          return `
            <div style="
              background: rgba(255, 255, 255, 0.05);
              border-radius: 12px;
              padding: 20px;
              border: 1px solid rgba(255, 255, 255, 0.1);
            ">
              <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;">
                <span style="font-size:24px;">${ICONS[String(it.title||'').toLowerCase()] || '✨'}</span>
                <div style="flex:1;">
                  <div style="color:rgba(255,255,255,.7);font-size:14px;font-weight:500;margin-bottom:4px;">${escapeHtml(String(it.title||''))}</div>
                  <div style="color:#fff;font-size:18px;font-weight:600;">${escapeHtml(sunSign && /sun/i.test(it.title) ? sunSign : (moonSign && /moon/i.test(it.title) ? moonSign : (ascSign && /asc|rising/i.test(it.title) ? ascSign : '')))}</div>
                </div>
              </div>
              <div style="color:rgba(255,255,255,.8);font-size:14px;line-height:1.6;margin-top:12px;padding-top:12px;border-top:1px solid rgba(255,255,255,.1);">
                ${mdToHtml(String(it.text||''))}
              </div>
            </div>
          `;
        }).join('');
      }catch(e){
        console.warn('[Natal Interpretation] backend fetch failed', e);
        const host = document.getElementById('acscalcNatalItemsHost');
        if (host) host.innerHTML = '<div style="color:rgba(255,255,255,.75);font-size:14px;">Failed to load interpretation.</div>';
      } finally {
        try{ window.__ACSCALC_NATAL_MODAL_OPENING__ = false; }catch(_){}
      }
    })();

    // Lock background scroll while modal open
    const __prevOverflow = document.documentElement.style.overflow;
    document.documentElement.style.overflow = 'hidden';

    // 添加关闭事件
    const modal = document.getElementById('natalInterpretationModal');
    const closeBtn = modal.querySelector('.acscalc__modalClose');
    
    let __natalModalClosed = false;
    const closeModal = () => {
      if (__natalModalClosed) return;
      __natalModalClosed = true;
      try{ modal.style.opacity = '0'; }catch(_){ }
      try{ document.removeEventListener('keydown', __onNatalKeyDown); }catch(_){ }
      // Clear opening flag early so user can reopen if needed
      try{ window.__ACSCALC_NATAL_MODAL_OPENING__ = false; }catch(_){ }
      setTimeout(() => {
        try{ modalContainer.remove(); }catch(_){
          try{ document.body.removeChild(modalContainer); }catch(__){}
        }
        try{ document.documentElement.style.overflow = __prevOverflow || ''; }catch(_){ }
      }, 220);
    };

    if (closeBtn) {
      closeBtn.addEventListener('click', (e)=>{
        try{ e.preventDefault(); e.stopPropagation(); }catch(_){ }
        closeModal();
      }, { once:true });
    }
    modal.addEventListener('click', (e) => {
      if (e.target === modal) closeModal();
    });

    // ESC to close (ensure listener is cleaned up on any close path)
    const __onNatalKeyDown = function(e){
      if (e && e.key === 'Escape'){
        closeModal();
      }
    };
    document.addEventListener('keydown', __onNatalKeyDown);

    // 异步加载话术（避免阻塞弹窗打开）
    (async ()=>{
      try{
        const results = await Promise.allSettled([
          pickZodiacEmoCopy(sunSign),
          pickZodiacEmoCopy(moonSign),
          pickZodiacEmoCopy(ascSign),
        ]);
        const sunCopy = (results[0] && results[0].status === 'fulfilled') ? (results[0].value||'') : '';
        const moonCopy = (results[1] && results[1].status === 'fulfilled') ? (results[1].value||'') : '';
        const ascCopy = (results[2] && results[2].status === 'fulfilled') ? (results[2].value||'') : '';
        const map = { sun: sunCopy, moon: moonCopy, asc: ascCopy };
        // Modal may have been closed already
        if (!modal || __natalModalClosed) return;
        modal.querySelectorAll('.acscalc__natalCopy').forEach(node=>{
          const k = node.getAttribute('data-natal-key') || '';
          const v = (k && map[k]) ? String(map[k]) : '';
          if (v){
            node.textContent = v;
            node.style.display = '';
          }else{
            node.textContent = '';
            node.style.display = 'none';
          }
        });
      }catch(_){}
    })();

    // 添加渐入动画
    modal.style.opacity = '0';
    modal.style.transition = 'opacity 0.2s';
    setTimeout(() => {
      modal.style.opacity = '1';
    }, 10);

    // Clear opening flag
    try{ window.__ACSCALC_NATAL_MODAL_OPENING__ = false; }catch(_){ }
  }

  
  // ============================================================
  // Natal Modules (V2) - render configurable chart/interpretation blocks
  // ============================================================
  const _natalModsCache = { loaded:false, loading:false, data:null, err:null };

  function formatDMS(deg){
    const x = ((Number(deg)%360)+360)%360;
    const d = Math.floor(x);
    const mFloat = (x - d) * 60;
    const m = Math.floor(mFloat);
    const s = Math.round((mFloat - m) * 60);
    return `${d}°${m}'${s}"`;
  }
  function formatDegInSign(deg){
    const x = ((Number(deg)%360)+360)%360;
    const dIn = x - Math.floor(x/30)*30;
    const d = Math.floor(dIn);
    const mFloat = (dIn - d) * 60;
    const m = Math.floor(mFloat);
    return `${d}°${m}'`;
  }
  function signLordEn(sign){
    const m = {
      'Aries':'Mars','Taurus':'Venus','Gemini':'Mercury','Cancer':'Moon','Leo':'Sun','Virgo':'Mercury',
      'Libra':'Venus','Scorpio':'Mars','Sagittarius':'Jupiter','Capricorn':'Saturn','Aquarius':'Saturn','Pisces':'Jupiter'
    };
    return m[sign] || '';
  }

  function approxMeanNodeLonFromJd(jd){
    const T = (Number(jd) - 2451545.0) / 36525.0;
    let lon = 125.04452 - 1934.136261 * T + 0.0020708 * T * T + (T * T * T) / 450000.0;
    lon = ((lon % 360) + 360) % 360;
    return lon;
  }

  function birthToJulianDayUTC(payload){
    try{
      const birth = payload && (payload.birth || (payload.dob ? { date: payload.dob, time: payload.tob } : null));
      if (!birth) return null;
      const date = String(birth.date || '').trim();
      const time = String(birth.time || '').trim() || '12:00';
      if (!date) return null;
      const dt = new Date(`${date}T${time.length===5?time+':00':time}Z`);
      if (isNaN(dt.getTime())) return null;
      return (dt.getTime() / 86400000) + 2440587.5;
    }catch(_){ return null; }
  }

  function fallbackNodePlanet(chartN, key, payload){
    const k = String(key||'').toLowerCase().trim();
    if (k !== 'rahu' && k !== 'ketu') return null;
    let base = null;
    try{
      const obj = chartN && chartN.planetsObj ? chartN.planetsObj : {};
      const rahu = obj.rahu || obj.northnode || obj.north_node || null;
      const ketu = obj.ketu || obj.southnode || obj.south_node || null;
      if (k === 'rahu' && ketu && isFinite(parseLonFlexible(ketu.longitude!=null?ketu.longitude:ketu.lon))) {
        base = ((Number(parseLonFlexible(ketu.longitude!=null?ketu.longitude:ketu.lon)) + 180) % 360 + 360) % 360;
      }
      if (k === 'ketu' && rahu && isFinite(parseLonFlexible(rahu.longitude!=null?rahu.longitude:rahu.lon))) {
        base = ((Number(parseLonFlexible(rahu.longitude!=null?rahu.longitude:rahu.lon)) + 180) % 360 + 360) % 360;
      }
    }catch(_){ }
    if (base == null) {
      const jd = (chartN && chartN.meta && isFinite(Number(chartN.meta.jd))) ? Number(chartN.meta.jd) : birthToJulianDayUTC(payload);
      if (jd != null) {
        const rahuLon = approxMeanNodeLonFromJd(jd);
        base = (k === 'rahu') ? rahuLon : (((rahuLon + 180) % 360) + 360) % 360;
      }
    }
    if (!isFinite(Number(base))) return null;
    return { name: (k==='rahu'?'Rahu':'Ketu'), key: k, longitude: Number(base) };
  }

  function getPlanetObj(chartN, key){
    if (!chartN) return null;
    const k = String(key||'').toLowerCase().trim();

    // Angles (ASC is treated like a "planet" row in tables)
    if (k === 'ascendant' || k === 'asc'){
      const ang = chartN.angles || {};
      const asc = (ang.ascendant!=null)?ang.ascendant:(ang.asc!=null?ang.asc:null);
      if (!isFinite(Number(asc))) return null;
      return { name:'Ascendant', key:'ascendant', longitude:Number(asc) };
    }

    // 1) Preferred legacy shape: planetsObj.{sun,moon,...}
    const obj = chartN.planetsObj || {};
    let it = obj[k] || obj[k.toLowerCase()] || obj[k.toUpperCase()] || null;

    // 2) Newer/common shape: planets: [{name:'Sun', longitude:...}, ...]
    const _plist = Array.isArray(chartN.planetsArr) ? chartN.planetsArr : (Array.isArray(chartN.planets) ? chartN.planets : null);
    if (!it && Array.isArray(_plist)){
      const normName = (s)=>String(s||'').toLowerCase().replace(/\s+/g,'').replace(/[^a-z]/g,'');
      const want = normName(k);
      // common aliases
      const aliasMap = {
        rahu: ['rahu','northnode','northlunar','ascendingnode','meanlilith'],
        ketu: ['ketu','southnode','southlunar','descendingnode'],
        jupiter: ['jupiter'],
        saturn: ['saturn'],
        mercury:['mercury'],
        venus:['venus'],
        mars:['mars'],
        sun:['sun','sol'],
        moon:['moon','luna'],
        uranus:['uranus'],
        neptune:['neptune'],
        pluto:['pluto'],
      };
      const wants = new Set([want, ...(aliasMap[want]||[])].map(normName));
      it = _plist.find(p=>{
        const n = normName(p && (p.key || p.name || p.planet || p.id));
        return wants.has(n);
      }) || null;
    }

    if (!it) {
      const fbNode = fallbackNodePlanet(chartN, k, (chartN && chartN.__payload) ? chartN.__payload : null);
      if (fbNode) it = fbNode;
    }
    if (!it) return null;
    const lon = parseLonFlexible((it.longitude!=null)?it.longitude:((it.lon!=null)?it.lon:(it.apparentLongitude!=null?it.apparentLongitude:(it.absoluteLongitude!=null?it.absoluteLongitude:(it.pos_abs!=null?it.pos_abs:it.position)))));
    if (!isFinite(Number(lon))) return null;
    return Object.assign({ key:k }, it, { longitude:Number(lon) });
  }

  function buildNatalCtx(chartN, payload, data){
    // Context object used to resolve {{placeholders}} inside natal modules.
    // Important: backend recommend endpoint may provide a `context` map (e.g. crystal_*).
    const ctx = {};
    try{ ctx.__chartN = chartN || null; }catch(_){ }
    try{ ctx.__payload = payload || null; }catch(_){ }
    try{ if (chartN && typeof chartN === 'object') chartN.__payload = payload || null; }catch(_){ }

    // Merge backend-provided context first so chart-derived fields can override when needed.
    try{
      const backendCtx = data && typeof data === 'object' ? (data.context || (data.result && data.result.context) || null) : null;
      if (backendCtx && typeof backendCtx === 'object') {
        Object.keys(backendCtx).forEach(k=>{ ctx[k] = backendCtx[k]; });
      }
    }catch(_){ }
    // signs/positions for major bodies
    const keys = ['sun','moon','mercury','venus','mars','jupiter','saturn','uranus','neptune','pluto','rahu','ketu','ascendant','mc'];
    keys.forEach(k=>{
      const it = (k==='mc') ? null : getPlanetObj(chartN, k);
      if (it && isFinite(Number(it.longitude))){
        const lon = Number(it.longitude);
        const sign = signFromLon(lon);
        const nk = nakshatraInfoFromLon(lon);
        ctx[`${k}_lon`] = lon;
        ctx[`${k}_sign`] = sign;
        ctx[`${k}_deg`] = formatDegInSign(lon);
        ctx[`${k}_pos_abs`] = positionTextFromLon(lon);
        ctx[`${k}_dms_abs`] = formatDMS(lon);
        ctx[`${k}_rasi`] = it.rasi || it.Rasi || sign;
        ctx[`${k}_rasi_lord`] = it.rasi_lord || it.rasiLord || signLordEn(ctx[`${k}_rasi`]) || signLordEn(sign);
        ctx[`${k}_nakshatra`] = it.nakshatra || it.Nakshatra || nk.name || '';
        ctx[`${k}_nakshatra_lord`] = it.nakshatra_lord || it.nakshatraLord || it.NakshatraLord || nk.lord || '';
      }
    });

    // final fallback for lunar nodes when upstream chart omitted them
    try{
      ['rahu','ketu'].forEach(function(k){
        if (!ctx[`${k}_pos_abs`] || !ctx[`${k}_deg`]){
          const fb = derivePlanetDisplayFromChart(chartN, k, payload);
          if (fb){
            ctx[`${k}_sign`] = ctx[`${k}_sign`] || fb.sign || '';
            ctx[`${k}_deg`] = ctx[`${k}_deg`] || fb.deg || '';
            ctx[`${k}_pos_abs`] = ctx[`${k}_pos_abs`] || fb.pos_abs || '';
            ctx[`${k}_rasi`] = ctx[`${k}_rasi`] || fb.rasi || fb.sign || '';
            ctx[`${k}_rasi_lord`] = ctx[`${k}_rasi_lord`] || fb.rasi_lord || '';
            ctx[`${k}_nakshatra`] = ctx[`${k}_nakshatra`] || fb.nakshatra || '';
            ctx[`${k}_nakshatra_lord`] = ctx[`${k}_nakshatra_lord`] || fb.nakshatra_lord || '';
          }
        }
      });
    }catch(_){ }

    // angles: ASC/MC
    try{
      const ang = chartN && chartN.angles ? chartN.angles : {};
      const asc = (ang.ascendant!=null)?Number(ang.ascendant):((ang.asc!=null)?Number(ang.asc):NaN);
      const mc = (ang.mc!=null)?Number(ang.mc):((ang.MC!=null)?Number(ang.MC):NaN);
      if (isFinite(asc)){
        ctx['asc_lon']=asc;
        ctx['rising_sign']=signFromLon(asc);
        ctx['asc_sign']=signFromLon(asc);
        ctx['ascendant_sign']=ctx['asc_sign'];
        ctx['asc_deg']=formatDegInSign(asc);
        ctx['ascendant_deg']=ctx['asc_deg'];
        ctx['asc_pos_abs']=positionTextFromLon(asc);
        ctx['ascendant_pos_abs']=ctx['asc_pos_abs'];
        ctx['asc_rasi']=ctx['asc_sign'];
        ctx['ascendant_rasi']=ctx['asc_sign'];
        ctx['asc_rasi_lord']=signLordEn(ctx['asc_sign']) || '';
        ctx['ascendant_rasi_lord']=ctx['asc_rasi_lord'];
        const nk = nakshatraInfoFromLon(asc);
        ctx['asc_nakshatra']=nk.name || '';
        ctx['ascendant_nakshatra']=ctx['asc_nakshatra'];
        ctx['asc_nakshatra_lord']=nk.lord || '';
        ctx['ascendant_nakshatra_lord']=ctx['asc_nakshatra_lord'];
      }
      if (isFinite(mc)){
        ctx['mc_lon']=mc;
        ctx['mc_sign']=signFromLon(mc);
        ctx['mc_deg']=formatDegInSign(mc);
        ctx['mc_pos_abs']=positionTextFromLon(mc);
      }
    }catch(_){}

    // houses
    try{
      const cusps = chartN && chartN.houses ? (chartN.houses.cusps || chartN.houses) : null;
      if (cusps && Array.isArray(cusps) && cusps.length >= 12){
        for (let i=0;i<12;i++){
          const lon = Number(cusps[i]);
          if (!isFinite(lon)) continue;
          const sign = signFromLon(lon);
          ctx[`h${i+1}`] = `${sign} ${formatDegInSign(lon)}`;
          ctx[`h${i+1}_sign`] = sign;
          ctx[`h${i+1}_deg`] = formatDegInSign(lon);
        }
      }
    }catch(_){}

    // legacy names used by older templates
    ctx['sun_sign'] = ctx['sun_sign'] || (ctx['sun_sign']||'');
    ctx['moon_sign'] = ctx['moon_sign'] || (ctx['moon_sign']||'');
    ctx['rising_sign'] = ctx['rising_sign'] || ctx['asc_sign'] || '';
    ctx['zodiac'] = ctx['sun_sign'] || (window.__ACSCALC_LAST__ && window.__ACSCALC_LAST__.zodiac) || '';

    // Ensure common placeholders never leak as raw {{tokens}}.
    // If backend doesn't provide these yet, keep them as empty strings.
    ['month_love','month_career','month_money','crystal_core','crystal_love','crystal_wealth',
     'sun_emotion_random','moon_emotion_random','rising_emotion_random'
    ].forEach(k=>{ if (!Object.prototype.hasOwnProperty.call(ctx, k)) ctx[k] = ''; });

    // Fallback from payload/data when chart service returned partial planet data.
    try{
      const sunSignDirect = String((data && (data.sun_sign || (data.profile && (data.profile.sun_sign || data.profile.zodiac_en || data.profile.name_en)))) || '').trim();
      if (!ctx['sun_sign'] && sunSignDirect) ctx['sun_sign'] = sunSignDirect;
      const ascSignDirect = String((data && (data.rising_sign || data.asc_sign || (data.profile && (data.profile.rising_sign || data.profile.asc_sign)))) || '').trim();
      if (!ctx['asc_sign'] && ascSignDirect) {
        ctx['asc_sign'] = ascSignDirect;
        ctx['rising_sign'] = ctx['rising_sign'] || ascSignDirect;
      }
    }catch(_){ }

    // Fallback copy when var library isn't available (prevents UI showing "—")
    try{
      const s = String(ctx['sun_sign']||'').trim();
      const m = String(ctx['moon_sign']||'').trim();
      const r = String(ctx['rising_sign']||'').trim();
      if (!String(ctx['month_love']||'').trim()) ctx['month_love'] = s ? (`This month in love: lean into your ${s} warmth; be clear about what you want.`) : 'This month in love: be honest, be kind, and make the first move when it feels right.';
      if (!String(ctx['month_career']||'').trim()) ctx['month_career'] = r ? (`Career focus: act from your ${r} strengths; take one visible step forward.`) : 'Career focus: pick one priority and finish it.';
      if (!String(ctx['month_money']||'').trim()) ctx['month_money'] = m ? (`Money theme: follow your ${m} instincts but avoid impulse spending; stick to a simple plan.`) : 'Money theme: keep it simple—track spending and avoid impulse buys.';
    }catch(_){}

    return ctx;
  }


  function derivePlanetDisplayFromChart(chartN, key, payload){
    let it = getPlanetObj(chartN, key);
    if ((!it || !isFinite(Number(it.longitude))) && (String(key||'').toLowerCase()==='rahu' || String(key||'').toLowerCase()==='ketu')) {
      it = fallbackNodePlanet(chartN, key, payload || (chartN && chartN.__payload) || null);
    }
    if (!it || !isFinite(Number(it.longitude))) return null;
    const lon = Number(it.longitude);
    const sign = signFromLon(lon);
    const nk = nakshatraInfoFromLon(lon);
    return {
      sign,
      pos_abs: positionTextFromLon(lon),
      deg: formatDegInSign(lon),
      rasi: it.rasi || it.Rasi || sign,
      rasi_lord: it.rasi_lord || it.rasiLord || signLordEn(it.rasi || it.Rasi || sign) || signLordEn(sign) || '',
      nakshatra: it.nakshatra || it.Nakshatra || nk.name || '',
      nakshatra_lord: it.nakshatra_lord || it.nakshatraLord || it.NakshatraLord || nk.lord || ''
    };
  }

  async function fetchNatalModulesConfig(){
    if (_natalModsCache.loaded) return _natalModsCache.data;
    if (_natalModsCache.loading) {
      // wait
      return new Promise((resolve,reject)=>{
        const t = setInterval(()=>{
          if (_natalModsCache.loaded){ clearInterval(t); resolve(_natalModsCache.data); }
          if (_natalModsCache.err){ clearInterval(t); reject(_natalModsCache.err); }
        }, 50);
        setTimeout(()=>{ clearInterval(t); resolve(_natalModsCache.data); }, 5000);
      });
    }
    _natalModsCache.loading = true;
    try{
      const url = CFG.natalModulesConfigUrl || (CFG.siteUrl ? (CFG.siteUrl.replace(/\/$/,'') + '/wp-json/acs/v1/natal-modules-config') : '');
      if (!url) throw new Error('natalModulesConfigUrl missing');
      const r = await fetch(url, { credentials:'same-origin' });
      const j = await r.json();
      _natalModsCache.data = (j && j.modules) ? j.modules : [];
      _natalModsCache.loaded = true;
      _natalModsCache.loading = false;
      return _natalModsCache.data;
    }catch(e){
      _natalModsCache.err = e;
      _natalModsCache.loading = false;
      console.warn('[NatalModules] config fetch failed', e);
      return [];
    }
  }

  function renderModule(mod, ctx){
    if (!mod || mod.enabled === false) return '';
    const title = mod.title || mod.name || mod.key || 'Module';
    const layout = mod.layout || 'list';
    const collapse = mod.collapsed_by_default ? ' closed' : '';
    const header = `
      <summary class="acscalc__modsSummary">
        <span class="acscalc__modsTitle">${escapeHtml(title)}</span>
        <span class="acscalc__modsHint">${escapeHtml(mod.hint || '')}</span>
      </summary>`;
    // Helper: strip any unresolved tokens so UI never shows raw {{placeholders}}.
    const stripUnresolved = (s)=> String(s||'').replace(/\{\{\s*[^{}]+\s*\}\}/g, '').trim();

    if (layout === 'table'){
      const cols = Array.isArray(mod.columns) ? mod.columns : [];
      const rows = Array.isArray(mod.rows) ? mod.rows : [];
      const thead = cols.map(c=>`<th>${escapeHtml(c.title || c.label || '')}</th>`).join('');

      // Back-compat: the DB plugin seeds table columns using a `source` key (pos_dms/deg_in_sign/...)
      // and some rows use `key: asc` instead of `ascendant`.
      const mapPlanetKey = (k)=>{
        const x = String(k||'').toLowerCase().trim();
        if (x === 'asc') return 'ascendant';
        if (x === 'ascendant') return 'ascendant';
        if (x === 'midheaven' || x === 'mc') return 'mc';
        return x;
      };
      const sourceMap = {
        'pos_dms': 'planet_pos_abs',
        'deg_in_sign': 'planet_deg',
        'rasi': 'planet_rasi',
        'rasi_lord': 'planet_rasi_lord',
        'nakshatra': 'planet_nakshatra',
        'nakshatra_lord': 'planet_nakshatra_lord',
        'sign': 'planet_sign',
        'sign_lord': 'planet_rasi_lord',
      };
      const body = rows.map(r=>{
        const rowKey = (r.key || r.planet_key || r.planet || r.label || '').toString().trim().toLowerCase();
        const planetKey = mapPlanetKey(rowKey || '');
        const rowCtx = Object.assign({}, ctx);
        if (planetKey){
          // attach row-specific alias: planet_* placeholders
          rowCtx['planet'] = planetKey;
          rowCtx['planet_label'] = r.label || r.name || planetKey;
          // allow {{planet_sign}} style
          const pk = planetKey;
          rowCtx['planet_sign'] = ctx[`${pk}_sign`] || '';
          rowCtx['planet_pos_abs'] = ctx[`${pk}_pos_abs`] || '';
          rowCtx['planet_deg'] = ctx[`${pk}_deg`] || '';
          rowCtx['planet_rasi'] = ctx[`${pk}_rasi`] || rowCtx['planet_sign'];
          rowCtx['planet_rasi_lord'] = ctx[`${pk}_rasi_lord`] || '';
          rowCtx['planet_nakshatra'] = ctx[`${pk}_nakshatra`] || '';
          rowCtx['planet_nakshatra_lord'] = ctx[`${pk}_nakshatra_lord`] || '';
          if (!rowCtx['planet_pos_abs'] || !rowCtx['planet_deg'] || !rowCtx['planet_rasi'] || !rowCtx['planet_nakshatra']){
            const fb = derivePlanetDisplayFromChart((ctx && ctx.__chartN) ? ctx.__chartN : null, pk, (ctx && ctx.__payload) ? ctx.__payload : null);
            if (fb){
              rowCtx['planet_sign'] = rowCtx['planet_sign'] || fb.sign || '';
              rowCtx['planet_pos_abs'] = rowCtx['planet_pos_abs'] || fb.pos_abs || '';
              rowCtx['planet_deg'] = rowCtx['planet_deg'] || fb.deg || '';
              rowCtx['planet_rasi'] = rowCtx['planet_rasi'] || fb.rasi || rowCtx['planet_sign'] || '';
              rowCtx['planet_rasi_lord'] = rowCtx['planet_rasi_lord'] || fb.rasi_lord || '';
              rowCtx['planet_nakshatra'] = rowCtx['planet_nakshatra'] || fb.nakshatra || '';
              rowCtx['planet_nakshatra_lord'] = rowCtx['planet_nakshatra_lord'] || fb.nakshatra_lord || '';
            }
          }
        }
        const tds = cols.map(c=>{
          const tpl = c.template || c.tpl || '';
          let cell = '';
          if (tpl){
            cell = resolvePlaceholders(String(tpl), rowCtx, (window.ACSCALC && window.ACSCALC.templates) ? window.ACSCALC.templates : {});
            cell = stripUnresolved(cell);
          }else if (c.source){
            const src = String(c.source||'').toLowerCase().trim();
            const k = sourceMap[src] || '';
            if (k) cell = rowCtx[k] != null ? String(rowCtx[k]) : '';
          }else if (c.key){
            const key = String(c.key||'').trim();
            cell = rowCtx[key] != null ? String(rowCtx[key]) : '';
          }
          if (!cell){
            const titleKey = String(c.title || c.label || '').toLowerCase().trim();
            if (titleKey === 'positions' || titleKey === 'position') cell = rowCtx['planet_pos_abs'] || '';
            else if (titleKey === 'degrees' || titleKey === 'degree') cell = rowCtx['planet_deg'] || '';
            else if (titleKey === 'rasi' || titleKey === 'sign') cell = rowCtx['planet_rasi'] || rowCtx['planet_sign'] || '';
            else if (titleKey === 'rasi lord' || titleKey === 'sign lord') cell = rowCtx['planet_rasi_lord'] || '';
            else if (titleKey === 'nakshatra') cell = rowCtx['planet_nakshatra'] || '';
            else if (titleKey === 'nakshatra lord') cell = rowCtx['planet_nakshatra_lord'] || '';
          }
          return `<td>${escapeHtml(String(cell))}</td>`;
        }).join('');
        return `<tr><td class="acscalc__modsRowHd">${escapeHtml(r.label || r.name || rowCtx['planet_label'] || '')}</td>${tds}</tr>`;
      }).join('');
      const ring = (mod.show_chart_ring !== false) ? renderChartRing(ctx) : '';
      return `
        <details class="acscalc__modsCard"${collapse}>
          ${header}
          <div class="acscalc__modsBody">
            ${ring}
            <div class="acscalc__modsTableWrap">
              <table class="acscalc__modsTable">
                <thead><tr><th>Planets</th>${thead}</tr></thead>
                <tbody>${body}</tbody>
              </table>
            </div>
          </div>
        </details>`;
    }

    // cards/list
    const rows = Array.isArray(mod.rows) ? mod.rows : [];
    const items = rows.map(r=>{
      const lbl = r.label || r.title || r.key || '';
      const tpl = r.template || r.tpl || r.text || '';
      let text = tpl ? resolvePlaceholders(String(tpl), ctx, (window.ACSCALC && window.ACSCALC.templates) ? window.ACSCALC.templates : {}) : '';
      text = stripUnresolved(text);
      if (!text) text = '—';
      // allow markdown-ish
      const html = mdToHtml(String(text||''));
      if (layout === 'cards'){
        return `<div class="acscalc__modsCardItem">
          <div class="acscalc__modsCardLbl">${escapeHtml(lbl)}</div>
          <div class="acscalc__modsCardTxt">${html}</div>
        </div>`;
      }
      return `<div class="acscalc__modsListItem"><div class="acscalc__modsListLbl">${escapeHtml(lbl)}</div><div class="acscalc__modsListTxt">${html}</div></div>`;
    }).join('');
    return `
      <details class="acscalc__modsCard"${collapse}>
        ${header}
        <div class="acscalc__modsBody">
          ${items || `<div class="acscalc__para">No items configured.</div>`}
        </div>
      </details>`;
  }


  function renderFullRawDataModuleDirect(ctx){
    const chartN = (ctx && ctx.__chartN) ? ctx.__chartN : null;
    const rowsDef = [
      ['Sun','sun'],['Moon','moon'],['Mercury','mercury'],['Venus','venus'],['Mars','mars'],
      ['Jupiter','jupiter'],['Saturn','saturn'],['Ascendant','ascendant'],['Rahu','rahu'],['Ketu','ketu']
    ];
    const body = rowsDef.map(function(pair){
      const label = pair[0], pk = pair[1];
      const fb = derivePlanetDisplayFromChart(chartN, pk, (ctx && ctx.__payload) ? ctx.__payload : null) || {};
      const pos = ctx[`${pk}_pos_abs`] || fb.pos_abs || '';
      const deg = ctx[`${pk}_deg`] || fb.deg || '';
      const rasi = ctx[`${pk}_rasi`] || fb.rasi || ctx[`${pk}_sign`] || fb.sign || '';
      const rasiLord = ctx[`${pk}_rasi_lord`] || fb.rasi_lord || '';
      const nak = ctx[`${pk}_nakshatra`] || fb.nakshatra || '';
      const nakLord = ctx[`${pk}_nakshatra_lord`] || fb.nakshatra_lord || '';
      return `<tr><td class="acscalc__modsRowHd">${escapeHtml(label)}</td><td>${escapeHtml(String(pos))}</td><td>${escapeHtml(String(deg))}</td><td>${escapeHtml(String(rasi))}</td><td>${escapeHtml(String(rasiLord))}</td><td>${escapeHtml(String(nak))}</td><td>${escapeHtml(String(nakLord))}</td></tr>`;
    }).join('');
    return `
      <details class="acscalc__modsCard">
        <summary class="acscalc__modsSummary">
          <span class="acscalc__modsTitle">Full Raw Data &amp; Charts</span>
          <span class="acscalc__modsHint"></span>
        </summary>
        <div class="acscalc__modsBody">
          ${renderChartRing(ctx)}
          <div class="acscalc__modsTableWrap">
            <table class="acscalc__modsTable">
              <thead><tr><th>Planets</th><th>Positions</th><th>Degrees</th><th>Rasi</th><th>Rasi Lord</th><th>Nakshatra</th><th>Nakshatra Lord</th></tr></thead>
              <tbody>${body}</tbody>
            </table>
          </div>
        </div>
      </details>`;
  }

  function renderChartRing(ctx){
    const sun = ctx.sun_sign ? `Sun ${ctx.sun_sign} ${ctx.sun_deg||''}` : '';
    const asc = (ctx.asc_sign||ctx.rising_sign) ? `Asc ${ctx.asc_sign||ctx.rising_sign} ${ctx.asc_deg||''}` : '';
    const mc = ctx.mc_sign ? `MC ${ctx.mc_sign} ${ctx.mc_deg||''}` : '';
    const lines = [sun, asc, mc].filter(Boolean).join('<br/>');
    if (!lines) return '';
    return `<div class="acscalc__chartRing"><div class="acscalc__chartRingInner">${lines}</div></div>`;
  }

  function renderBodyChartHouses(ctx){
    // Static anatomy labels like customer screenshot
    const labels = ['Head','Face','Arms','Chest','Heart','Belly','Waist','Hips','Legs','Bones','Hands','Feet'];
    const chips = [];
    for (let i=1;i<=12;i++){
      const t = ctx[`h${i}`] || '';
      chips.push(`<div class="acscalc__houseChip"><div class="acscalc__houseChipTop">H${i}</div><div class="acscalc__houseChipMid">${escapeHtml(labels[i-1])}</div><div class="acscalc__houseChipBot">${escapeHtml(t)}</div></div>`);
    }
    return `
      <details class="acscalc__modsCard">
        <summary class="acscalc__modsSummary">
          <span class="acscalc__modsTitle">Body Chart • 12 Houses</span>
          <span class="acscalc__modsHint">Click to expand</span>
        </summary>
        <div class="acscalc__modsBody">
          <div class="acscalc__bodyChart">${chips.join('')}</div>
        </div>
      </details>`;
  }

  function renderHouseCuspDegrees(ctx){
    const rows = [];
    for (let i=1;i<=12;i++){
      const pos = ctx[`h${i}`] || '';
      const sign = ctx[`h${i}_sign`] || '';
      const deg = ctx[`h${i}_deg`] || '';
      rows.push(`<tr><td class="acscalc__modsRowHd">H${i}</td><td>${escapeHtml(pos)}</td><td>${escapeHtml(sign)}</td><td>${escapeHtml(deg)}</td></tr>`);
    }
    if (!rows.some(r => !/>\s*<\/td><td><\/td><td><\/td>/.test(r))) return '';
    return `
      <details class="acscalc__modsCard">
        <summary class="acscalc__modsSummary">
          <span class="acscalc__modsTitle">House Cusp Degrees</span>
          <span class="acscalc__modsHint">H1–H12 cusp positions</span>
        </summary>
        <div class="acscalc__modsBody">
          <div class="acscalc__modsTableWrap">
            <table class="acscalc__modsTable"><thead><tr><th>House</th><th>Position</th><th>Rasi</th><th>Degrees</th></tr></thead><tbody>${rows.join('')}</tbody></table>
          </div>
        </div>
      </details>`;
  }

  async function resolveRenderableChart(chartN, payload, data){
    let out = chartN && chartHasUsablePlanets(chartN) ? chartN : null;
    if (!out && payload && payload._chart) out = normalizeChart(payload._chart);
    if (!out && data && data._chart) out = normalizeChart(data._chart);
    if (!out && data && data.chart) out = normalizeChart(data.chart);
    if ((!out || !chartHasUsablePlanets(out)) && payload){
      try{ out = normalizeChart(await getChartIfPossible(payload, 'precise')); }catch(_){ }
    }
    return out;
  }

  function renderNatalModulesFallback(modsWrap, chartN, payload, data){
    if (!modsWrap) return;
    try{
      const ctx = buildNatalCtx(chartN, payload, data);
      let html = '';
      const defaultFull = {
        key:'full_raw_data',
        title:'Full Raw Data & Charts (Click to expand)',
        hint:'',
        layout:'table',
        show_chart_ring:true,
        columns:[
          {title:'Positions', template:'{{planet_pos_abs}}'},
          {title:'Degrees', template:'{{planet_deg}}'},
          {title:'Rasi', template:'{{planet_rasi}}'},
          {title:'Rasi Lord', template:'{{planet_rasi_lord}}'},
          {title:'Nakshatra', template:'{{planet_nakshatra}}'},
          {title:'Nakshatra Lord', template:'{{planet_nakshatra_lord}}'},
        ],
        rows:[
          {label:'Sun', planet_key:'sun'},
          {label:'Moon', planet_key:'moon'},
          {label:'Mercury', planet_key:'mercury'},
          {label:'Venus', planet_key:'venus'},
          {label:'Mars', planet_key:'mars'},
          {label:'Jupiter', planet_key:'jupiter'},
          {label:'Saturn', planet_key:'saturn'},
          {label:'Ascendant', planet_key:'ascendant'},
          {label:'Rahu', planet_key:'rahu'},
          {label:'Ketu', planet_key:'ketu'},
        ]
      };
      html += renderFullRawDataModuleDirect(ctx);
      const hasHouseData = Array.from({length:12}, (_,i)=>String(ctx[`h${i+1}`]||'').trim()).filter(Boolean).length >= 4;
      if (hasHouseData) {
        html += renderBodyChartHouses(ctx);
        html += renderHouseCuspDegrees(ctx);
      }
      modsWrap.innerHTML = html || `<div class="acscalc__para">Chart modules are temporarily unavailable, but your chart data is ready.</div>`;
    }catch(_e){
      modsWrap.innerHTML = `<div class="acscalc__para">Chart modules are temporarily unavailable, but your chart data is ready.</div>`;
    }
  }

  async function hydrateNatalModules(container, chartN, payload, data){
    if (!container) return;
    const modsWrap = container.querySelector('[data-role="natal-modules"]');
    if (!modsWrap) return;
    renderNatalModulesFallback(modsWrap, chartN, payload, data);
    try{
      chartN = await resolveRenderableChart(chartN, payload, data);
      const cfgMods = await fetchNatalModulesConfig();
      const ctx = buildNatalCtx(chartN, payload, data);

      // 0) Fill common template variables from Variable Dictionary as a safe fallback.
      // These are used by seeded natal modules (monthly/houses/crystal) and should never leak as {{placeholders}}.
      try{
        const __VAR_CACHE__ = window.__ACSCALC_VAR_CACHE__ = window.__ACSCALC_VAR_CACHE__ || {};
        const want = [];
        for (let i=1;i<=12;i++) want.push('h'+i);
        want.push('month_love','month_career','month_money','crystal_core','crystal_love','crystal_wealth');

        const need = want.filter(c=>{
          const v = (ctx && Object.prototype.hasOwnProperty.call(ctx, c)) ? String(ctx[c] ?? '') : '';
          if (!v) return true;
          return /\{\{\s*[^}]+\s*\}\}/.test(v);
        }).filter(c=>!Object.prototype.hasOwnProperty.call(__VAR_CACHE__, c));

        if (need.length){
          const base = (CFG && CFG.siteUrl) ? String(CFG.siteUrl).replace(/\/$/,'') : (window.location.origin || '');
          const url = base + '/wp-json/acs/v1/vars?codes=' + encodeURIComponent(need.join(',')) + '&locale=' + encodeURIComponent('en-US');
          const res = await fetch(addCacheBuster(url), { method:'GET', credentials:'include', cache:'no-store', headers: noCacheHeaders() });
          if (res && res.ok){
            const j = await res.json();
            const vars = (j && j.vars && typeof j.vars === 'object') ? j.vars : {};
            Object.keys(vars).forEach(k => { __VAR_CACHE__[k] = String(vars[k] ?? ''); });
          }
        }

        want.forEach(code=>{
          const cur = (ctx && Object.prototype.hasOwnProperty.call(ctx, code)) ? String(ctx[code] ?? '') : '';
          if (!cur || /\{\{\s*[^}]+\s*\}\}/.test(cur)){
            if (__VAR_CACHE__[code]) ctx[code] = __VAR_CACHE__[code];
          }
        });
      }catch(e){ console.warn('[NatalModules] vars fallback failed', e); }

      try{
        if ((ctx.sun_sign || ctx.moon_sign || ctx.rising_sign)){
          const base = (CFG && CFG.siteUrl) ? String(CFG.siteUrl).replace(/\/$/,'') : (window.location.origin || '');
          const url = base + '/wp-json/acs/v1/natal-interpretation';
          const body = { sun_sign: ctx.sun_sign || '', moon_sign: ctx.moon_sign || '', rising_sign: ctx.rising_sign || ctx.asc_sign || '', locale: 'en-US' };
          const res = await fetch(addCacheBuster(url), {
            method:'POST',
            credentials:'include',
            headers: Object.assign({'Content-Type':'application/json'}, noCacheHeaders()),
            body: JSON.stringify(body)
          });
          const j = await res.json();
          if (j && Array.isArray(j.items)){
            j.items.forEach(it=>{
              const label = String((it && (it.label || it.title)) || '').toLowerCase();
              const text = (it && it.text!=null) ? String(it.text) : '';
              if (!text) return;
              if (label.includes('sun')) ctx.sun_emotion_random = text;
              else if (label.includes('moon')) ctx.moon_emotion_random = text;
              else if (label.includes('asc') || label.includes('rising')) ctx.rising_emotion_random = text;
            });
          } else if (j && (j.sun || j.moon || j.ascendant)){
            if (j.sun && j.sun.text) ctx.sun_emotion_random = String(j.sun.text);
            if (j.moon && j.moon.text) ctx.moon_emotion_random = String(j.moon.text);
            if (j.ascendant && j.ascendant.text) ctx.rising_emotion_random = String(j.ascendant.text);
          }
        }
      }catch(e){
        console.warn('[NatalModules] natal-interpretation fetch failed', e);
      }

      let html = '';
      const mods = Array.isArray(cfgMods) ? cfgMods : [];
      const defaultFull = {
        key:'full_raw_data',
        title:'Full Raw Data & Charts',
        hint:'',
        layout:'table',
        show_chart_ring:true,
        columns:[
          {title:'Positions', template:'{{planet_pos_abs}}'},
          {title:'Degrees', template:'{{planet_deg}}'},
          {title:'Rasi', template:'{{planet_rasi}}'},
          {title:'Rasi Lord', template:'{{planet_rasi_lord}}'},
          {title:'Nakshatra', template:'{{planet_nakshatra}}'},
          {title:'Nakshatra Lord', template:'{{planet_nakshatra_lord}}'},
        ],
        rows:[
          {label:'Sun', planet_key:'sun'},
          {label:'Moon', planet_key:'moon'},
          {label:'Mercury', planet_key:'mercury'},
          {label:'Venus', planet_key:'venus'},
          {label:'Mars', planet_key:'mars'},
          {label:'Jupiter', planet_key:'jupiter'},
          {label:'Saturn', planet_key:'saturn'},
          {label:'Ascendant', planet_key:'ascendant'},
          {label:'Rahu', planet_key:'rahu'},
          {label:'Ketu', planet_key:'ketu'},
        ]
      };
      html += renderFullRawDataModuleDirect(ctx);
      const extraMods = mods.filter(m=>{
        const k = String((m && m.key) || '').toLowerCase();
        const t = String((m && m.title) || '').toLowerCase();
        return !(k === 'full_raw_data' || k === 'raw' || t.includes('full raw'));
      });

      const hasHouseData = Array.from({length:12}, (_,i)=>String(ctx[`h${i+1}`]||'').trim()).filter(Boolean).length >= 4;
      if (hasHouseData) {
        html += renderBodyChartHouses(ctx);
        html += renderHouseCuspDegrees(ctx);
      }

      html += extraMods.map(m=>{
        try{ return renderModule(m, ctx); }catch(e){ console.warn('[NatalModules] render module failed', m && (m.key || m.title || m.name), e); return ''; }
      }).join('');
      if (html) modsWrap.innerHTML = html;
    }catch(e){
      console.warn('[NatalModules] hydrate failed, keeping fallback', e);
    }
  }


function renderResult(container, mode, payload, data){
    if (!container) return;
    const age = payload.age;
    const teen = age != null && age < 18;

    // Compatibility: backend may return either {profile:...} (preferred) or {zodiac:...} (legacy)
    window.__ACSCALC_LAST__ = window.__ACSCALC_LAST__||{};
    let zodiac = window.__ACSCALC_LAST__.zodiac = pick(data, [
      'profile.zodiac_en','profile.zodiac_cn','profile.zodiac_key',
      'profile.name_en','profile.name_cn','profile.key',
      'zodiac.name_en','zodiac.name_cn','zodiac.key','zodiac.zodiac_id'
    ], '');
    zodiac = cnZodiacToEn(zodiac);
    window.__ACSCALC_LAST__.zodiac = zodiac;
    const dateRange = pick(data, [
      'profile.zodiac_date','profile.date','profile.zodiac_range','profile.range','profile.date_range',
      'zodiac.date_range'
    ], '');
    const match = pick(data, ['profile.match_score','profile.score'], '');
    const safety = pick(data, ['set.safety_level','profile.safety_level'], '');

    const pai = pick(data, ['profile.pain_en','profile.pain_cn','profile.pai_text','profile.pai','pai','pai_text','result.pai','result.pai_text'], '');
    const setName = pick(data, ['set.name','set.name_cn','set.name_en','set.set_name','set.title','result.set.name','result.set.name_cn','result.set.name_en'], '');
    const crystalsLine = (Array.isArray(data.crystals) ? data.crystals : [])
      .slice(0, 3)
      .map(c => c.name_en || c.name_cn || c.name || c.id)
      .filter(Boolean)
      .join(' • ');

    // Some endpoints return copy blocks instead of a single string.
    const copyBlocks = Array.isArray(data && data.copy_blocks) ? data.copy_blocks : (Array.isArray(data && data.result && data.result.copy_blocks) ? data.result.copy_blocks : []);
    const copyFromBlocks = copyBlocks
      .map(b => (b && (b.text || b.content)) ? String(b.text || b.content).trim() : '')
      .filter(Boolean)
      .join('\n\n');

    const copyRaw = pick(data, ['copy','result.copy','profile.copy','profile.text','text','message','content','pai_text','profile.pai_text'], '') || copyFromBlocks;
    // Remove duplicated chart debug lines in precise mode (they are now represented in the core table above).
    let copyRaw2 = copyRaw;
    if (mode === 'precise' && copyRaw2){
      // Drop lines like: 太阳经度: 白羊座16°（绝对值16.19°） / 太阳星座(根据经度): 白羊座
      copyRaw2 = String(copyRaw2)
        .replace(/^[ \t]*太阳经度.*(?:\r?\n|$)/gm, '')
        .replace(/^[ \t]*太阳星座.*(?:\r?\n|$)/gm, '');
    }

    let copyText = copyRaw2 ? String(copyRaw2) : '';
    try{
      const tplLib = (window.ACSCALC && window.ACSCALC.templates) ? window.ACSCALC.templates : {};
      const ctx = { sunSign: zodiac, sun_sign: zodiac, zodiac: zodiac };
      copyText = resolvePlaceholders(copyText, ctx, tplLib);
    }catch(_){}
    const copy = copyText ? mdToHtml(copyText) : '';
    const copyThemeRaw = pick(data, ['copy_theme','result.copy_theme','profile.copy_theme','theme_copy','theme.text'], '');
    const copyAgeRaw = pick(data, ['copy_age','result.copy_age','profile.copy_age','age_copy','age.text','carousel_text','result.carousel_text'], '');
    let copyThemeText = copyThemeRaw ? decodeHtmlEntities(String(copyThemeRaw)) : '';
    let copyAgeText = copyAgeRaw ? decodeHtmlEntities(String(copyAgeRaw)) : '';
    try{
      const tplLib = (window.ACSCALC && window.ACSCALC.templates) ? window.ACSCALC.templates : {};
      const ctx = { sunSign: zodiac, sun_sign: zodiac, zodiac: zodiac };
      copyThemeText = resolvePlaceholders(copyThemeText, ctx, tplLib);
      copyAgeText = resolvePlaceholders(copyAgeText, ctx, tplLib);
    }catch(_){ }
    const copyTheme = copyThemeText ? mdToHtml(copyThemeText) : '';
    const copyAge = copyAgeText ? mdToHtml(copyAgeText) : '';
    const productsHtml = renderProducts(data.products);

    const chips = [];
    const selectedHouse = Number(payload && (payload.house || payload.house_number) || 0) || null;
    const selectedHouseLabel = selectedHouse ? getHouseLabel(selectedHouse) : '';
    if (zodiac) chips.push({ kind:'accent', text:`Sun sign: ${zodiac}` });
    if (dateRange) chips.push({ kind:'', text:`${dateRange}` });
    if (safety) chips.push({ kind:'', text:`${escapeHtml(String(safety))} safe` });
    if (age != null) chips.push({ kind:(age < 18 ? 'warn' : ''), text:`${age < 18 ? '13–17 teen mode' : '18+ suitable'}` });
    if (mode === 'precise' && selectedHouseLabel) chips.push({ kind:'', text:`Focus: ${selectedHouseLabel}` });

    const teenBanner = teen
      ? `<div class="acscalc__alert acscalc__alert--info">Age detected: teen mode has been enabled automatically. B‑level products are hidden; only A‑level safe products are shown.</div>` : '';

    const chart = data.chart || data._chart || data.astrology || data.chart_data || null;
    const chartN = normalizeChart(chart);

    // Keep last chart/payload on both window and the closest .acscalc root
    // (supports cached/pre-rendered result pages & multiple instances on one page)
    try{
      const rootEl = (container && container.closest) ? container.closest(".acscalc") : null;
      const host = rootEl || root;
      if (host) {
        host.__acscalc_last_chartN = chartN;
        host.__acscalc_last_payload = payload;
        host.__acscalc_last_data = data;
      }
      window.__ACSCALC_LAST__ = window.__ACSCALC_LAST__ || {};
      window.__ACSCALC_LAST__.chartN = chartN;
      window.__ACSCALC_LAST__.payload = payload;
      window.__ACSCALC_LAST__.data = data;
    }catch(_){}
    const sunLon = chartN && chartN.planetsObj && chartN.planetsObj.sun ? chartN.planetsObj.sun.longitude : null;
    const moonLon = chartN && chartN.planetsObj && chartN.planetsObj.moon ? chartN.planetsObj.moon.longitude : null;
    const ascLon = chartN && chartN.angles && isFinite(Number(chartN.angles.ascendant)) ? Number(chartN.angles.ascendant) : null;
    const sun = sunLon!=null ? signFromLon(sunLon) : '';
    const moon = moonLon!=null ? signFromLon(moonLon) : '';
    const rising = ascLon!=null ? signFromLon(ascLon) : '';

    // Attempt to build PPT-like "core chart data" lines for precise mode.
    const coreLines = [];
    if (sun) coreLines.push(`Sun: ${sun}`);
    if (moon) coreLines.push(`Moon: ${moon}`);
    if (rising) coreLines.push(`Rising: ${rising}`);

    // === Precise: show REAL chart factors required by customer doc ===
    let sunAbs = null, sunSign = '', sunDeg = null, sunHouse = null;
    let keyAspects = [];
    try{
      const sunObj = chartN && chartN.planetsObj ? (chartN.planetsObj.sun || chartN.planetsObj.Sun) : null;
      sunAbs = sunObj && isFinite(Number(sunObj.longitude)) ? ((Number(sunObj.longitude)%360)+360)%360 : null;
      if (sunAbs != null){
        sunSign = signFromLon(sunAbs);
        sunDeg = sunAbs - Math.floor(sunAbs/30)*30;
      }
      sunHouse = (sunAbs!=null) ? houseFromCusps(sunAbs, chartN && chartN.houses) : null;

      const aspects = (chartN && chartN.aspects && Array.isArray(chartN.aspects)) ? chartN.aspects : [];
      keyAspects = aspects
        .filter(a=>{
          const p1 = String(a.p1 || a.planet1 || a.from || '').toLowerCase();
          const p2 = String(a.p2 || a.planet2 || a.to || '').toLowerCase();
          return p1 === 'sun' || p2 === 'sun';
        })
        .sort((a,b)=> (Number(a.orb||999) - Number(b.orb||999)))
        .slice(0,3)
        .map(formatAspectEN)
        .filter(Boolean);
    }catch(_){}

    const chartSvg = (mode === 'precise') ? renderChartSvg(chartN) : '';

    const coreBlock = (mode === 'precise') ? `
      <div class="acscalc__block">
        <div data-role="natal-modules" class="acscalc__modsHost">
          <div class="acscalc__para">Loading chart modules…</div>
        </div>
      </div>
    ` : '';

    // 星盘解读按钮（仅在precise模式且有模板数据时显示）
    // 即使chartN为null，只要有模板配置也显示按钮
    const hasTemplates = payload && payload.natal_chart_templates && 
                         Object.keys(payload.natal_chart_templates).length > 0;
    
    // 调试日志
    console.log('[Natal Interpretation Button] display decision', {
      mode: mode,
      isPrecise: mode === 'precise',
      hasTemplates: hasTemplates,
      templateKeys: payload && payload.natal_chart_templates ? Object.keys(payload.natal_chart_templates) : [],
      willShowButton: mode === 'precise'
    });
    
    const natalInterpretationTrigger = '';


    // Customer requirement: completely remove legacy "Scenario pain points (PAI)" block.
    // Even if the backend returns a pain/pai field for compatibility, we never render it.
    const paiBlock = '';

    const houseFocusBlock = (mode === 'precise' && (selectedHouseLabel || selectedHouse)) ? `
      <div class="acscalc__block">
        <div class="acscalc__blockTitle">House Focus</div>
        <div class="acscalc__para">${escapeHtml(selectedHouseLabel || (`House ${selectedHouse}`))}</div>
        <div class="acscalc__para">Your Premium Reading is aligned to this house so the interpretation and recommendations stay focused on the life area you chose.</div>
      </div>
    ` : '';

    const setBlock = (setName || crystalsLine) ? `
      <div class="acscalc__block">
        <div class="acscalc__blockTitle">${mode === 'precise' ? 'Precise recommendations' : 'Recommended products'}${setName ? `：${escapeHtml(String(setName))}` : ''}</div>
        ${crystalsLine ? `<div class="acscalc__para">${escapeHtml(crystalsLine)}</div>` : ''}
      </div>
    ` : '';

    const normalizedCopy = copy ? String(copy).trim() : '';
    const normalizedCopyTheme = copyTheme ? String(copyTheme).trim() : '';
    const normalizedCopyAge = copyAge ? String(copyAge).trim() : '';
    const hasStandaloneTemplateCopy = normalizedCopy && normalizedCopy !== normalizedCopyTheme && normalizedCopy !== normalizedCopyAge;

    const readingBlock = (normalizedCopyTheme || normalizedCopyAge || normalizedCopy) ? `
      <div class="acscalc__block">
        <div class="acscalc__blockTitle">Interpretation</div>
        ${hasStandaloneTemplateCopy ? `<div class="acscalc__subBlock"><div class="acscalc__subTitle">Full Reading</div><div class="acscalc__para">${normalizedCopy}</div></div>` : (normalizedCopy ? `<div class="acscalc__subBlock"><div class="acscalc__para">${normalizedCopy}</div></div>` : '')}
        ${normalizedCopyTheme ? `<div class="acscalc__subBlock"><div class="acscalc__subTitle">Theme Guidance</div><div class="acscalc__para">${normalizedCopyTheme}</div></div>` : ''}
        ${normalizedCopyAge ? `<div class="acscalc__subBlock"><div class="acscalc__subTitle">Age Guidance</div><div class="acscalc__para">${normalizedCopyAge}</div></div>` : ''}
      </div>
    ` : '';

    const shopBlock = `
      <div class="acscalc__block">
        <div class="acscalc__blockTitle">View details</div>
        ${productsHtml}
        <div class="acscalc__actions">
          <button class="acscalc__btn" type="button" data-action="save">${mode === 'precise' ? 'Save to my profile' : 'Save plan'}</button>
          <button class="acscalc__btn acscalc__btn--primary" type="button" data-action="view-cart">Build my plan</button>
        </div>
        <div style="margin-top:10px;color:rgba(255,255,255,.55);font-size:12px;line-height:1.5;">Results are for reference only. Product effects vary by individual.</div>
      </div>
    `;

    // Quick mode: show a compact CTA that navigates to the PPT slide-06 style upgrade guide.
    const upgrade = (mode === 'quick') ? `
      <div class="acscalc__upgradeTeaser">
        <div class="acscalc__upgradeTeaserHd">
          <div class="acscalc__upgradeTeaserTitle">Want a deeper interpretation?</div>
          <div class="acscalc__upgradeTeaserSub">Free upgrade: full chart, blind‑spot analysis, and 30‑day transit guide</div>
        </div>
        <div class="acscalc__actions">
          <button class="acscalc__btn acscalc__btn--primary" type="button" data-action="open-upgrade">Upgrade</button>
          <button class="acscalc__btn" type="button" data-action="stay-quick">Not now</button>
        </div>
      </div>
    ` : '';

    container.innerHTML = `
      ${teenBanner}
      <div class="acscalc__resultHeader">
        <div>
          <h3 class="acscalc__resultTitle">${escapeHtml(mode === 'precise' ? 'Precise Reading — Results' : 'Quick Reading — Results')}</h3>
          <div style="margin-top:6px;color:rgba(255,255,255,.70);font-size:13px;line-height:1.45;">${escapeHtml(mode === 'precise' ? 'Multi-dimensional interpretation based on your full birth chart' : 'One-click assessment: Theme-based quick reading')}</div>
        </div>
        <div class="acscalc__resultMeta">
          ${chips.map(c=>`<span class="acscalc__tag ${c.kind==='accent'?'acscalc__tag--accent':''} ${c.kind==='warn'?'acscalc__tag--warn':''}">${c.text}</span>`).join('')}
        </div>
      </div>

      ${coreBlock}
      ${houseFocusBlock}
      ${natalInterpretationTrigger}
      ${paiBlock}
      ${setBlock}
      ${readingBlock}
      ${shopBlock}
      ${upgrade}
    `;

    // Hydrate configurable natal modules (V2) after HTML paint
    try{
      if (mode === 'precise') {
        Promise.resolve(hydrateNatalModules(container, chartN, payload, data)).catch(function(e){
          console.warn('[NatalModules] hydrate failed', e);
          try{
            const modsWrap = container.querySelector('[data-role="natal-modules"]');
            renderNatalModulesFallback(modsWrap, chartN, payload, data);
          }catch(_){ }
        });
      }
    }catch(e){ console.warn('[NatalModules] hydrate failed', e); }
    // Natal interpretation CTA button removed per requirement.
// Hide placeholder in the panel
    try{
      const panel = container.closest('.acscalc__panel');
      const empty = panel ? panel.querySelector('[data-empty]') : null;
      if (empty) empty.style.display = 'none';
    }catch(_){ }

    container.querySelectorAll('[data-action]').forEach(el=>{
      el.addEventListener('click', (ev)=>{
        const act = el.getAttribute('data-action');
        if (act === 'save') {
          const ok = savePlan(mode, payload, data);
          el.textContent = ok ? 'Saved ✓' : 'Save failed';
        } else if (act === 'show-natal-interpretation') {
          try{ ev.__acscalc_natal_handled = true; }catch(_){ }
          // 显示星盘解读弹窗
          console.log('[Natal Interpretation] button clicked', {
            mode: mode,
            hasChartN: !!chartN,
            hasPayload: !!payload,
            chartNKeys: chartN ? Object.keys(chartN) : []
          });
          showNatalInterpretationModal(chartN, payload);
        } else if (act === 'open-upgrade') {
          // Toggle to the upgrade guide (slide-06)
          try { showUpgradeView(root); } catch(_){ }
        } else if (act === 'back-quick') {
          try { hideUpgradeView(root); } catch(_){ }
        } else if (act === 'switch-precise') {
          try{ ev.preventDefault(); ev.stopPropagation(); }catch(_){ }
          // Astral UI: always switch tabs in-page.
          const btn = root.querySelector('.acscalc__tab[data-tab="precise"]');
          if (btn) btn.click();
          try{ window.scrollTo({ top: root.getBoundingClientRect().top + window.scrollY - 10, behavior:'smooth' }); }catch(_){ }
        } else if (act === 'view-cart') {
          window.location.href = (CFG.siteUrl || '/') + 'cart';
        } else if (act === 'stay-quick') {
          try{ window.scrollTo({ top: container.getBoundingClientRect().top + window.scrollY - 10, behavior:'smooth' }); }catch(_){ }
        }
      });
    });
  }

  // Upgrade guide view (slide-06) toggling. Server renders both blocks; JS flips visibility.
  function setSearchParam(url, key, value){
    try{
      const u = new URL(url, window.location.origin);
      if (!value) u.searchParams.delete(key); else u.searchParams.set(key, value);
      return u.pathname + (u.search ? u.search : '') + (u.hash ? u.hash : '');
    }catch(_){
      return url;
    }
  }

  function showUpgradeView(root){
    if (!root) return;
    const up = root.querySelector('[data-view-block="upgrade"]');
    const main = root.querySelector('[data-view-block="quick-main"]');
    if (!up || !main) return;
    main.hidden = true;
    main.style.display = 'none';
    up.hidden = false;
    up.style.display = '';
    root.classList.add('acscalc--view-upgrade');
    root.dataset.view = 'upgrade';
    try{
      const next = setSearchParam(window.location.href, 'acscalc_view', 'upgrade');
      window.history.pushState({acscalc_view:'upgrade'}, '', next);
    }catch(_){ }
    try{ window.scrollTo({ top: root.getBoundingClientRect().top + window.scrollY - 10, behavior:'smooth' }); }catch(_){ }
  }

  function hideUpgradeView(root){
    if (!root) return;
    const up = root.querySelector('[data-view-block="upgrade"]');
    const main = root.querySelector('[data-view-block="quick-main"]');
    if (!up || !main) return;
    up.hidden = true;
    up.style.display = 'none';
    main.hidden = false;
    main.style.display = '';
    root.classList.remove('acscalc--view-upgrade');
    root.dataset.view = '';
    try{
      const next = setSearchParam(window.location.href, 'acscalc_view', '');
      window.history.pushState({acscalc_view:''}, '', next);
    }catch(_){ }
    try{ window.scrollTo({ top: root.getBoundingClientRect().top + window.scrollY - 10, behavior:'smooth' }); }catch(_){ }
  }

  async function getChartIfPossible(payload, mode){
    const req = {
      // ACS chart endpoint expects {birth:{date,time}, city:{lat,lng}}
      birth: payload && (payload.birth || payload.dob) ? (payload.birth || { date: payload.dob, time: payload.tob }) : null,
      city: payload && payload.city && typeof payload.city === 'object'
        ? payload.city
        : (payload && (payload.city_obj || { lat: payload.lat, lng: payload.lng, name: payload.city_label || payload.city, country: payload.country })),
      dob: payload && payload.dob,
      tob: payload && payload.tob,
      city_label: payload && payload.city_label,
      country: payload && payload.country,
      lat: payload && payload.lat,
      lng: payload && payload.lng,
    };

    // Precise mode MUST have houses + angles + aspects.
    // On hosts without swisseph, the ACS core plugin patches fetch() and computes the chart via Moshier in-browser.
    const wantFullChart = (mode === 'precise');

    // If we have a chart endpoint, prefer it for precise (houses/aspects). Fallback to local planets-only chart.
    if (wantFullChart && CFG.chartUrl) {
      try {
        const remote = await postJsonChart(CFG.chartUrl, req);
        if (remote) return remote;
      } catch(_) {}
      // continue to local fallback
    }

    // Local planets-only (no houses unless another script augments it)
    const local = await computeChartLocalMoshier(req);
    if (local) return local;

    // For quick mode, allow remote chart if local wasn't available
    const localOnly = (CFG.localOnly !== undefined) ? !!CFG.localOnly : false;
    if (!localOnly && CFG.chartUrl) {
      try { return await postJsonChart(CFG.chartUrl, req); } catch(_) { return null; }
    }
    return null;
  }

  function setLoadingProgress(loadingEl, pct, label){
    if (!loadingEl) return;
    const p = Math.max(0, Math.min(100, Math.round(Number(pct)||0)));
    loadingEl.style.display = 'block';
    loadingEl.innerHTML = `
      <div class="acscalc__progressWrap">
        <div class="acscalc__progressMeta"><span>${escapeHtml(label||'Generating your reading…')}</span><span>${p}%</span></div>
        <div class="acscalc__progressBar"><span style="width:${p}%"></span></div>
      </div>`;
  }

  function startLoadingProgress(loadingEl){
    if (!loadingEl) return ()=>{};
    let pct = 8;
    const steps = [
      [8,'Validating birth data…'],
      [22,'Matching city coordinates…'],
      [42,'Calculating natal chart…'],
      [64,'Analyzing houses and aspects…'],
      [82,'Generating interpretation…'],
      [94,'Finalizing your report…']
    ];
    let idx = 0;
    setLoadingProgress(loadingEl, steps[0][0], steps[0][1]);
    const timer = setInterval(()=>{
      idx = Math.min(idx + 1, steps.length - 1);
      pct = Math.max(pct, steps[idx][0]);
      setLoadingProgress(loadingEl, pct, steps[idx][1]);
      if (idx >= steps.length - 1) clearInterval(timer);
    }, 700);
    return function finish(finalLabel){
      clearInterval(timer);
      setLoadingProgress(loadingEl, 100, finalLabel || 'Completed');
      setTimeout(()=>{ try{ loadingEl.style.display='none'; loadingEl.innerHTML=''; }catch(_){ } }, 350);
    };
  }

  async function submit(mode, form, resultEl, loadingEl){
    clearError();

    // Premium gating (server-side should also enforce; this is UX layer)
    if (mode === 'precise') {
      const ok = await ensureLoggedInFresh();
      if (!ok) {
        try{ if (loadingEl && loadingEl.style) loadingEl.style.display = 'none'; }catch(_){ }
        try{ openLoginGate(); }catch(_){ }
        return;
      }
    }

    // Defensive DOM: allow calculation flow even if result container is missing.
    if (!resultEl) {
      resultEl = document.createElement('div');
      resultEl.className = 'acscalc__result acscalc__result--auto';
      try { root && root.appendChild(resultEl); } catch(_){ }
    }

    if (resultEl && resultEl.style) {
      resultEl.style.display = 'none';
      resultEl.innerHTML = '';
      try{
        const panel = resultEl.closest ? resultEl.closest('.acscalc__panel') : null;
        const empty = panel ? panel.querySelector('[data-empty]') : null;
        if (empty) empty.style.display = '';
      }catch(_){ }
    }

    const finishLoading = startLoadingProgress(loadingEl);

    try{
      const fd = new FormData(form);
      const theme = normalizeThemeKey(fd.get('theme') || 'general');
      const selectedHouse = String(fd.get('house') || fd.get('house_number') || '').trim();
      const birthDateRaw = String(fd.get('birthDate')||'').trim();
      const birthTimeRaw = String(fd.get('birthTime')||'').trim();

      const birthDate = normalizeBirthDate(birthDateRaw);
      const birthCity = String(fd.get('birthCity')||'').trim();

      if (!birthDate) throw new Error('Please select your birth date.');
      if (!birthCity) throw new Error('Please enter your birth city.');

      // Quick mode: birth time is optional. If missing, we default to noon (12:00) to keep API payload stable.
      // Precise mode: birth time is required.
      const birthTime = (mode === 'quick')
        ? (normalizeBirthTime(birthTimeRaw) || '12:00')
        : normalizeBirthTime(birthTimeRaw);

      if (mode === 'precise' && !birthTime) {
        throw new Error('Please enter a valid birth time (HH:MM), e.g., 09:30.');
      }
      if (mode === 'precise' && !selectedHouse) {
        const err = new Error('Please choose a focus house for Premium Reading.');
        err.code = 'HOUSE_REQUIRED';
        throw err;
      }

      const age = calcAge(birthDate);
      if (age === null) throw new Error('Invalid birth date. Please select a valid date.');
      const ageBucket = ageToBucket(age);

      const cityObj = parseCityInput(birthCity);
      const timeStr = birthTime;

      // IMPORTANT: ACS database expects a real city match from its city DB (with coordinates).
      // Require user to pick a city that exists in the ACS city file.
      setLoadingProgress(loadingEl, 20, 'Matching city coordinates…');
      const cityMatch = await resolveCityCoordsFromInput(birthCity);
      if (!cityMatch || cityMatch.lat == null || cityMatch.lng == null) {
        throw new Error('Please select a city from the suggestions (needed to match coordinates).');
      }

      // Send BOTH payload schemas for maximum compatibility with ACS database plugin:
      // 1) legacy schema: {dob, tob, city, age, mode, lat, lng, country}
      // 2) structured schema: {birth:{date,time}, city_obj:{name,country,lat,lng}, age, mode}
      // Commercial mode: do NOT use local approximations. We will require a real chart from the ACS chart endpoint.
      let zodiac_key_name = '';
      let zodiac_key_ast = '';
      let zodiac_key = '';

      const payload = {
        // For /wp-json/acs/v1/recommend (server expects zodiac_key and/or ast.zodiac_key)
        zodiac_key,
        theme,
        ast: {
          zodiac_key,
          birth: { date: birthDate, time: timeStr },
          city: { name: cityMatch.name, country: cityMatch.country, lat: Number(cityMatch.lat), lng: Number(cityMatch.lng) }
        },

        // primary (ACS-compatible)
        age,
        age_bucket: ageBucket,
        age_group_key: ageBucket,
        mode,
        house: mode === 'precise' ? Number(selectedHouse || 0) : undefined,
        house_number: mode === 'precise' ? Number(selectedHouse || 0) : undefined,
        birth: { date: birthDate, time: timeStr },
        city: { name: cityMatch.name, country: cityMatch.country, lat: Number(cityMatch.lat), lng: Number(cityMatch.lng) },

        // legacy/back-compat (some hosts / older bridges)
        dob: birthDate,
        tob: timeStr,
        city_label: `${cityMatch.name}, ${cityMatch.country}`,
        country: cityMatch.country,
        lat: Number(cityMatch.lat),
        lng: Number(cityMatch.lng),
        ui_theme: theme,
        ui_mode: mode,
        source: 'acscalc_complete',
      };

      // Attach natal chart templates from localized config (may be empty)
      payload.natal_chart_templates = (window.ACSCALC && window.ACSCALC.natal_chart_templates) ? window.ACSCALC.natal_chart_templates : {};
      payload.templates = (window.ACSCALC && window.ACSCALC.templates) ? window.ACSCALC.templates : {};




      // Require a real chart from the ACS chart endpoint (no fake/local fallback).
      setLoadingProgress(loadingEl, 42, 'Calculating natal chart…');
      const chartRaw = await getChartIfPossible(payload, mode);
      const chartN = normalizeChart(chartRaw);
      const sunLon = chartN && chartN.planetsObj && chartN.planetsObj.sun ? chartN.planetsObj.sun.longitude : null;
      if (!chartN || !isFinite(Number(sunLon))) {
        // Strict: no silent fallback; the chart must be real and parseable.
        throw new Error('Chart calculation failed: missing planet longitudes (Sun). Please ensure the ACS chart endpoint is working (Swiss Ephemeris or Moshier fallback).');
      }
      payload._chart = chartN.raw;

      // Derive zodiac keys from the returned chart (real ephemeris-based longitude).
      const z = zodiacFromLongitude(sunLon);
      zodiac_key_name = z.key;
      zodiac_key_ast = z.ast;
      zodiac_key = z.key;
      if (zodiac_key) {
        payload.zodiac_key = zodiac_key;
        payload.ast = payload.ast || {};
        payload.ast.zodiac_key = zodiac_key;
      }

      const recommendEndpoint = (mode === 'precise' && CFG && CFG.premiumRecommendUrl) ? CFG.premiumRecommendUrl : CFG.recommendUrl;
      setLoadingProgress(loadingEl, 74, 'Generating interpretation…');
      let data = await postJson(recommendEndpoint, payload);

      // If server fell back to keyword-mode, the zodiac_key didn't match the DB profile keys.
      // Retry once using ACS zodiac tag ids (AST0xx) which some deployments use as profile keys.
      if (data && data.mode === 'keywords' && zodiac_key_ast && zodiac_key_ast !== zodiac_key_name) {
        const payload2 = JSON.parse(JSON.stringify(payload));
        payload2.zodiac_key = zodiac_key_ast;
        payload2.ast = payload2.ast || {};
        payload2.ast.zodiac_key = zodiac_key_ast;
        data = await postJson(recommendEndpoint, payload2);
      }
      // Strict mode: only accept content returned from ACS database (no local fallback)
      const hasCopy = !!(data && (
        data.copy ||
        (data.result && data.result.copy) ||
        (data.profile && (data.profile.copy || data.profile.text)) ||
        (Array.isArray(data.copy_blocks) && data.copy_blocks.length) ||
        (data.result && Array.isArray(data.result.copy_blocks) && data.result.copy_blocks.length) ||
        data.text || data.message
      ));
      const hasProfile = !!(data && (data.profile || data.zodiac));
      const hasSet = !!(data && data.set && (data.set.name || data.set.name_cn || data.set.name_en || data.set.set_name));
      if (!hasCopy && !hasProfile && !hasSet) {
        // Show raw response for debugging (still database-originated), then stop.
        const raw = JSON.stringify(data, null, 2);
        renderResult(resultEl, mode, payload, { copy: 'Database integration failed: ACS returned no readable content. Raw response attached below.', _raw: raw });
        resultEl.style.display = 'block';
        return;
      }

      // Attach chart if we got one (rendering convenience)
      // NOTE: backend may include a truthy but incomplete `chart` object (e.g. missing planets on hosts without Swiss Ephemeris).
      // If we already computed a client chart (_chart), prefer it when the backend chart is missing key fields.
      if (payload._chart) {
        try {
          const existing = data.chart || data._chart || null;
          const n = normalizeChart(existing);
          const okPlanets = n && Array.isArray(n.planetsArr) && n.planetsArr.filter(p=>p && isFinite(Number(p.longitude))).length >= 3;
          const okHouses = n && n.houses && ((Array.isArray(n.houses.cusps) && n.houses.cusps.length >= 12) || (Array.isArray(n.houses) && n.houses.length >= 12));
          const hasNodes = !!(getPlanetObj(n, 'rahu') && getPlanetObj(n, 'ketu'));
          const hasAngles = !!(n && n.angles && isFinite(Number(n.angles.ascendant!=null?n.angles.ascendant:n.angles.asc)) && isFinite(Number(n.angles.mc!=null?n.angles.mc:n.angles.midheaven)));
          if (!data.chart || !okPlanets || !okHouses || !hasNodes || !hasAngles) {
            data.chart = payload._chart;
          }
        } catch(_e) {
          data.chart = payload._chart;
        }
      }

      setLoadingProgress(loadingEl, 92, 'Rendering your report…');
      renderResult(resultEl, mode, payload, data);
      resultEl.style.display = 'block';

      // When using PPT multi-page UI, advance to the appropriate result page.
      if (hasPptPages) {
        if (mode === 'quick') {
          showQuickPage('quick-result');
        } else if (mode === 'precise') {
          showPrecisePage('precise-report');
        }
      }
    }catch(e){
      const msg = e && e.message ? String(e.message) : '';
      const st = (e && e.status) ? Number(e.status) : null;
      const code = e && e.code ? String(e.code) : '';
      if (code === 'HOUSE_REQUIRED') {
        const houseSel = form.querySelector('[data-role="houseSelect"]');
        try{ if (houseSel) { houseSel.focus(); houseSel.scrollIntoView({behavior:'smooth', block:'center'}); houseSel.style.boxShadow = '0 0 0 3px rgba(255,183,77,.35)'; setTimeout(()=>{ try{ houseSel.style.boxShadow=''; }catch(_){ } }, 1800); } }catch(_){ }
        showError('Premium Reading requires a house focus. Please choose one of the 12 houses and submit again.');
      } else if (code === 'AGE_VERIFICATION_FAILED') {
        showError('Your birth date and age did not match closely enough. Please review them and confirm again if needed.');
      } else if (mode === 'precise' && (st === 401 || st === 403 || /not allowed|forbidden|login|authentication/i.test(msg))) {
        // UX: show login modal instead of dumping raw REST error.
        try{ openLoginGate(); }catch(_){ }
        showError('Login required. Premium Reading requires an account. Please log in to continue.');
      } else {
        showError(msg || 'Calculation failed. Please try again.');
      }
    }finally{
try{ finishLoading('Report ready'); }catch(_){ if (loadingEl && loadingEl.style) loadingEl.style.display='none'; }
    }
  }

  function bind(mode){
    const form = document.querySelector(`form[data-form="${mode}"]`);
    const result = document.querySelector(`[data-result="${mode}"]`);
    if (!form || !result) return;
    const loading = form.querySelector('[data-role="loading"]');

    const input = form.querySelector('input[name="birthCity"]');
    const box = form.querySelector(`[data-suggest="${mode}"]`);
    if (input && box){
      let t = null;

      // Popular cities fallback (shown when input is empty and/or geo fails).
      // Keep this list small and globally recognizable for overseas users.
      const POPULAR = [
        { name:'New York', country:'US' },
        { name:'Los Angeles', country:'US' },
        { name:'London', country:'GB' },
        { name:'Paris', country:'FR' },
        { name:'Berlin', country:'DE' },
        { name:'Toronto', country:'CA' },
        { name:'Vancouver', country:'CA' },
        { name:'Sydney', country:'AU' },
        { name:'Melbourne', country:'AU' },
        { name:'Singapore', country:'SG' },
        { name:'Hong Kong', country:'HK' },
        { name:'Dubai', country:'AE' },
        { name:'Tokyo', country:'JP' },
        { name:'Seoul', country:'KR' }
      ];

      async function fetchJsonWithTimeout(url, timeoutMs){
        const ctrl = new AbortController();
        const id = setTimeout(()=>ctrl.abort(), timeoutMs);
        try{
          const res = await fetch(url, { signal: ctrl.signal, cache: 'no-store' });
          if (!res.ok) return null;
          return await res.json();
        }catch(_){
          return null;
        }finally{
          clearTimeout(id);
        }
      }

      async function tryAutoFillCity(){
        // Only auto-fill when empty (don't overwrite user input)
        if (String(input.value||'').trim()) return;

        // Avoid running twice for the same form instance
        if (input.dataset && input.dataset.geoTried === '1') return;
        if (input.dataset) input.dataset.geoTried = '1';

        // ip-api free tier is HTTP only; use it only on HTTP pages.
        const isHttps = (window.location && window.location.protocol === 'https:');

        // 1) Prefer HTTPS-friendly provider (ipapi.co)
        let data = await fetchJsonWithTimeout('https://ipapi.co/json/', 1000);
        let city = data && (data.city || data.region || data.country_name) ? String(data.city||'').trim() : '';
        let country = data && data.country ? String(data.country).trim().toUpperCase() : '';

        // 2) If still empty and page is HTTP, try ip-api
        if ((!city || city.length < 2) && !isHttps) {
          data = await fetchJsonWithTimeout('http://ip-api.com/json/?fields=status,city,countryCode', 1000);
          if (data && data.status === 'success'){
            city = data.city ? String(data.city).trim() : '';
            country = data.countryCode ? String(data.countryCode).trim().toUpperCase() : country;
          }
        }

        if (city) {
          input.value = country ? `${city}, ${country}` : city;
          // Trigger suggestions refresh so user can pick the canonical city row
          refresh().catch(()=>{});
        }
      }

      async function refresh(){
        const v = String(input.value||'').trim();
        if (!v){
          renderCitySuggestions(box, POPULAR);
          return;
        }
        const matches = await getCityMatches(v, 20);
        renderCitySuggestions(box, matches.length ? matches : POPULAR);
        _citiesLoadError = false;
      }

      input.addEventListener('input', ()=>{
        clearTimeout(t);
        t = setTimeout(()=>{ refresh().catch(()=>{
          renderCitySuggestions(box, []);
          if (!_citiesLoadError) {
            _citiesLoadError = true;
            showError('City database could not be loaded. Please verify the ACS city JSON file is accessible.');
          }
        }); }, 120);
      });

      input.addEventListener('focus', ()=>{
        tryAutoFillCity().catch(()=>{});
        refresh().catch(()=>{});
      });

      // Also attempt geo on first paint (non-blocking)
      tryAutoFillCity().catch(()=>{});

      // select a suggestion (use mousedown to avoid focus/blur timing issues)
      function pickSuggestion(e){
        const item = e.target.closest('.acscalc__suggestion');
        if (!item) return;
        e.preventDefault();
        e.stopPropagation();
        input.value = item.getAttribute('data-city') || '';
        // Hide immediately and also after a tick to guard against theme click handlers.
        renderCitySuggestions(box, []);
        try{ box.style.display = 'none'; }catch(_){ }
        try{ input.blur(); }catch(_){ }
        setTimeout(()=>{ try{ renderCitySuggestions(box, []); }catch(_){ } }, 0);
      }
      box.addEventListener('mousedown', pickSuggestion);
      box.addEventListener('click', pickSuggestion);

      // hide on outside click
      document.addEventListener('click', (e)=>{
        if (e.target === input || box.contains(e.target)) return;
        renderCitySuggestions(box, []);
      });
    }

    form.addEventListener('submit', (e)=>{
      e.preventDefault();
      submit(mode, form, result, loading);
    });
  }

  bind('quick');

  bind('precise');

  // ------------------------------------------------------------
  // Robust "jump to precise" handler
  // - Prevents other handlers from blanking the UI on quick-only widgets.
  // - If a precise calculator exists on the SAME page (shortcode on same page), scroll to it and activate.
  // - Otherwise, redirect to the page that contains [astrology_calculator_precise] (URL injected by PHP).
  // ------------------------------------------------------------
  (function(){

    function normalizeUrl(u){
      try{
        const x = new URL(u, window.location.href);
        x.hash = '';
        return x.toString();
      }catch(_){
        return String(u||'').split('#')[0];
      }
    }

    function findPreciseInstanceOnPage(){
      // Prefer explicit precise-only instance
      let el = document.querySelector('.acscalc.acscalc--precise, .acscalc[data-mode="precise"]');
      if (el) return el;

      // Or a "both" instance that has precise panel/pages
      el = document.querySelector('.acscalc .acscalc__panel[data-panel="precise"]');
      if (el) return el.closest('.acscalc');

      return null;
    }

    function activatePreciseWithin(rootEl){
      if (!rootEl) return false;

      // Tabs mode
      const tab = rootEl.querySelector('.acscalc__tab[data-tab="precise"]');
      if (tab) { tab.click(); return true; }

      // PPT pages mode
      const precisePage = rootEl.querySelector('.acscalc__page[data-page="precise-input"]');
      if (precisePage) {
        // If helper exists in closure, use it; otherwise just show the page.
        try{
          if (typeof showPrecisePage === 'function') { showPrecisePage('precise-input'); }
          else {
            const panel = rootEl.querySelector('.acscalc__panel[data-panel="precise"]') || rootEl;
            const pages = Array.from(panel.querySelectorAll('.acscalc__page[data-page]'));
            pages.forEach(p=>{
              const active = (p.getAttribute('data-page') === 'precise-input');
              p.hidden = !active;
              p.style.display = active ? '' : 'none';
            });
          }
        }catch(_){}
        return true;
      }

      // Panel fallback
      const panel = rootEl.querySelector('.acscalc__panel[data-panel="precise"]');
      if (panel) {
        panel.scrollIntoView({behavior:'smooth', block:'start'});
        return true;
      }

      return false;
    }

    // Intercept clicks with highest priority
    document.addEventListener('click', (e)=>{
      const t = e.target && e.target.closest
        ? e.target.closest('[data-action="switch-precise"],[data-action="go-precise"],[data-role="go-precise"],a[href="#precise"],button[data-target="precise"],.acscalc__toPrecise,.acscalc__jumpPrecise')
        : null;
      if (!t) return;

      // Only handle clicks that originate inside a calculator widget
      const fromRoot = t.closest('.acscalc');
      if (!fromRoot) return;


      // Premium gating: require login
      if (!isLoggedIn()) {
        e.preventDefault();
        if (e.stopImmediatePropagation) e.stopImmediatePropagation();
        if (e.stopPropagation) e.stopPropagation();
        // Refresh auth state (handles full-page cache) then retry once.
        ensureLoggedInFresh().then((ok)=>{
          if (ok) {
            try{ t.click(); }catch(_){ }
          } else {
            try{ openLoginGate(); }catch(_){ }
          }
        });
        return;
      }

      e.preventDefault();
      // Stop other handlers that might blank the UI
      if (e.stopImmediatePropagation) e.stopImmediatePropagation();
      if (e.stopPropagation) e.stopPropagation();

      // 1) If there's a precise calculator on the same page, go there and activate it.
      const preciseRoot = findPreciseInstanceOnPage();
      if (preciseRoot) {
        preciseRoot.scrollIntoView({behavior:'smooth', block:'start'});
        setTimeout(()=>{ activatePreciseWithin(preciseRoot); }, 60);
        return;
      }

      // Last resort: visible alert (some themes hide error box)
      alert("Couldn't switch to Premium Reading. Please make sure you are using the unified [astrology_calculator] shortcode.");
    }, true);
  })();




  // ------------------------------------------------------------
  // Quick -> Premium (Precise) jump
  // - Switch within the same widget instance.
  // ------------------------------------------------------------
  (function(){
    if (!root) return;

    function trySwitchToPreciseWithinRoot(){
      // tabbed mode
      const tab = root.querySelector('.acscalc__tab[data-tab="precise"]');
      if (tab) { tab.click(); return true; }

      // ppt multi-page mode
      if (typeof showPrecisePage === 'function') { try{ showPrecisePage('precise-input'); return true; }catch(_){ } }

      // panel mode fallback
      const panel = root.querySelector('.acscalc__panel[data-panel="precise"]');
      if (panel) {
        panel.scrollIntoView({behavior:'smooth', block:'start'});
        return true;
      }
      return false;
    }

    // Buttons/links we consider as "go precise" CTAs
    const selectors = [
      '[data-action="go-precise"]',
      '[data-role="go-precise"]',
      'a[href="#precise"]',
      'button[data-target="precise"]',
      '.acscalc__toPrecise',
      '.acscalc__jumpPrecise'
    ].join(',');

    root.addEventListener('click', (e)=>{
      const t = e.target.closest(selectors);
      if (!t) return;

      e.preventDefault();

      // 1) switch within same widget if possible
      if (trySwitchToPreciseWithinRoot()) return;

      // 2) last resort: show a helpful error
      try{ showError('Premium mode is unavailable in this instance.'); }catch(_){}
    }, true);
  })();


  // Delegated handler: makes the "Natal Interpretation" button work even when the result HTML
  // is cached/pre-rendered (so renderResult did not attach per-element handlers), and across
  // multiple calculator instances on the same page.
  document.addEventListener("click", function(ev){
    try{
      if (ev && ev.__acscalc_natal_handled) return;
      const btn = ev && ev.target && ev.target.closest ? ev.target.closest("[data-action=\"show-natal-interpretation\"]") : null;
      if (!btn) return;

      if (ev && typeof ev.preventDefault === "function") ev.preventDefault();

      let chartN = null;
      let pl = null;

      const r = btn.closest ? btn.closest(".acscalc") : null;
      if (r && r.__acscalc_last_chartN) chartN = r.__acscalc_last_chartN;
      if (r && r.__acscalc_last_payload) pl = r.__acscalc_last_payload;

      const last = window.__ACSCALC_LAST__ || {};
      if (!chartN && last.chartN) chartN = last.chartN;
      if (!pl && last.payload) pl = last.payload;

      if (!pl) pl = {};
      if (!pl.natal_chart_templates) {
        pl.natal_chart_templates = (window.ACSCALC && window.ACSCALC.natal_chart_templates) ? window.ACSCALC.natal_chart_templates : {};
      
        pl.templates = (window.ACSCALC && window.ACSCALC.templates) ? window.ACSCALC.templates : {};
      }

      console.log("[Natal Interpretation] delegated click", {
        hasChartN: !!chartN,
        hasTemplates: !!(pl.natal_chart_templates && Object.keys(pl.natal_chart_templates).length)
      });

      showNatalInterpretationModal(chartN, pl);
    }catch(e){
      console.warn("[Natal Interpretation] delegated handler failed", e);
    }
  }, false);

  // warm up city DB
  loadCities().catch(()=>{});
})();


// Local chart compute (Moshier) - pure front-end mode. Returns chart-like object or null.
async function computeChartLocalMoshier(payload){
  try{
    if (window.ACS_LOCAL && typeof window.ACS_LOCAL.computeChart === 'function') {
      try{
        const full = await window.ACS_LOCAL.computeChart(payload);
        if (full && ((full.planets && full.planets.length) || (full.houses && full.angles))) return full;
      }catch(_){ }
    }
    if (!(window.ACS_Moshier && typeof window.ACS_Moshier.calculatePlanets === 'function')) return null;
    const birth = payload && (payload.birth || payload.dob) ? (payload.birth || { date: payload.dob, time: payload.tob }) : null;
    const date = birth && birth.date ? String(birth.date) : '';
    const time = birth && birth.time ? String(birth.time) : '12:00';
    const city = payload && payload.city && typeof payload.city === 'object' ? payload.city : null;
    const lat = city && city.lat != null ? Number(city.lat) : Number(payload && payload.lat);
    const lng = city && city.lng != null ? Number(city.lng) : Number(payload && payload.lng);

    if (!date || !isFinite(lat) || !isFinite(lng)) return null;

    function normLon(x){
      let v = Number(x);
      if (!isFinite(v)) return 0;
      v = ((v % 360) + 360) % 360;
      return v;
    }

    // calculatePlanets(date, time, lat, lng) expected by ACS_Moshier adapter.
    const planets = await window.ACS_Moshier.calculatePlanets(date, time, lat, lng);
    if (!planets) return null;

    // Normalize output to be compatible with downstream UI (expects .planets[].lon etc in degrees)
    // If adapter already returns ACS format, just pass through.
    if (planets.planets && Array.isArray(planets.planets)) {
      planets.planets = planets.planets.map(p => ({...p, lon: normLon(p.lon), longitude: normLon((p.longitude!=null)?p.longitude:p.lon)}));
      return planets;
    }

    // If raw map keyed by name, convert to array.
    if (typeof planets === 'object') {
      const arr = [];
      for (const k of Object.keys(planets)) {
        const v = planets[k];
        if (v && typeof v === 'object' && v.lon != null) arr.push({ name: k, ...v, lon: normLon(v.lon), longitude: normLon((v.longitude!=null)?v.longitude:v.lon) });
      }
      if (arr.length) return { planets: arr };
    }
    return null;
  }catch(_){
    return null;
  }
}



// === ACS LOCAL OVERRIDE ===
(function(){
  if(!window.ACS_LOCAL) return;
  window.ACS_DEBUG = /acscalc_debug=1/.test(location.search) || window.ACS_DEBUG;

  async function runLocal(payload, city){
    try{
      const loc = await ACS_LOCAL.resolveCity(city);
      payload.lat = loc.lat;
      payload.lon = loc.lon;
      const chart = await ACS_LOCAL.computeChart(payload);
      if(typeof renderChart === 'function') renderChart(chart);
    }catch(e){
      console.error('[ACS]', e);
      alert(e.message);
    }
  }

  window.ACSCALC_RUN_LOCAL = runLocal;
})();

// ---- QUICK RESULT SUN SIGN PATCH ----
(function(){
  function addQuickSunSign(){
    try{
      var box=document.querySelector('[data-result="quick"]');
      if(!box || box.querySelector('.acscalc__quickSun')) return;
      if(window.__ACSCALC_LAST__ && window.__ACSCALC_LAST__.zodiac){
        var d=document.createElement('div');
        d.className='acscalc__quickSun';
        d.innerHTML='<div style="font-weight:600;margin-bottom:6px;">Quick calculation result</div>'
          +'<div>Sun sign: '+window.__ACSCALC_LAST__.zodiac+'</div>'
          +'<div style="font-size:12px;opacity:.7;">Based on your birth date</div>';
        box.prepend(d);
      }
    }catch(e){}
  }
  document.addEventListener('click',function(e){
    var t=e.target;
    if(t && t.getAttribute && t.getAttribute('data-action')==='back-to-quick-result'){
      setTimeout(addQuickSunSign,50);
    }
  });
  document.addEventListener('DOMContentLoaded',function(){
    setTimeout(addQuickSunSign,300);
  });
})();