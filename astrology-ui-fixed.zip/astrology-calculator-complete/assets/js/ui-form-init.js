
jQuery(function($){
  // Restore birth date & time selectors
  if ($('#acs-birth-date').length && !$('#acs-birth-date').attr('type')) {
    $('#acs-birth-date').attr('type','date');
  }
  if ($('#acs-birth-time').length && !$('#acs-birth-time').attr('type')) {
    $('#acs-birth-time').attr('type','time');
  }
});
