
jQuery(function($){
  // Simple city autocomplete fallback
  $('#acs-city').on('input', function(){
    // placeholder for core plugin autocomplete binding
  });
});
