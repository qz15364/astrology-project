<?php
/**
 * Plugin Name: Astrology Calculator (Astral UI)
 * Description: Astral-style UI for ACS astrology recommend system. Shortcode: [astrology_calculator]
 * Version: 1.5.5-age-bucket-fix
 * Author: MyTeam
 */

if (!defined('ABSPATH')) { exit; }

// Bump asset version to break browser/cache-plugin caches after bugfix releases.
define('ACSCALC_COMPLETE_VERSION', '1.5.5-age-bucket-fix');

// Social proof (pseudo-dynamic) defaults (display-only).
// Can be overridden via WordPress filters:
//   - acscalc_socialproof_base   (int)
//   - acscalc_socialproof_rating (float)
//   - acscalc_socialproof_epoch  (string ISO datetime)
if (!defined('ACSCALC_SOCIALPROOF_BASE')) {
  define('ACSCALC_SOCIALPROOF_BASE', 138888);
}
if (!defined('ACSCALC_SOCIALPROOF_RATING')) {
  define('ACSCALC_SOCIALPROOF_RATING', 4.9);
}
if (!defined('ACSCALC_SOCIALPROOF_EPOCH')) {
  define('ACSCALC_SOCIALPROOF_EPOCH', '2025-01-01T00:00:00Z');
}

if (!defined('ACSCALC_COMPLETE_URL')) {
  define('ACSCALC_COMPLETE_URL', plugin_dir_url(__FILE__));
}
if (!defined('ACSCALC_COMPLETE_PATH')) {
  define('ACSCALC_COMPLETE_PATH', plugin_dir_path(__FILE__));
}




/**
 * Find ACS DB plugin static city JSON file URL (world-cities-min.json).
 * This keeps city autocomplete fast (front-end fetch + local filter) and avoids REST/PHP parsing.
 */
function acscalc_complete_find_cities_json_url() {
  // Prefer the ACS DB plugin path when available (folder name may vary).
  $file = '';
  if (defined('ACS_PLUGIN_DIR')) {
    $candidate = trailingslashit(ACS_PLUGIN_DIR) . 'assets/data/world-cities-min.json';
    if (file_exists($candidate)) $file = $candidate;
  }
  if ($file === '') {
    // Fallback: scan common plugin layouts.
    $paths = glob(WP_PLUGIN_DIR . '/*/assets/data/world-cities-min.json');
    if ($paths && is_array($paths) && isset($paths[0])) {
      $file = $paths[0];
    }
  }
  if ($file === '' || !file_exists($file)) return '';
  if (!file_exists($file)) return '';
  // Convert absolute plugin path to URL.
  $rel = str_replace(WP_PLUGIN_DIR, '', $file);
  $rel = ltrim(str_replace('\\', '/', $rel), '/');
  return plugins_url($rel);
}

function acscalc_complete_find_shortcode_page_url($shortcode_tag) {
  global $wpdb;
  $shortcode_tag = sanitize_key($shortcode_tag);
  if (!$shortcode_tag) return '';

  $cache_key = 'acscalc_sc_url_' . $shortcode_tag;
  $cached = get_transient($cache_key);
  // Cache only non-empty results (avoid "sticky empty" when pages are created later).
  if (is_string($cached) && $cached !== '') return $cached;

  // Most editors store shortcodes in post_content, but some builders (e.g., Elementor)
  // keep the layout in postmeta (like _elementor_data). Search both.
  $like_bracket = '%[' . $wpdb->esc_like($shortcode_tag) . '%';
  $like_raw     = '%' . $wpdb->esc_like($shortcode_tag) . '%';

  // 1) post_content search
  $sql1 = $wpdb->prepare(
    "SELECT ID FROM {$wpdb->posts}
     WHERE post_status = 'publish'
       AND post_type IN ('page','post')
       AND (post_content LIKE %s OR post_content LIKE %s)
     ORDER BY post_type DESC, ID ASC
     LIMIT 1",
    $like_bracket, $like_raw
  );
  $post_id = (int) $wpdb->get_var($sql1);

  // 2) postmeta search (builders)
  if (!$post_id) {
    $sql2 = $wpdb->prepare(
      "SELECT p.ID
       FROM {$wpdb->posts} p
       INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID
       WHERE p.post_status = 'publish'
         AND p.post_type IN ('page','post')
         AND (pm.meta_value LIKE %s OR pm.meta_value LIKE %s)
       ORDER BY p.post_type DESC, p.ID ASC
       LIMIT 1",
      $like_bracket, $like_raw
    );
    $post_id = (int) $wpdb->get_var($sql2);
  }

  $url = $post_id ? get_permalink($post_id) : '';

  if ($url) {
    set_transient($cache_key, $url, 12 * HOUR_IN_SECONDS);
  } else {
    // Short negative cache to reduce DB load but allow quick recovery
    set_transient($cache_key, '', 5 * MINUTE_IN_SECONDS);
  }
  return $url;
}

/**
 * Compute a login URL with redirect back to current page.
 * Prefers WooCommerce My Account page when available.
 */
function acscalc_complete_get_login_url() {
  $redirect = (function(){
    try {
      $scheme = is_ssl() ? 'https://' : 'http://';
      $host = $_SERVER['HTTP_HOST'] ?? '';
      $uri  = $_SERVER['REQUEST_URI'] ?? '';
      if ($host && $uri) return $scheme . $host . $uri;
    } catch (Throwable $e) {}
    return home_url('/');
  })();

  if (function_exists('wc_get_page_permalink')) {
    $acc = wc_get_page_permalink('myaccount');
    if ($acc && is_string($acc)) {
      return add_query_arg('redirect_to', rawurlencode($redirect), $acc);
    }
  }

  return wp_login_url($redirect);
}





if (!function_exists('acscalc_complete_theme_options')) {
  function acscalc_complete_theme_options() {
    $defaults = [
      ['key'=>'general','label'=>'General Reading'],
      ['key'=>'love','label'=>'Love & Relationships'],
      ['key'=>'career','label'=>'Career Development'],
      ['key'=>'wealth','label'=>'Wealth Opportunities'],
      ['key'=>'study','label'=>'Study & Growth'],
      ['key'=>'teen','label'=>'Teen Guidance'],
      ['key'=>'self','label'=>'Self Exploration'],
    ];
    if (function_exists('acs_get_enabled_theme_template_options')) {
      $rows = acs_get_enabled_theme_template_options();
      if (is_array($rows) && !empty($rows)) return $rows;
    }
    return $defaults;
  }
}


if (!function_exists('acscalc_complete_normalize_theme_key')) {
  function acscalc_complete_normalize_theme_key($key) {
    $key = sanitize_key((string)$key);
    if ($key === 'communication') return 'teen';
    $allowed = ['general','love','career','wealth','study','self','teen'];
    return in_array($key, $allowed, true) ? $key : 'general';
  }
}

if (!function_exists('acscalc_complete_house_options')) {
  function acscalc_complete_house_options() {
    return [
      ['value' => 1, 'label' => '1st House — Self & Identity'],
      ['value' => 2, 'label' => '2nd House — Money & Values'],
      ['value' => 3, 'label' => '3rd House — Communication & Learning'],
      ['value' => 4, 'label' => '4th House — Home & Roots'],
      ['value' => 5, 'label' => '5th House — Love & Creativity'],
      ['value' => 6, 'label' => '6th House — Work & Wellbeing'],
      ['value' => 7, 'label' => '7th House — Partnership'],
      ['value' => 8, 'label' => '8th House — Transformation'],
      ['value' => 9, 'label' => '9th House — Study & Expansion'],
      ['value' => 10, 'label' => '10th House — Career & Reputation'],
      ['value' => 11, 'label' => '11th House — Community & Goals'],
      ['value' => 12, 'label' => '12th House — Inner World & Healing'],
    ];
  }
}

if (!function_exists('acscalc_complete_render_house_select')) {
  function acscalc_complete_render_house_select($field_id) {
    $options = acscalc_complete_house_options();
    ob_start();
    ?>
    <label class="acscalc__field acscalc__field--full acscalc__field--houseSelect">
      <span class="acscalc__label">Choose your focus house for Premium Reading</span>
      <select class="acscalc__input" name="house" id="<?php echo esc_attr($field_id); ?>" data-role="houseSelect">
        <option value="">Select a house focus</option>
        <?php foreach ($options as $opt): ?>
          <option value="<?php echo esc_attr((string)$opt['value']); ?>"><?php echo esc_html((string)$opt['label']); ?></option>
        <?php endforeach; ?>
      </select>
      <small class="acscalc__fieldHint">Premium Reading now requires a house focus to align with the astrology content system.</small>
    </label>
    <?php
    return ob_get_clean();
  }
}

if (!function_exists('acscalc_complete_render_theme_select')) {
  function acscalc_complete_render_theme_select($field_id) {
    $options = acscalc_complete_theme_options();
    ob_start();
    ?>
    <label class="acscalc__field acscalc__field--full acscalc__field--themeSelect">
      <span class="acscalc__label">Please select the area you wish to receive guidance on</span>
      <select class="acscalc__input" name="theme" id="<?php echo esc_attr($field_id); ?>">
        <?php foreach ($options as $opt):
          $key = isset($opt['key']) ? acscalc_complete_normalize_theme_key($opt['key']) : 'general';
          $label = isset($opt['label']) && trim((string)$opt['label']) !== '' ? (string)$opt['label'] : ucfirst($key);
        ?>
          <option value="<?php echo esc_attr($key); ?>" <?php selected($key, 'general'); ?>><?php echo esc_html($label); ?></option>
        <?php endforeach; ?>
      </select>
      
    </label>
    <?php
    return ob_get_clean();
  }
}

function acscalc_complete_enqueue_assets() {
  wp_register_style(
    'acscalc-complete',
    ACSCALC_COMPLETE_URL . 'assets/css/acscalc-complete.css',
    [],
    ACSCALC_COMPLETE_VERSION
  );

  // IMPORTANT: This UI relies on the ACS database plugin's browser-side Moshier fallback.
  // Some WP optimization stacks can reorder footer scripts; to guarantee order, we
  // declare dependencies when those handles are present.
  $deps = [];
  foreach (['acs-moshier-fallback','acs-moshier-recommend','acs-moshier-adapter','acs-moshier-ephemeris'] as $h) {
    if (wp_script_is($h, 'registered') || wp_script_is($h, 'enqueued')) {
      $deps[] = $h;
    }
  }

  wp_register_script(
    'acscalc-complete',
    ACSCALC_COMPLETE_URL . 'assets/js/acscalc-complete.js',
    $deps,
    ACSCALC_COMPLETE_VERSION,
    true
  );

  wp_enqueue_style('acscalc-complete');
  wp_enqueue_script('acscalc-complete');

  $site_url = site_url('/');

  // IMPORTANT: Do not change API endpoints or payload logic. This UI calls the existing ACS endpoints.
  $cfg = [
    'siteUrl'       => $site_url,
    'recommendUrl'  => trailingslashit($site_url) . 'wp-json/acs/v1/recommend',
    // Premium recommend proxy (requires login)
    'premiumRecommendUrl' => trailingslashit($site_url) . 'wp-json/acscalc/v1/recommend-premium',
    'chartUrl'      => trailingslashit($site_url) . 'wp-json/acs/v1/chart',
    'natalModulesConfigUrl' => trailingslashit($site_url) . 'wp-json/acs/v1/natal-modules-config',
    // Pure front-end mode: compute charts in browser via Moshier, do not call /wp-json/acs/v1/chart
    'localOnly'    => false,
    'citiesUrl'     => (acscalc_complete_find_cities_json_url() ?: (trailingslashit($site_url) . 'wp-json/acscalc/v1/cities')),
    // Also expose to ACS_CONFIG for compatibility with other scripts
    'citiesJsonUrl' => acscalc_complete_find_cities_json_url(),
    // Legacy (previous versions used a separate [astrology_calculator_precise] page)
    // Kept for backward compatibility in JS, but this Astral UI runs both modes in-page.
    'precisePageUrl' => '',
    // Social proof UI config (display-only)
    'themeTemplates' => acscalc_complete_theme_options(),
    'houseOptions'   => acscalc_complete_house_options(),
    'socialProof'    => [
      'base'   => (int) apply_filters('acscalc_socialproof_base', ACSCALC_SOCIALPROOF_BASE),
      'rating' => (float) apply_filters('acscalc_socialproof_rating', ACSCALC_SOCIALPROOF_RATING),
      'epoch'  => (string) apply_filters('acscalc_socialproof_epoch', ACSCALC_SOCIALPROOF_EPOCH),
    ],
    // Auth gating (Premium requires login)
    'auth' => [
      // NOTE: this can be affected by full-page caching. JS will refresh via auth.stateUrl.
      'isLoggedIn' => is_user_logged_in(),
      // Prefer WooCommerce account page if available, otherwise fallback to wp-login.php
      'loginUrl' => acscalc_complete_get_login_url(),
      // Optional: site owners can override via filter acscalc_signup_url
      'signupUrl' => (string) apply_filters('acscalc_signup_url', ''),
      // REST nonce for cookie-authenticated POST requests (needed for Premium proxy).
      'restNonce' => is_user_logged_in() ? wp_create_nonce('wp_rest') : '',
      // Auth refresh endpoint (GET) for cache-safe login state + nonce.
      'stateUrl'  => trailingslashit($site_url) . 'wp-json/acscalc/v1/auth',
    ],
  ];

  // 🌟 获取星盘解读话术模板数据
  if (function_exists('acs_build_frontend_payload')) {
    $payload = acs_build_frontend_payload();
    // Also expose generic template library so the UI can resolve nested placeholders
    // like {{action_career_01}} inside natal_chart_templates and report copy.
    if (isset($payload['templates'])) {
      $cfg['templates'] = $payload['templates'];
    }
    if (isset($payload['natal_chart_templates'])) {
      $cfg['natal_chart_templates'] = $payload['natal_chart_templates'];
    }
  }


  wp_localize_script('acscalc-complete', 'ACSCALC', $cfg);
  // Ensure ACS_CONFIG.citiesJsonUrl is available for the city DB loader.
  $cities_json = $cfg['citiesJsonUrl'] ?? '';
  if ($cities_json) {
    wp_add_inline_script('acscalc-complete', 'window.ACS_CONFIG = window.ACS_CONFIG || {}; window.ACS_CONFIG.citiesJsonUrl = ' . wp_json_encode($cities_json) . ';', 'before');
  }
}


function acscalc_complete_render($mode='both') {
  $mode = in_array($mode, ['both','quick','precise'], true) ? $mode : 'both';

  $root_class = 'acscalc';
  $root_class .= ($mode === 'quick') ? ' acscalc--quick' : '';
  $root_class .= ($mode === 'precise') ? ' acscalc--precise' : '';

  ob_start();
  
?>
  <style>
/* Critical CSS - 内联关键样式，防止 FOUC */
/* Critical CSS (Astral) - keep minimal but aligned with external stylesheet */
.acscalc__viewport{
  position:relative;
  width:100vw;
  left:50%;
  right:50%;
  margin-left:-50vw;
  margin-right:-50vw;
  padding:56px 14px 72px;
  background:
    radial-gradient(1100px 560px at 50% 10%, rgba(167,139,250,.22), transparent 62%),
    radial-gradient(900px 560px at 78% 35%, rgba(236,72,153,.14), transparent 64%),
    radial-gradient(900px 560px at 22% 50%, rgba(56,189,248,.12), transparent 64%),
    linear-gradient(180deg, rgba(22,12,38,1), rgba(10,8,18,1));
  overflow:hidden;
}
.acscalc__viewport::before,
.acscalc__viewport::after{
  content:"";
  position:absolute;
  inset:-240px;
  pointer-events:none;
}
.acscalc__fieldHint{display:block;margin-top:8px;color:rgba(255,255,255,.68);font-size:12px;line-height:1.45;}
.acscalc__viewport::before{
  opacity:.65;
  background:
    radial-gradient(circle at 6% 18%, rgba(255,255,255,.85) 0 1px, transparent 2px),
    radial-gradient(circle at 10% 72%, rgba(255,255,255,.7) 0 1px, transparent 2px),
    radial-gradient(circle at 18% 40%, rgba(255,255,255,.65) 0 1px, transparent 2px),
    radial-gradient(circle at 28% 22%, rgba(255,255,255,.8) 0 1px, transparent 2px),
    radial-gradient(circle at 36% 66%, rgba(255,255,255,.6) 0 1px, transparent 2px),
    radial-gradient(circle at 50% 18%, rgba(255,255,255,.7) 0 1px, transparent 2px),
    radial-gradient(circle at 62% 52%, rgba(255,255,255,.6) 0 1px, transparent 2px),
    radial-gradient(circle at 72% 26%, rgba(255,255,255,.75) 0 1px, transparent 2px),
    radial-gradient(circle at 82% 64%, rgba(255,255,255,.6) 0 1px, transparent 2px),
    radial-gradient(circle at 92% 28%, rgba(255,255,255,.6) 0 1px, transparent 2px),
    radial-gradient(circle at 96% 70%, rgba(255,255,255,.55) 0 1px, transparent 2px);
  filter:blur(.2px);
}
.acscalc__viewport::after{
  opacity:.9;
  background:
    radial-gradient(60% 60% at 10% 55%, rgba(167,139,250,.18), transparent 62%),
    radial-gradient(60% 60% at 90% 48%, rgba(56,189,248,.12), transparent 62%),
    radial-gradient(70% 70% at 50% 25%, transparent 0 60%, rgba(0,0,0,.55) 100%);
}

.acscalc{
  position:relative;
  max-width:1100px;
  margin:0 auto;
  padding:26px;
  border-radius:32px;
  background:
    radial-gradient(1200px 700px at 45% 15%, rgba(167,139,250,.22), transparent 60%),
    radial-gradient(900px 520px at 70% 25%, rgba(236,72,153,.16), transparent 58%),
    radial-gradient(900px 520px at 25% 45%, rgba(56,189,248,.12), transparent 62%),
    linear-gradient(180deg, rgba(34,16,54,.92), rgba(19,12,34,.96));
  border:1px solid rgba(255,255,255,.08);
  box-shadow:0 30px 120px rgba(0,0,0,.45), 0 0 0 100vmax rgba(16,10,28,.92);
  color:rgba(255,255,255,.92);
  font-family:ui-sans-serif,system-ui,-apple-system,Segoe UI,Roboto,Arial,"PingFang SC","Hiragino Sans GB","Microsoft YaHei",sans-serif;
  overflow:hidden;
}
.acscalc *{box-sizing:border-box}
.acscalc__shell{position:relative;z-index:2;padding:10px}

.acscalc__appTop{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:14px}
.acscalc__appBrand{display:flex;align-items:center;gap:10px;font-weight:800}
.acscalc__appDot{width:14px;height:14px;border-radius:999px;background:rgba(167,139,250,.95);box-shadow:0 0 0 6px rgba(167,139,250,.18)}
.acscalc__appLink{color:rgba(255,255,255,.75);text-decoration:none;font-size:13px;display:none}
.acscalc.is-results .acscalc__appLink{display:inline-flex}

.acscalc__brand{padding:16px 16px 14px;border-radius:22px;border:1px solid rgba(255,255,255,.10);background:rgba(0,0,0,.18);backdrop-filter:blur(6px)}
.acscalc__brandMark{width:44px;height:44px;border-radius:999px;background:radial-gradient(circle at 30% 30%, rgba(167,139,250,1), rgba(99,102,241,.35));border:1px solid rgba(255,255,255,.18)}
.acscalc__title{margin:0;font-size:18px;font-weight:850}
.acscalc__subtitle{margin-top:6px;color:rgba(255,255,255,.66);font-size:13px;line-height:1.45}

.acscalc__tabs--astral{
  margin:16px auto 8px;
  max-width:520px;
  padding:8px;
  border-radius:999px;
  background:rgba(0,0,0,.18);
  border:1px solid rgba(255,255,255,.12);
  display:flex;
  justify-content:center;
  gap:10px;
}
.acscalc__tabs--astral .acscalc__tab{
  flex:1 1 0;
  min-width:0;
  padding:12px 16px;
  border-radius:999px;
  background:rgba(0,0,0,.22);
  border:1px solid rgba(255,255,255,.14);
  color:rgba(255,255,255,.82);
  font-size:13px;
  cursor:pointer;
  text-align:center;
  line-height:1;
}
.acscalc__tabs--astral .acscalc__tab.is-active{
  background:rgba(167,139,250,.22);
  border-color:rgba(167,139,250,.55);
  color:#fff;
  box-shadow:0 10px 30px rgba(167,139,250,.18);
}
.acscalc.is-results .acscalc__tabs{display:none!important}

.acscalc__card{border-radius:22px;border:1px solid rgba(255,255,255,.10);background:rgba(0,0,0,.18);padding:14px;margin-bottom:12px}
.acscalc__card--form{background:linear-gradient(180deg, rgba(17,28,52,.78), rgba(10,15,26,.55))}
.acscalc__sectionTitle{font-size:14px;font-weight:760}
.acscalc__sectionHint{font-size:12px;color:rgba(255,255,255,.55)}
.acscalc__label{font-size:12px;color:rgba(255,255,255,.82);display:block;margin-bottom:7px}
.acscalc__input{width:100%;padding:12px;border-radius:16px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.06);color:rgba(255,255,255,.92);font-size:14px}
.acscalc__cta{width:100%;border:0;border-radius:18px;padding:12px 14px;background:linear-gradient(90deg, rgba(217,70,239,.95), rgba(167,139,250,.95));color:#fff;font-weight:800;font-size:14px;cursor:pointer}
.acscalc__cta:hover{filter:brightness(1.05)}
.acscalc__dateRow,.acscalc__timeRow{display:flex;gap:10px}
.acscalc__dateRow .acscalc__input,.acscalc__timeRow .acscalc__input{flex:1}\n</style>
<!-- 移动端滚轮选择器容器 - 全局共用 -->
<div class="acscalc-wheel-picker" id="acscalcWheelPicker" data-role="wheelPicker" style="display:none;">
  <div class="acscalc-wheel-picker__overlay"></div>
  <div class="acscalc-wheel-picker__container">
    <div class="acscalc-wheel-picker__header">
      <button type="button" class="acscalc-wheel-picker__btn acscalc-wheel-picker__btn--cancel" data-action="wheelCancel">Cancel</button>
      <span class="acscalc-wheel-picker__title">Select</span>
      <button type="button" class="acscalc-wheel-picker__btn acscalc-wheel-picker__btn--confirm" data-action="wheelConfirm">Done</button>
    </div>
    <div class="acscalc-wheel-picker__body">
      <div class="acscalc-wheel-picker__highlight"></div>
      <div class="acscalc-wheel-picker__wheels" data-role="wheelsContainer">
        <!-- 滚轮列会由JS动态生成 -->
      </div>
    </div>
  </div>
</div>

<div class="acscalc__viewport" data-role="viewport">
<div class="<?php echo esc_attr($root_class); ?>" data-mode="<?php echo esc_attr($mode); ?>">
    <div class="acscalc__shell">

      <header class="acscalc__top">
        <div class="acscalc__appTop" aria-label="Astral header">
          <div class="acscalc__appBrand"><span class="acscalc__appDot" aria-hidden="true"></span> Astral Crystals</div>
          <div class="acscalc__appRight">
            <a class="acscalc__appLink" href="javascript:void(0)" data-action="app-back">&larr; Back</a>
          </div>
        </div>

        <!-- Social proof (pseudo-dynamic, display-only) -->
        <div class="acscalc__socialProof" data-role="socialProof" aria-label="Social proof" role="note">
          <div class="acscalc__spBadge" aria-label="Rating">
            <span class="acscalc__spStars" aria-hidden="true">★★★★★</span>
            <span class="acscalc__spScore" data-role="spScore">4.9</span>
          </div>
          <div class="acscalc__spLine acscalc__spLine--small">Your privacy is our priority · all data is encrypted</div>
          <div class="acscalc__spLine"><span data-role="spUsers">Over 138,888+ users</span> have tested and aligned their energy</div>
        </div>

        <div class="acscalc__brand">
          <div class="acscalc__brandMark" aria-hidden="true"></div>
          <div class="acscalc__brandText">
            <h2 class="acscalc__title">Astral Crystal Reading</h2>
            <p class="acscalc__subtitle">Enter your birthday to start your personalized crystal energy alignment journey.</p>
          </div>
        </div>

        <?php if ($mode === 'both'): ?>
          <div class="acscalc__tabs acscalc__tabs--astral" data-role="tabs" role="tablist" aria-label="Calculation mode">
            <button class="acscalc__tab is-active" data-tab="quick" role="tab" aria-selected="true" type="button">Basic Reading</button>
            <button class="acscalc__tab" data-tab="precise" role="tab" aria-selected="false" type="button">Premium Reading</button>
          </div>
        <?php endif; ?>
      </header>

      <div class="acscalc__error" data-role="error" style="display:none;"></div>

      <!-- Login gate modal (Premium requires login) -->
      <div class="acscalc__modal" data-role="loginGate" aria-hidden="true" style="display:none;">
        <div class="acscalc__modalOverlay" data-action="loginGateClose" aria-hidden="true"></div>
        <div class="acscalc__modalCard" role="dialog" aria-modal="true" aria-label="Login required">
          <div class="acscalc__modalTitle">Login required</div>
          <div class="acscalc__modalText">Premium Reading requires an account. Please log in to continue.</div>
          <div class="acscalc__modalActions">
            <a class="acscalc__modalBtn acscalc__modalBtn--primary" data-action="loginGateLogin" href="#">Log in</a>
            <a class="acscalc__modalBtn" data-action="loginGateSignup" href="#">Create account</a>
            <button class="acscalc__modalBtn acscalc__modalBtn--ghost" type="button" data-action="loginGateClose">Cancel</button>
          </div>
        </div>
      </div>

      <?php if (!defined('ACS_PLUGIN_URL')): 
?>
        <div class="acscalc__alert acscalc__alert--error">Missing dependency: please enable <strong>Astrology Crystal System (ACS)</strong> database plugin (provides /wp-json/acs/v1/* endpoints).</div>
      <?php endif; 
?>

      <?php if ($mode !== 'precise'): 
?>
        <section class="acscalc__panel is-active" data-panel="quick" style="display:block;">

          <!-- PAGE 01: Quick Input -->
          <div class="acscalc__page acscalc__page--quickInput" data-page="quick-input">
            <div class="acscalc__hero acscalc__hero--quick">
              <div class="acscalc__heroTitle">Quick Reading</div>
              <div class="acscalc__heroSub">Fast, one-click assessment · Sun sign + scenario pain points (PAI) + basic energy set</div>
            </div>

            <div class="acscalc__pageBody">
              <div class="acscalc__card acscalc__card--form">
                <div class="acscalc__sectionHd">
                  <div class="acscalc__sectionTitle">Enter your details</div>
                  <div class="acscalc__sectionHint">For accurate results, please provide your birth date, time, and city.</div>
                </div>

                <form class="acscalc__form acscalc__form--stacked" data-form="quick">

                  <div class="acscalc__group acscalc__group--birth">
                    <div class="acscalc__groupTitle">Birth Information</div>
                    <div class="acscalc__groupGrid">
                      <label class="acscalc__field acscalc__field--full">
                        <span class="acscalc__label">Date of Birth</span>
                        <div class="acscalc__dateRow" data-role="birthDateRow">
                          <select class="acscalc__input" name="birthMonth" data-role="birthMonth" required><option value="">Month</option></select>
                          <select class="acscalc__input" name="birthDay" data-role="birthDay" required><option value="">Day</option></select>
                          <select class="acscalc__input" name="birthYear" data-role="birthYear" required><option value="">Year</option></select>
                        </div>
                        <input type="text" class="acscalc__input acscalc__mobileDateTrigger" data-role="mobileDateTrigger" placeholder="Tap to select date" readonly />
                        <input type="hidden" name="birthDate" value="" data-role="birthDate" />
                      </label>

                      <input type="hidden" name="birthTime" value="12:00" data-role="birthTime" />

                      <label class="acscalc__field acscalc__field--full">
                        <span class="acscalc__label">Place of Birth</span>
                        <input class="acscalc__input" type="text" name="birthCity" required placeholder="e.g., New York, USA" autocomplete="off"/>
                        <div class="acscalc__suggestions" data-suggest="quick" style="display:none;"></div>
                      </label>
                    </div>
                  </div>

                  <div class="acscalc__group acscalc__group--question">
                    <div class="acscalc__groupTitle">Question Type</div>
                    <div class="acscalc__groupGrid acscalc__groupGrid--single">
                      <?php echo acscalc_complete_render_theme_select('acscalc-theme-quick'); ?>
                    </div>
                  </div>

                  <label class="acscalc__field acscalc__field--full acscalc__field--consent">
                    <span class="acscalc__checkbox">
                      <input type="checkbox" name="consent" required/>
                      <span>I agree to the <a href="#" target="_blank" rel="nofollow">Privacy Policy</a> and <a href="#" target="_blank" rel="nofollow">Data Usage Policy</a>.</span>
                    </span>
                  </label>

                  <div class="acscalc__formActions">
                    <button class="acscalc__cta" type="submit">Get Your Reading</button>
                    <div class="acscalc__loading" data-role="loading" style="display:none;">Calculating…</div>
                    <div class="acscalc__fineprint">Private and secure · personalized guidance based on your birth details</div>
                  </div>

                </form>
              </div>

              <div class="acscalc__card acscalc__card--trust">
                <div class="acscalc__sectionHd">
                  <div class="acscalc__sectionTitle">Trust & Compliance</div>
                  <div class="acscalc__sectionHint">Understandable · Verifiable · Controllable</div>
                </div>
                <div class="acscalc__trustList">
                  <div class="acscalc__trustItem">
                    <div class="acscalc__trustTitle">Data minimization</div>
                    <div class="acscalc__trustDesc">Only uses birth time and city coordinates for chart calculation—no profiling or tracking.</div>
                  </div>
                  <div class="acscalc__trustItem">
                    <div class="acscalc__trustTitle">Local-first</div>
                    <div class="acscalc__trustDesc">Your plan can be saved locally in your browser—never uploaded to third parties.</div>
                  </div>
                  <div class="acscalc__trustItem">
                    <div class="acscalc__trustTitle">For reference only</div>
                    <div class="acscalc__trustDesc">All astrology/energy descriptions are for reflection only and are not professional advice.</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- PAGE 02: Quick Results -->
          <div class="acscalc__page acscalc__page--quickResult" data-page="quick-result" hidden style="display:none;">
            <div class="acscalc__hero acscalc__hero--quick">
              <div class="acscalc__heroTitle">Quick Reading · Results</div>
              <div class="acscalc__heroSub">Clear summary + scenario insights + energy set · One-click upgrade for a deeper report</div>
            </div>

            <div class="acscalc__pageBody">
              <div class="acscalc__card acscalc__card--resultPage">
                <div class="acscalc__sectionHd">
                  <div class="acscalc__sectionTitle">Summary & Suggestions</div>
                  <div class="acscalc__sectionHint">This is a lightweight quick result—upgrade to unlock the full report</div>
                </div>
                <div class="acscalc__result" data-result="quick" style="display:block;"></div>
              </div>

              <div class="acscalc__card acscalc__card--nav">
                <div class="acscalc__sectionHd">
                  <div class="acscalc__sectionTitle">Next</div>
                  <div class="acscalc__sectionHint">Continue with Quick Reading or open the upgrade guide</div>
                </div>
                <div class="acscalc__actions">
                  <button class="acscalc__btn" type="button" data-action="back-to-quick-input">Back</button>
                  <button class="acscalc__btn acscalc__btn--primary" type="button" data-action="open-upgrade">Upgrade guide</button>
                </div>
                <div class="acscalc__fineprint" style="margin-top:10px;">Results are for reference only. Product effects vary by individual.</div>
              </div>
            </div>
          </div>

          <!-- PAGE 06: Upgrade guide -->
          <div class="acscalc__page acscalc__page--upgrade" data-page="quick-upgrade" hidden style="display:none;">
            <div class="acscalc__upgradePage" aria-label="Upgrade guide">
              <div class="acscalc__upgradeGrid">
                <div class="acscalc__upgradeLeft">
                  <div class="acscalc__upgradeHd">Upgrade guide</div>
                  <div class="acscalc__upgradeSub">Unlock deeper self-discovery</div>

                  <ul class="acscalc__upgradeBullets">
                    <li>
                      <span class="acscalc__uIcon" aria-hidden="true"></span>
                      <div>
                        <div class="acscalc__uTitle">Deep full-chart analysis</div>
                        <div class="acscalc__uDesc">Explore cosmic patterns and gain insight into life trends</div>
                      </div>
                    </li>
                    <li>
                      <span class="acscalc__uIcon" aria-hidden="true"></span>
                      <div>
                        <div class="acscalc__uTitle">Higher-match energy configuration</div>
                        <div class="acscalc__uDesc">Calibrate your energy and improve wellbeing</div>
                      </div>
                    </li>
                    <li>
                      <span class="acscalc__uIcon" aria-hidden="true"></span>
                      <div>
                        <div class="acscalc__uTitle">Personalized blind-spot analysis</div>
                        <div class="acscalc__uDesc">Identify bottlenecks and grow beyond them</div>
                      </div>
                    </li>
                    <li>
                      <span class="acscalc__uIcon" aria-hidden="true"></span>
                      <div>
                        <div class="acscalc__uTitle">Your 30-day transit guide</div>
                        <div class="acscalc__uDesc">Catch the right timing and go with the flow</div>
                      </div>
                    </li>
                  </ul>
                </div>

                <div class="acscalc__upgradeRight">
                  <div class="acscalc__upgradeRTitle">Start your personalized journey</div>
                  <div class="acscalc__upgradeCtas">
                    <button class="acscalc__upgradeBtn acscalc__upgradeBtn--primary" type="button" data-action="switch-precise">Free upgrade</button>
                    <button class="acscalc__upgradeBtn" type="button" data-action="back-to-quick-result">Continue Quick Reading</button>
                  </div>
                  <div class="acscalc__upgradeFoot">Upgrading unlocks all advanced features for a much deeper guidance.</div>
                </div>
              </div>
            </div>
          </div>

        </section>
      <?php endif; 
?>

      <?php if ($mode !== 'quick'): 
?>
        <section class="acscalc__panel<?php echo ($mode==='precise') ? ' is-active' : ''; 
?>" data-panel="precise" <?php echo ($mode==='precise') ? '' : 'hidden'; 
?> style="<?php echo ($mode==='precise') ? 'display:block;' : 'display:none;'; 
?>">

          <!-- PRECISE PAGE A: Input -->
          <div class="acscalc__page acscalc__page--preciseInput" data-page="precise-input">
            <div class="acscalc__hero acscalc__hero--precise">
              <div class="acscalc__heroTitle">Precise Reading · Deep report</div>
              <div class="acscalc__heroSub">Multi-dimensional full-chart reading · Key aspects & patterns · Higher-match energy configuration</div>
            </div>

            <div class="acscalc__pageBody acscalc__pageBody--precise">
              <div class="acscalc__card acscalc__card--form">
                <div class="acscalc__sectionHd">
                  <div class="acscalc__sectionTitle">Enter your details</div>
                  <div class="acscalc__sectionHint">Please provide your exact birth information for the most accurate result</div>
                </div>

                <form class="acscalc__form acscalc__form--stacked" data-form="precise">

                  <div class="acscalc__group acscalc__group--birth">
                    <div class="acscalc__groupTitle">Birth Information</div>
                    <div class="acscalc__groupGrid">
                      <label class="acscalc__field acscalc__field--full">
                        <span class="acscalc__label">Date of Birth</span>
                        <div class="acscalc__dateRow" data-role="birthDateRow">
                          <select class="acscalc__input" name="birthMonth" data-role="birthMonth" required><option value="">Month</option></select>
                          <select class="acscalc__input" name="birthDay" data-role="birthDay" required><option value="">Day</option></select>
                          <select class="acscalc__input" name="birthYear" data-role="birthYear" required><option value="">Year</option></select>
                        </div>
                        <input type="text" class="acscalc__input acscalc__mobileDateTrigger" data-role="mobileDateTrigger" placeholder="Tap to select date" readonly />
                        <input type="hidden" name="birthDate" value="" data-role="birthDate" />
                      </label>

                      <label class="acscalc__field acscalc__field--full">
                        <span class="acscalc__label">Time of Birth</span>
                        <div class="acscalc__timeRow" data-role="birthTimeRow">
                          <select class="acscalc__input" name="birthHour" data-role="birthHour" required><option value="">Hour</option></select>
                          <select class="acscalc__input" name="birthMinute" data-role="birthMinute" required><option value="">Minute</option></select>
                        </div>
                        <input type="text" class="acscalc__input acscalc__mobileTimeTrigger" data-role="mobileTimeTrigger" placeholder="Tap to select time" readonly />
                        <input type="hidden" name="birthTime" value="12:00" data-role="birthTime" />
                      </label>

                      <label class="acscalc__field acscalc__field--full">
                        <span class="acscalc__label">Place of Birth</span>
                        <input class="acscalc__input" type="text" name="birthCity" required placeholder="e.g., New York, USA" autocomplete="off"/>
                        <div class="acscalc__suggestions" data-suggest="precise" style="display:none;"></div>
                      </label>
                    </div>
                  </div>

                  <div class="acscalc__group acscalc__group--question">
                    <div class="acscalc__groupTitle">Question Type</div>
                    <div class="acscalc__groupGrid acscalc__groupGrid--single">
                      <?php echo acscalc_complete_render_theme_select('acscalc-theme-precise'); ?>
                      <?php echo acscalc_complete_render_house_select('acscalc-house-precise'); ?>
                    </div>
                  </div>

                  <label class="acscalc__field acscalc__field--full acscalc__field--consent">
                    <span class="acscalc__checkbox">
                      <input type="checkbox" name="consent" required/>
                      <span>I agree to the <a href="#" target="_blank" rel="nofollow">Privacy Policy</a> and <a href="#" target="_blank" rel="nofollow">Data Usage Policy</a>.</span>
                    </span>
                  </label>

                  <div class="acscalc__formActions">
                    <button class="acscalc__cta" type="submit">Get Your Reading</button>
                    <div class="acscalc__loading" data-role="loading" style="display:none;"></div>
                    <div class="acscalc__fineprint">Private and secure · personalized guidance based on your birth details</div>
                  </div>
                </form>
              </div>

              <div class="acscalc__card acscalc__card--preciseIntro">
                <div class="acscalc__sectionHd">
                  <div class="acscalc__sectionTitle">What’s included</div>
                  <div class="acscalc__sectionHint">More detail, more complete modules</div>
                </div>
                <div class="acscalc__trustList">
                  <div class="acscalc__trustItem">
                    <div class="acscalc__trustTitle">Core chart data</div>
                    <div class="acscalc__trustDesc">Sun/Moon/Rising and key placements—core personality and drivers.</div>
                  </div>
                  <div class="acscalc__trustItem">
                    <div class="acscalc__trustTitle">Key aspects & patterns</div>
                    <div class="acscalc__trustDesc">Identify conflicts/strengths and provide actionable suggestions.</div>
                  </div>
                  <div class="acscalc__trustItem">
                    <div class="acscalc__trustTitle">High-match energy plan</div>
                    <div class="acscalc__trustDesc">Higher-match energy set and configuration suggestions.</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- PRECISE PAGE B: Deep report -->
          <div class="acscalc__page acscalc__page--preciseReport" data-page="precise-report" hidden style="display:none;">
            <div class="acscalc__hero acscalc__hero--precise">
              <div class="acscalc__heroTitle">Precise Reading · Deep report</div>
              <div class="acscalc__heroSub">Core chart data · Analysis · Recommendations · Safety/Compliance</div>
            </div>

            <div class="acscalc__pageBody acscalc__pageBody--preciseReport">
              <aside class="acscalc__side">
                <div class="acscalc__sideCard">
                  <div class="acscalc__sideTitle">Report navigation</div>
                  <ul class="acscalc__sideNav">
                    <li>Core chart data</li>
                    <li>Interpretation</li>
                    <li>Precise recommendations</li>
                    <li>Safety & compliance</li>
                  </ul>
                  <div class="acscalc__actions" style="margin-top:12px;">
                    <button class="acscalc__btn" type="button" data-action="back-to-precise-input">Back</button>
                    <button class="acscalc__btn" type="button" data-action="open-upgrade" style="display:none;">Upgrade</button>
                  </div>
                </div>

                <div class="acscalc__sideCard">
                  <div class="acscalc__sideTitle">Safety / compliance</div>
                  <div class="acscalc__sideText">All astrology/energy descriptions are for reference only and are not medical/psychological/professional advice. Product effects vary.</div>
                </div>
              </aside>

              <main class="acscalc__report">
                <div class="acscalc__card acscalc__card--resultPage">
                  <div class="acscalc__sectionHd">
                    <div class="acscalc__sectionTitle">Deep report contents</div>
                    <div class="acscalc__sectionHint">Please read the modules below (more detailed than the quick version).</div>
                  </div>
                  <div class="acscalc__result" data-result="precise" style="display:block;"></div>
                </div>
              </main>
            </div>
          </div>

        </section>
      <?php endif; 
?>

      <details class="acscalc__details" data-role="details">
        <summary class="acscalc__detailsSummary">Show Details</summary>
        <div class="acscalc__detailsBody">
          <div class="acscalc__detailsTitle">✨ Premium Version Exclusive Benefits (Platform-wide)</div>

          <div class="acscalc__detailsCols">
            <div class="acscalc__detailsCol">
              <div class="acscalc__detailsHd">🔮 Astrology Module</div>
              <ul class="acscalc__detailsList">
                <li>Deep Birth Chart Analysis</li>
                <li>Personalized Crystal Energy Plan</li>
                <li>Quarterly Energy Forecast &amp; Guidance</li>
              </ul>

              <div class="acscalc__detailsHd">🃏 Tarot Module</div>
              <ul class="acscalc__detailsList">
                <li>Exclusive Multi-Spread Readings</li>
                <li>Advanced Card Analysis</li>
                <li>Custom Spread Creation</li>
              </ul>
            </div>

            <div class="acscalc__detailsCol">
              <div class="acscalc__detailsHd">🚀 Affiliate Program Benefits</div>
              <ul class="acscalc__detailsList">
                <li>Agent status upon registration</li>
                <li>Share readings or crystal products, earn 5% permanent commission</li>
              </ul>
            </div>
          </div>
        </div>
      </details>

      <footer class="acscalc__footer">
        <p>All astrology/crystal energy descriptions are for reference only and are not medical/psychological/professional advice. Product effects vary.</p>
      </footer>

    </div>
  </div>
</div><!-- /.acscalc -->
</div><!-- /.acscalc__viewport -->
  <?php
  return ob_get_clean();
}

// REST proxy: serve ACS city database via same-origin
add_action('rest_api_init', function () {
  // Auth state endpoint (GET): returns login status + nonce for POST.
  // This helps when full-page caching serves a stale localized config.
  register_rest_route('acscalc/v1', '/auth', [
    'methods'  => 'GET',
    'permission_callback' => '__return_true',
    'callback' => function () {
      $is = is_user_logged_in();
      return rest_ensure_response([
        'isLoggedIn' => $is,
        'restNonce'  => $is ? wp_create_nonce('wp_rest') : '',
        'loginUrl'   => acscalc_complete_get_login_url(),
        'signupUrl'  => (string) apply_filters('acscalc_signup_url', ''),
      ]);
    }
  ]);

  // Premium recommend proxy: enforce login before calling ACS recommend endpoint.
  register_rest_route('acscalc/v1', '/recommend-premium', [
    'methods'  => 'POST',
    'permission_callback' => function(){
      return is_user_logged_in();
    },
    'callback' => function (WP_REST_Request $request) {
      $target = home_url('/wp-json/acs/v1/recommend');
      $body = $request->get_body();
      $resp = wp_remote_post($target, [
        'headers' => [
          'Content-Type' => 'application/json',
          'Accept' => 'application/json',
        ],
        'body' => $body,
        'timeout' => 25,
      ]);

      if (is_wp_error($resp)) {
        return new WP_Error('acscalc_premium_proxy_failed', 'Premium request failed. Please try again later.', ['status' => 502]);
      }
      $code = (int) wp_remote_retrieve_response_code($resp);
      $raw  = wp_remote_retrieve_body($resp);
      $data = json_decode($raw, true);
      if (json_last_error() === JSON_ERROR_NONE) {
        return new WP_REST_Response($data, $code ?: 200);
      }
      // Fallback: return raw
      return new WP_REST_Response($raw, $code ?: 200);
    }
  ]);

  register_rest_route('acscalc/v1', '/cities', [
    'methods'  => 'GET',
    'permission_callback' => '__return_true',
    'callback' => function () {
      $candidates = [];
      $candidates[] = WP_PLUGIN_DIR . '/astrology-crystal-system/assets/data/world-cities-min.json';
      $candidates[] = WP_PLUGIN_DIR . '/astrology-crystal-system/assets/data/world-cities.json';

      if (defined('ACS_PLUGIN_URL')) {
        $u = ACS_PLUGIN_URL;
        $parts = explode('/', trim($u, '/'));
        $folder = end($parts);
        if ($folder) {
          $candidates[] = WP_PLUGIN_DIR . '/' . $folder . '/assets/data/world-cities-min.json';
          $candidates[] = WP_PLUGIN_DIR . '/' . $folder . '/assets/data/world-cities.json';
        }
      }

      foreach ($candidates as $p) {
        if (is_readable($p)) {
          $raw = file_get_contents($p);
          if ($raw !== false) {
            $data = json_decode($raw, true);
            if (is_array($data)) return rest_ensure_response($data);
          }
        }
      }

      return new WP_Error('acscalc_cities_missing', 'City database not found on server.', ['status' => 404]);
    }
  ]);
});

// Shortcode
// Only keep one: [astrology_calculator]
add_shortcode('astrology_calculator', function($atts=[]){
  acscalc_complete_enqueue_assets();
  return acscalc_complete_render('both');
});


add_action('wp_enqueue_scripts', function(){
  wp_enqueue_script('acs-ui-form-init', plugin_dir_url(__FILE__).'assets/js/ui-form-init.js', ['jquery'], '1.0', true);
  wp_enqueue_script('acs-city-autocomplete', plugin_dir_url(__FILE__).'assets/js/city-autocomplete.js', ['jquery'], '1.0', true);
});
